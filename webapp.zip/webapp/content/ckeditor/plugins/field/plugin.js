CKEDITOR.plugins.add('field', {
    icons: 'field',
    init: function (editor) {

        editor.addCommand('field', new CKEDITOR.dialogCommand('fieldDialog'));


        // Ck Editor button configuration
        editor.ui.addButton('Field', {
            label: 'Insert Fields',
            command: 'field',
            toolbar: 'basicstyles,0'
        });


        // reg dialog name to load
        CKEDITOR.dialog.add('fieldDialog', this.path + 'dialogs/field.js');
    }

});