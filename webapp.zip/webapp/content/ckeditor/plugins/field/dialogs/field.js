
var htmlContent = `
<div style="color:blue;">
<h2 style="font-weight: bold;">Your Information</h2>
<p style="color:red;font-weight: bold; margin:5px; margin-left:0px;">Please make sure all fields are lower case</p>
<span style="color:blue; cursor:pointer; font-size:17px;" onclick="CKEDITOR.instances[Object.keys(CKEDITOR.instances)[0]].insertHtml('{title}')">{title}</span>
<span style="color:blue; cursor:pointer; font-size:17px;" onclick="CKEDITOR.instances[Object.keys(CKEDITOR.instances)[0]].insertHtml('{from:name}')">{from:name}</span>
<span style="color:blue; cursor:pointer; font-size:17px;" onclick="CKEDITOR.instances[Object.keys(CKEDITOR.instances)[0]].insertHtml('{from:email}')">{from:email}</span>
<span style="color:blue; cursor:pointer; font-size:17px;" onclick="CKEDITOR.instances[Object.keys(CKEDITOR.instances)[0]].insertHtml('{phone}')">{phone}</span>
<span style="color:blue; cursor:pointer; font-size:17px;" onclick="CKEDITOR.instances[Object.keys(CKEDITOR.instances)[0]].insertHtml('{tollfree}')">{tollfree}</span><br>
<span style="color:blue; cursor:pointer; font-size:17px;" onclick="CKEDITOR.instances[Object.keys(CKEDITOR.instances)[0]].insertHtml('{cell}')">{cell}</span>
<span style="color:blue; cursor:pointer; font-size:17px;" onclick="CKEDITOR.instances[Object.keys(CKEDITOR.instances)[0]].insertHtml('{fax}')">{fax}</span>
<span style="color:blue; cursor:pointer; font-size:17px;" onclick="CKEDITOR.instances[Object.keys(CKEDITOR.instances)[0]].insertHtml('{address}')">{address}</span>
<span style="color:blue; cursor:pointer; font-size:17px;" onclick="CKEDITOR.instances[Object.keys(CKEDITOR.instances)[0]].insertHtml('{address2}')">{address2}</span>
<span style="color:blue; cursor:pointer; font-size:17px;" onclick="CKEDITOR.instances[Object.keys(CKEDITOR.instances)[0]].insertHtml('{url}')">{url}</span><br>
<h2 style="font-weight: bold; margin:5px; margin-left:0px;">Appointment Time</h2>
<span style="color:blue; cursor:pointer; font-size:17px;" onclick="CKEDITOR.instances[Object.keys(CKEDITOR.instances)[0]].insertHtml('{time}')">{time}</span>
<h2 style="font-weight: bold; margin:5px; margin-left:0px;">Recipient Information</h2>
<span style="color:blue; cursor:pointer; font-size:17px;" onclick="CKEDITOR.instances[Object.keys(CKEDITOR.instances)[0]].insertHtml('{to:name}')">{to:name}</span>
<span style="color:blue; cursor:pointer; font-size:17px;" onclick="CKEDITOR.instances[Object.keys(CKEDITOR.instances)[0]].insertHtml('{to:email}')">{to:email}</span>
<h2  style="font-weight: bold; margin:5px; margin-left:0px;">Social Media</h2>
<span style="color:blue; cursor:pointer; font-size:17px;" onclick="CKEDITOR.instances[Object.keys(CKEDITOR.instances)[0]].insertHtml('{facebook}')">{facebook}</span>
<span style="color:blue; cursor:pointer; font-size:17px;" onclick="CKEDITOR.instances[Object.keys(CKEDITOR.instances)[0]].insertHtml('{twitter}')">{twitter}</span>
<span style="color:blue; cursor:pointer; font-size:17px;" onclick="CKEDITOR.instances[Object.keys(CKEDITOR.instances)[0]].insertHtml('{linkedin}')">{linkedin}</span>
<span style="color:blue; cursor:pointer; font-size:17px;" onclick="CKEDITOR.instances[Object.keys(CKEDITOR.instances)[0]].insertHtml('{google}')">{google}</span>
<span style="color:blue; cursor:pointer; font-size:17px;" onclick="CKEDITOR.instances[Object.keys(CKEDITOR.instances)[0]].insertHtml('{flickr}')">{flickr}</span>
<span style="color:blue; cursor:pointer; font-size:17px;" onclick="CKEDITOR.instances[Object.keys(CKEDITOR.instances)[0]].insertHtml('{rss}')">{rss}</span><br>
<span style="color:blue; cursor:pointer; font-size:17px;" onclick="CKEDITOR.instances[Object.keys(CKEDITOR.instances)[0]].insertHtml('{skype}')">{skype}</span>
<span style="color:blue; cursor:pointer; font-size:17px;" onclick="CKEDITOR.instances[Object.keys(CKEDITOR.instances)[0]].insertHtml('{yahoo}')">{yahoo}</span>
</div>
`;
CKEDITOR.dialog.add('fieldDialog', function (editor) {
    return {
        title: 'Fields Properties',
        minWidth: 400,
        minHeight: 200,
        maxWidth: 400,
        maxHeight: 200,
        contents: [
            {
                id: 'tab-basic',
                label: 'Basic Settings',
                elements: [
                    {
                        id: 'id1',
                        type: 'html',
                        html: htmlContent
                    }

                ]
            }
        ],
        buttons: [
            // CKEDITOR.dialog.okButton.override({ label: 'Close' }),
            // CKEDITOR.dialog.cancelButton.override({})
        ],
        onOk: function () {
            editor.insertHtml();
        },

    };
});
