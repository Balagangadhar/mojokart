import { Injectable } from '@angular/core';
import { SERVER_API_URL } from 'app/app.constants';
import { HttpResponse, HttpClient, HttpHeaders } from '@angular/common/http';
import { Observable } from 'rxjs';
import { ActivatedRoute } from '@angular/router';
type EntityArrayResponseType = HttpResponse<any>;

@Injectable({
    providedIn: 'root'
})
export class SubscriptionService {
    private requestUrl = SERVER_API_URL + 'api/campaigns/';
    constructor(private http: HttpClient, private route: ActivatedRoute) {}
    getSubscriberInfo(uuid: string, key: string): Observable<any> {
        const url = this.requestUrl + `${uuid}` + '/details?key=' + key;
        return this.http.get<any>(url);
    }
    doUnsubscribe(uuid: string, key: string, fromAll: Boolean): Observable<any> {
        const url = this.requestUrl + `${uuid}` + '/unsubscribe?key=' + key + '&fromAll=' + fromAll;
        // const headers = new HttpHeaders().set('Content-Type', 'text/plain; charset=utf-8');
        return this.http.post<any>(url, null, { responseType: 'text' as 'json' });
    }
}
