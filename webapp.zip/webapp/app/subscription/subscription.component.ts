import { Component, OnInit } from '@angular/core';
import { SubscriptionService } from './subscription.service';
import { ActivatedRoute } from '@angular/router';

@Component({
    selector: 'jhi-subscription',
    templateUrl: './subscription.component.html',
    styleUrls: ['./subscription.component.css']
})
export class SubscriptionComponent implements OnInit {
    unSubscribed: Boolean = false;
    email = '';
    senderName = '';
    responseData: any;
    allParams: any;
    uuid: string;
    key: string;
    fromAll: Boolean = false;
    getUrlInfo() {
        this.allParams = this.route.snapshot.params;
        this.uuid = this.route.snapshot.params['uuid']; // dynamic uuid
        this.key = this.route.snapshot.queryParams['key'];
        console.log(this.uuid, this.key);
    }
    constructor(private apiService: SubscriptionService, private route: ActivatedRoute) {
        this.getUrlInfo();
    }

    ngOnInit() {
        this.apiService.getSubscriberInfo(this.uuid, this.key).subscribe(data => {
            this.responseData = data;
            console.log(data);
            this.senderName = data.senderName;
            this.email = data.receiverEmail;
        });
    }
    onUnsubscribe() {
        console.log(this.unSubscribed);
        this.apiService.doUnsubscribe(this.uuid, this.key, this.fromAll).subscribe((data: any) => {
            console.log(JSON.stringify(data));
            this.unSubscribed = true;
        });
    }
}
