import { Component, Inject, AfterViewInit, OnInit } from '@angular/core';
import { ContactList } from './../../shared/model/contact-list.model';
import { ContactListService } from './../contact-list/contact-list.service';
import { MAT_DIALOG_DATA, MatDialogRef } from '@angular/material';
import { Contact } from 'app/shared/model/contact.model';
@Component({
    selector: 'jhi-save-list',
    templateUrl: 'jhi-save-list.html',
    styleUrls: ['./contact.component.css']
})
export class SaveListComponent implements OnInit {
    name: string;
    allListName: any;
    contactList: ContactList;
    selectedLevel;
    campaignSelected;

    constructor(
        public dialogRef: MatDialogRef<SaveListComponent>,
        @Inject(MAT_DIALOG_DATA) public data: Contact[],
        private apiListService: ContactListService
    ) {}
    ngOnInit(): void {
        this.apiListService.getAllLists().subscribe(data => {
            console.log(JSON.stringify(data.body));
            this.allListName = data.body;
        });
    }
    onNoClick(): void {
        this.dialogRef.close();
    }
    onUpdateExistingList() {
        this.apiListService.updateContactList(this.selectedLevel.id, this.data).subscribe(() => console.log('data updated succeffully'));
        this.onNoClick();
    }
}
