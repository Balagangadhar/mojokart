import { Component, OnInit, ViewChild, Inject, AfterViewInit, ElementRef, DoCheck, ViewEncapsulation } from '@angular/core';
import { OptIn, IOptIn } from './../../shared/model/opt-in-request.model';
import { ContactList } from './../../shared/model/contact-list.model';
import { FileUpload } from './../../shared/model/file-upload.model';
import { FileUploadComponent } from './file-upload.component';
import { ContactService } from './contact.service';
import { MatPaginator, MatSort, MatDialog, MatDialogRef, MAT_DIALOG_DATA } from '@angular/material';
import { SelectionModel } from '@angular/cdk/collections';
import { Contact } from '../../shared/model/contact.model';
import { DeleteContactComponent } from './delete-contact.component';
import { PendingOptInComponent } from './pending-opt-in.component';
import { SaveListComponent } from './save-list.component';
import { HttpClient } from '@angular/common/http';
import { merge, Observable, of as observableOf } from 'rxjs';
import { startWith, switchMap, map, catchError } from 'rxjs/operators';
import { FileUploader, FileSelectDirective } from 'ng2-file-upload/ng2-file-upload';
import { Account } from 'app/shared/model/account.model';
import { AccountService } from 'app/core';
import { Router } from '@angular/router';
import { LocalStorageService } from 'ngx-webstorage';
import { OptinAlertComponent } from './optin-alert/optin-alert.component';

@Component({
    selector: 'jhi-contact',
    templateUrl: './contact.component.html',
    styleUrls: ['./contact.component.css']
})
export class ContactComponent implements AfterViewInit, DoCheck {
    enableButton = true;
    currentAccount: Account;
    displayedColumns: string[] = ['select', 'name', 'email', 'phone', 'action'];
    apiService: ContactService | null;
    dataSource: Contact[] = [];
    contact;
    deleteAll: Boolean = false;
    resultsLength = 0;
    isLoadingResults = true;
    isRateLimitReached = false;
    // optinArray: OptIn[] = [];
    @ViewChild(MatPaginator) paginator: MatPaginator;
    @ViewChild(MatSort) sort: MatSort;
    public description = 'Add';
    contactApiResponse: any;
    selection = new SelectionModel<Contact>(true, []);
    searchText = '';
    @ViewChild('exportLink')
    exportLink: ElementRef;
    constructor(
        private localStorage: LocalStorageService,
        public router: Router,
        private accountService: AccountService,
        public dialog: MatDialog,
        private http: HttpClient
    ) {
        this.accountService.identity().then(account => {
            this.currentAccount = account;
        });
    }
    isAllSelected() {
        const numSelected = this.selection.selected.length;
        // console.log('....numSelected....', numSelected);
        const numRows = this.dataSource.length;
        // console.log('....numRows....', numRows);
        return numSelected === numRows;
    }
    masterToggle() {
        this.isAllSelected() ? this.selection.clear() : this.dataSource.forEach(row => this.selection.select(row));
    }
    ngAfterViewInit() {
        this.apiService = new ContactService(this.http);
        this.sort.sortChange.subscribe(() => (this.paginator.pageIndex = 0));
        merge(this.sort.sortChange, this.paginator.page)
            .pipe(
                startWith({}),
                switchMap(() => {
                    this.isLoadingResults = true;
                    return this.apiService!.getContacts(
                        this.sort.active,
                        this.sort.direction,
                        this.paginator.pageIndex,
                        this.paginator.pageSize,
                        this.searchText
                    );
                }),
                map(data => {
                    this.isLoadingResults = false;
                    this.isRateLimitReached = false;
                    this.resultsLength = data.headers.get('X-Total-Count');
                    return data;
                }),
                catchError(() => {
                    this.isLoadingResults = false;
                    this.isRateLimitReached = true;
                    return observableOf([]);
                })
            )
            .subscribe(data => {
                this.dataSource = data.body;
            });
    }
    addContact(): void {
        const dialogRef = this.dialog.open(ContactFormComponent, {
            width: 'auto',
            data: { contact: new Contact(), formType: 'Add' },
            disableClose: true
        });
        dialogRef.afterClosed().subscribe(result => {
            console.log('The dialog was closed......' + JSON.stringify(result));
            if (result) {
                if (result.phone) {
                    result.phone = result.phone.replace(/[' '()-\s]/g, '');
                }
                if (result.mobileNumber) {
                    result.mobileNumber = result.mobileNumber.replace(/[' '()-\s]/g, '');
                }
                this.apiService.create(result).subscribe(() => this.ngAfterViewInit());
            }
        });
    }
    // edit contact
    editContact(contact: Contact): void {
        const dialogRef = this.dialog.open(ContactFormComponent, {
            width: 'auto',
            data: { contact, formType: 'Update' },
            disableClose: true
        });
        // create button clicked
        dialogRef.afterClosed().subscribe(result => {
            console.log('The dialog was closed......' + JSON.stringify(result));
            if (result) {
                result.phone = result.phone.replace(/[' '()-\s]/g, '');
                result.mobileNumber = result.mobileNumber.replace(/[' '()-\s]/g, '');
                this.apiService.update(result).subscribe(() => this.ngAfterViewInit());
            }
            this.ngAfterViewInit();
        });
    }
    // Save As List
    saveListDialog(contact: Contact): void {
        const dialogRef1 = this.dialog.open(SaveListComponent, {
            width: 'auto',
            data: this.selection.selected
        });

        // create button clicked
        dialogRef1.afterClosed().subscribe(result => {
            console.log('The dialog was closed' + JSON.stringify(result));
            if (result) {
                const arr = new ContactList();
                arr.name = result;
                arr.companyId = this.currentAccount.companyId;
                arr.ownerId = this.currentAccount.id;
                arr.contacts = this.selection.selected;
                console.log(arr.contacts);
                console.log(this.selection.selected, arr);
                this.apiService.saveAsList(arr).subscribe(() => this.ngAfterViewInit());
            }
        });
    }
    // delete contact
    deleteByIdDialog(contact: Contact): void {
        const dialogRef2 = this.dialog.open(DeleteContactComponent, {
            width: 'auto',
            data: contact,
            disableClose: true
        });
        dialogRef2.afterClosed().subscribe(result => {
            if (result) {
                this.apiService.delete(result.id).subscribe(() => this.ngAfterViewInit());
            }
        });
    }
    deleteAllDialog(contacts: Contact[]): void {
        const dialogRef2 = this.dialog.open(DeleteContactComponent, {
            width: 'auto',
            data: contacts,
            disableClose: true
        });
        dialogRef2.afterClosed().subscribe(result => {
            console.log(result);
            if (result) {
                console.log(result);
                this.apiService.deleteAll(result).subscribe(() => this.ngAfterViewInit());
            }
        });
    }
    // file upload dialog
    fileUploadDilaog() {
        const dialogRef2 = this.dialog.open(FileUploadComponent, {
            width: 'auto',
            data: new FileUpload('', '', ''),
            disableClose: true
        });
        dialogRef2.afterClosed().subscribe(result => {
            this.ngAfterViewInit();
            console.log('The dialog was closed' + JSON.stringify(result));
            if (result) {
                console.log('Uploading..' + result);
            }
        });
    }
    onDelete(contact: Contact) {
        console.log(contact);
        this.deleteByIdDialog(contact);
    }
    onDeleteAll() {
        this.deleteAll = true;
        const contacts = this.selection.selected;
        this.deleteAllDialog(contacts);
    }

    async exportContacts() {
        let blob: Blob;
        if (this.selection.selected.length === 0) {
            blob = await this.apiService.exportContacts([]);
        } else {
            blob = await this.apiService.exportContacts(this.selection.selected);
        }
        const url = window.URL.createObjectURL(blob);
        const link = this.exportLink.nativeElement;
        link.href = url;
        link.download = 'contacts.csv';
        link.click();
        window.URL.revokeObjectURL(url);
    }

    applyFilter(searchText: string) {
        this.searchText = searchText;
        this.ngAfterViewInit();
    }

    optionAlertDialog(alertData: any) {
        const dialogRef2 = this.dialog.open(OptinAlertComponent, {
            width: '350px',
            height: '200px;',
            data: alertData
        });
        dialogRef2.afterClosed().subscribe(result => {
            console.log('The dialog was closed' + JSON.stringify(result));
            if (result) {
                console.log('optin alert..' + result);
            }
        });
    }
    // send pending request
    sendOptInRequest(): any {
        console.log('inside optIn send request');
        // this.optinArray = [];
        const selectedContacts = this.selection.selected;
        console.log('selectedContacts', selectedContacts);
        let requestOptin = true;
        this.selection.selected.forEach(contacts => {
            console.log('contacts....', contacts);
            if (contacts.phone === null || contacts.phone.length < 10) {
                this.optionAlertDialog('Please select the contacts with valid phone number to proceed.');
                requestOptin = false;
                return;
            } else if (contacts.allowOptInRequest === false) {
                this.optionAlertDialog('Selected contact ' + contacts.name + ' has already opted in contacts');
                requestOptin = false;
                return;
            }
            // else {
            //     const optinObj = new OptIn(contacts, null, null, null, null, null);
            //     this.optinArray.push(optinObj);
            // }
        });
        if (requestOptin === true) {
            // this.optionAlertDialog('Sent Succefully');
            console.log(this.selection.selected);
            this.apiService.createOptInRequest(this.selection.selected).subscribe(data => {
                console.log(data);
                // this.optionAlertDialog('Sent Successfully');
            });
        }
    }

    // view pending pop-up
    viewPendingRequest() {
        const optInDialogRef = this.dialog.open(PendingOptInComponent, {
            width: '70%',
            height: '400px',
            disableClose: true
            // data: contacts
        });
    }
    createCampaign() {
        const contactList = [];
        for (const contact of this.selection.selected) {
            const cont = new Contact();
            cont.id = contact.id;
            cont.name = contact.name;
            cont.email = contact.email;
            contactList.push(cont);
        }
        console.log('listOfContacts', contactList);
        this.localStorage.clear('listOfContacts');
        this.localStorage.store('listOfContacts', contactList);
        this.router.navigate(['/createCampaign'], { queryParams: { pageName: 'contactList' } });
    }
    // enable disable button for multiselection request
    ngDoCheck(): void {
        this.handleButton();
    }
    handleButton() {
        if (this.selection.selected.length < 1) {
            this.enableButton = true;
        } else {
            this.enableButton = false; // disable button
        }
    }
    closeDialog() {
        console.log('close dialog init');
        this.dialog.closeAll();
    }
}

@Component({
    selector: 'jhi-contact-form',
    templateUrl: 'jhi-contact-form.html',
    styleUrls: ['./contact.component.css']
})
export class ContactFormComponent implements OnInit {
    states: any;

    constructor(
        public dialogRef: MatDialogRef<ContactFormComponent>,
        @Inject(MAT_DIALOG_DATA) public data: any,
        private contactService: ContactService
    ) {}

    ngOnInit() {
        this.contactService.getStates().subscribe(results => {
            console.log(results);
            this.states = results;
        });
    }
    onNoClick(): void {
        this.dialogRef.close();
    }
    onSubmit(contact: any) {
        console.log('submitted data' + JSON.stringify(contact));
        this.dialogRef.close();
    }
}
