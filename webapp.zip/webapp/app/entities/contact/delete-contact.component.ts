import { Component, Inject } from '@angular/core';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material';

@Component({
    selector: 'jhi-delete-contact',
    templateUrl: 'jhi-delete-contact.html',
    styleUrls: ['./contact.component.css']
})
export class DeleteContactComponent {
    constructor(public dialogRef: MatDialogRef<DeleteContactComponent>, @Inject(MAT_DIALOG_DATA) public contact: any) {}

    onNoClick(): void {
        this.dialogRef.close();
    }
}
