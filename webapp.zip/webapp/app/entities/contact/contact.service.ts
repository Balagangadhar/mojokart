import { Injectable } from '@angular/core';
import { ContactList } from './../../shared/model/contact-list.model';
import { HttpClient, HttpResponse, HttpHeaders } from '@angular/common/http';
import { Observable, observable } from 'rxjs';
import { SERVER_API_URL } from 'app/app.constants';
import { Contact } from '../../shared/model/contact.model';
import { DomSanitizer } from '@angular/platform-browser';
import { OptIn } from 'app/shared/model/opt-in-request.model';
type EntityResponseType = HttpResponse<Contact>;
type EntityArrayResponseType = HttpResponse<Contact[]>;
@Injectable({
    providedIn: 'root'
})
export class ContactService {
    private resourceUrl = SERVER_API_URL + 'api/contacts';
    private requestResourceUrl = SERVER_API_URL + 'api/text-opt-in-requests';
    private statesUrl = SERVER_API_URL + 'api/states';

    constructor(private http: HttpClient) {}

    find(id: number): Observable<EntityResponseType> {
        return this.http.get<Contact>(`${this.resourceUrl}/${id}`, { observe: 'response' });
    }

    getContacts(sortParam: string, order: string, page: number, pageSize: number, searchText: string): Observable<any> {
        const requestUrl = `${this.resourceUrl}?page=${page}&size=${pageSize}&sort=${sortParam}%2C${order}&searchText=${searchText}`;
        return this.http.get<EntityArrayResponseType>(requestUrl, { observe: 'response' });
    }

    update(contact: Contact): Observable<any> {
        // this.http.put<Contact>(this.resourceUrl, contact).subscribe(data => console.log(JSON.stringify(data)));
        return this.http.put<Contact>(this.resourceUrl, contact);
    }

    create(contact: Contact): Observable<any> {
        // this.http.post<Contact>(this.resourceUrl, contact).subscribe(data => console.log(JSON.stringify(data)));
        return this.http.post<Contact>(this.resourceUrl, contact);
    }

    delete(id: number): Observable<any> {
        console.log(this.resourceUrl + '/' + id);
        return this.http.delete<any>(this.resourceUrl + '/' + id);
    }
    deleteAll(contacts: Contact[]): Observable<any> {
        let ids = '';
        contacts.forEach(element => {
            ids = element.id + ',' + ids;
        });
        ids = ids.slice(0, ids.length - 1);
        const url = this.resourceUrl + '?ids=' + ids;
        return this.http.delete<any>(url);
    }

    saveAsList(list: ContactList): Observable<any> {
        const url = SERVER_API_URL + 'api/contact-lists';
        console.log(url);
        // this.http.post<ContactList>(url, list).subscribe(data => console.log(JSON.stringify(data)));
        return this.http.post<ContactList>(url, list);
    }

    fileUpload(fromData: FormData): Observable<any> {
        // this.http.post<any>(this.resourceUrl, fromData).subscribe(data => console.log(data));
        return this.http.post<any>(this.resourceUrl, fromData);
    }

    async exportContacts(contacts: Contact[]) {
        return await this.http.post<Blob>(this.resourceUrl + '/export', contacts, { responseType: 'blob' as 'json' }).toPromise();
    }

    createOptInRequest(contacts: Contact[]): Observable<Contact[]> {
        return this.http.post<Contact[]>(this.requestResourceUrl, contacts, { headers: new HttpHeaders() });
    }
    pendingOptinContacts(): Observable<any> {
        const requestUrl = this.requestResourceUrl + '/pending';
        return this.http.get<OptIn[]>(requestUrl, { observe: 'response' });
    }
    getOptedInContact(sortParam: string, order: string, page: number, pageSize: number, searchText: string): Observable<any> {
        const requestUrl = `${
            this.resourceUrl
        }/opted-in?page=${page}&size=${pageSize}&sort=${sortParam}%2C${order}&searchText=${searchText}`;
        return this.http.get<EntityArrayResponseType>(requestUrl, { observe: 'response' });
    }
    deleteOptedInContact(id: number): Observable<any> {
        return this.http.delete<any>(this.requestResourceUrl + '/' + id);
    }
    resendOptinRequest(optin: OptIn): Observable<OptIn> {
        const optinArray = [];
        optinArray.push(optin);
        return this.http.post<OptIn>(this.requestResourceUrl + '/resend', optinArray, { headers: new HttpHeaders() });
    }
    deleteOptinRequest(id: number): Observable<any> {
        return this.http.delete<any>(this.requestResourceUrl + '/' + id);
    }
    getStates() {
        return this.http.get<any>(this.statesUrl);
    }
}
