import { Component, Inject, OnInit, ViewChild } from '@angular/core';
import { ContactService } from './contact.service';

import { MAT_DIALOG_DATA, MatDialogRef } from '@angular/material';
import { FileUpload } from 'app/shared/model/file-upload.model';
import { UploadFieldComponent } from './upload.component';
import { SERVER_API_URL } from 'app/app.constants';
import { HttpClient } from '@angular/common/http';

@Component({
    selector: 'jhi-file-upload',
    templateUrl: 'jhi-file-upload.html',
    styleUrls: ['./contact.component.css']
})
export class FileUploadComponent implements OnInit {
    public resourceUrl: any = SERVER_API_URL + 'api/contacts/import';
    selectedFile: File = null;
    @ViewChild(UploadFieldComponent) public uploadField: UploadFieldComponent;
    constructor(
        private contactService: ContactService,
        public dialogRef: MatDialogRef<FileUploadComponent>,
        @Inject(MAT_DIALOG_DATA) public fileUpload: FileUpload
    ) {}
    ngOnInit() {}
    onFileSelected(event) {
        console.log(event);
        this.selectedFile = <File>event.target.files[0];
    }
    onUpload() {
        console.log('uploading...files');
        const fd = new FormData();
        fd.append('image', this.selectedFile, this.selectedFile.name);
        this.contactService.fileUpload(fd);
    }
    uploadComplete(event) {
        console.log(event);
        this.dialogRef.close();
    }
}
