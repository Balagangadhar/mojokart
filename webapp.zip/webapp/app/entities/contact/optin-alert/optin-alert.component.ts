import { Component, OnInit, Inject } from '@angular/core';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material';

@Component({
    selector: 'jhi-optin-alert',
    templateUrl: './optin-alert.component.html',
    styles: []
})
export class OptinAlertComponent implements OnInit {
    constructor(public dialogRef: MatDialogRef<OptinAlertComponent>, @Inject(MAT_DIALOG_DATA) public data: any) {}

    ngOnInit() {}
}
