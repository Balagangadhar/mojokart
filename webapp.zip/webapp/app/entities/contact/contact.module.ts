import { NgModule, CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { FileUploadComponent } from './file-upload.component';
import { CommonModule } from '@angular/common';
import { MaterialModule } from './../material.module';
import { FormsModule } from '@angular/forms';
import { RouterModule } from '@angular/router';
import { ContactComponent, ContactFormComponent, contactRoutes } from './';
import { DeleteContactComponent } from './delete-contact.component';
import { MAT_DIALOG_DATA, MatDialogRef } from '@angular/material/dialog';
import { SaveListComponent } from './save-list.component';
import { FormatPhoneNumberPipe } from './format-phone-number.pipe';
import { UploadFieldComponent } from './upload.component';
import { FileUploadModule } from 'ng2-file-upload';
import { SharedCommonModule } from '../../shared/shared-common.module';
import { PendingOptInComponent } from './pending-opt-in.component';
import { OptinAlertComponent } from './optin-alert/optin-alert.component';
import { CustomDatePipe } from './custom-date.pipe';

const ENTITY_STATES = [...contactRoutes];

@NgModule({
    imports: [SharedCommonModule, MaterialModule, CommonModule, FileUploadModule, FormsModule, RouterModule.forChild(ENTITY_STATES)],
    declarations: [
        ContactComponent,
        ContactFormComponent,
        DeleteContactComponent,
        SaveListComponent,
        FileUploadComponent,
        FormatPhoneNumberPipe,
        UploadFieldComponent,
        PendingOptInComponent,
        OptinAlertComponent,
        CustomDatePipe
    ],
    exports: [SharedCommonModule],
    entryComponents: [
        ContactComponent,
        ContactFormComponent,
        DeleteContactComponent,
        SaveListComponent,
        FileUploadComponent,
        PendingOptInComponent,
        OptinAlertComponent
    ],
    schemas: [CUSTOM_ELEMENTS_SCHEMA],
    providers: [{ provide: MAT_DIALOG_DATA, useValue: {} }, { provide: MatDialogRef, useValue: {} }]
})
export class ContactModule {}
