import { Component, OnInit, Inject, AfterViewInit, ViewChild } from '@angular/core';
import { OptIn } from './../../shared/model/opt-in-request.model';
import { MAT_DIALOG_DATA, MatDialogRef } from '@angular/material';
import { SelectionModel } from '@angular/cdk/collections';
import { MatPaginator, MatSort, MatDialog } from '@angular/material';
import { HttpClient } from '@angular/common/http';
import { merge, Observable, of as observableOf } from 'rxjs';
import { startWith, switchMap, map, catchError } from 'rxjs/operators';
import { ContactService } from 'app/entities/contact';

@Component({
    selector: 'jhi-pending-opt-in',
    templateUrl: './pending-opt-in.component.html',
    styleUrls: ['./pending-opt-in.component.css']
})
export class PendingOptInComponent implements AfterViewInit {
    @ViewChild(MatPaginator) paginator!: MatPaginator;
    @ViewChild(MatSort) sort!: MatSort;
    displayedColumns = ['name', 'phone', 'request-1', 'request-2', 'request-3', 'action'];
    apiService: ContactService | null;
    dataSource: OptIn[] = [];
    resultsLength = 0;
    isLoadingResults = true;
    isRateLimitReached = false;
    selection = new SelectionModel<OptIn>(true, []);

    constructor(
        public dialogRef: MatDialogRef<PendingOptInComponent>,
        @Inject(MAT_DIALOG_DATA) public data: any,
        private http: HttpClient
    ) {}

    isAllSelected() {
        const numSelected = this.selection.selected.length;
        const numRows = this.dataSource.length;
        return numSelected === numRows;
    }

    masterToggle() {
        this.isAllSelected() ? this.selection.clear() : this.dataSource.forEach(row => this.selection.select(row));
    }

    ngAfterViewInit() {
        this.contactTable();
    }

    contactTable() {
        this.apiService = new ContactService(this.http);
        merge()
            .pipe(
                startWith({}),
                switchMap(() => {
                    this.isLoadingResults = true;
                    return this.apiService.pendingOptinContacts();
                }),
                map(data => {
                    this.isLoadingResults = false;
                    this.isRateLimitReached = false;
                    return data;
                }),
                catchError(() => {
                    this.isLoadingResults = false;
                    this.isRateLimitReached = true;
                    return observableOf([]);
                })
            )
            .subscribe(data => {
                this.dataSource = data.body;
            });
    }

    onResend(optin: OptIn) {
        this.apiService.resendOptinRequest(optin).subscribe(res => {
            optin.req1Date = res[0].req1Date;
            optin.req2Date = res[0].req2Date;
            optin.req3Date = res[0].req3Date;
        });
    }

    onDelete(id: number) {
        this.apiService.deleteOptinRequest(id).subscribe(data => this.ngAfterViewInit());
    }
}
