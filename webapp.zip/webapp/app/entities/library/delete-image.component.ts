import { Component, Input } from '@angular/core';
import { NgbActiveModal } from '@ng-bootstrap/ng-bootstrap';
import { LibraryService } from './library.service';

@Component({
    selector: 'jhi-delete-image',
    templateUrl: './delete-image.component.html',
    styles: []
})
export class DeleteImageComponent {
    @Input() seletedImage;

    constructor(private _libraryService: LibraryService, public activeModal: NgbActiveModal) {}

    deleteImage() {
        this._libraryService.deleteLibrary(this.seletedImage).subscribe(
            () => {
                this.activeModal.dismiss('delete');
            },
            () => {
                this.activeModal.dismiss('delete');
            }
        );
    }
}
