import { Injectable } from '@angular/core';
import { Resolve, ActivatedRouteSnapshot, RouterStateSnapshot, Routes, RouterModule } from '@angular/router';
import { HttpResponse } from '@angular/common/http';
import { Observable, of } from 'rxjs';
import { filter, map } from 'rxjs/operators';
import { UserRouteAccessService } from 'app/core';
import { JhiResolvePagingParams } from 'ng-jhipster';
import { LibraryComponent } from './library.component';
import { ITemplate, Template } from 'app/shared/model/template.model';
import { TemplateService } from '../template/template.service';

export const libraryRoutes: Routes = [
    {
        path: 'library',
        component: LibraryComponent,
        resolve: {
            pagingParams: JhiResolvePagingParams
        },
        data: {
            authorities: ['ROLE_USER'],
            defaultSort: 'id,asc',
            pageTitle: 'Library'
        },
        canActivate: [UserRouteAccessService]
    }
];

@Injectable({ providedIn: 'root' })
export class TemplateResolve implements Resolve<ITemplate> {
    constructor(private service: TemplateService) {}

    resolve(route: ActivatedRouteSnapshot, state: RouterStateSnapshot): Observable<Template> {
        const id = route.params['id'] ? route.params['id'] : null;
        if (id) {
            return this.service.find(id).pipe(
                filter((response: HttpResponse<Template>) => response.ok),
                map((contactList: HttpResponse<Template>) => contactList.body)
            );
        }
        // return of(new Template());
    }
}
