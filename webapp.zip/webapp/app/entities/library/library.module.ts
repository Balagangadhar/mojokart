import { LibraryComponent } from './library.component';
import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { RouterModule } from '@angular/router';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { NgbModule } from '@ng-bootstrap/ng-bootstrap';
import { libraryRoutes } from './library.route';
import { LibraryFilter } from './library-filter.pipe';
import { FileUploadModule } from 'ng2-file-upload';
import { SharedCommonModule } from '../../shared/shared-common.module';
import { DeleteImageComponent } from './delete-image.component';
import { DeleteLibraryImageFolderComponent } from './delete-library-image-folder.component';
import { MatPaginatorModule } from '@angular/material';
const ENTITY_STATES = [...libraryRoutes];

@NgModule({
    declarations: [LibraryComponent, LibraryFilter, DeleteImageComponent, DeleteLibraryImageFolderComponent],
    imports: [
        BrowserAnimationsModule,
        CommonModule,
        FormsModule,
        ReactiveFormsModule,
        NgbModule,
        FileUploadModule,
        SharedCommonModule,
        MatPaginatorModule,
        RouterModule.forChild(ENTITY_STATES)
    ],
    exports: [SharedCommonModule],
    providers: [],
    entryComponents: [DeleteImageComponent, DeleteLibraryImageFolderComponent]
})
export class LibraryModule {}
