import { Component, Input } from '@angular/core';
import { NgbActiveModal } from '@ng-bootstrap/ng-bootstrap';
import { LibraryService } from './library.service';

@Component({
    selector: 'jhi-delete-library-image-folder',
    templateUrl: './delete-library-image-folder.component.html',
    styles: []
})
export class DeleteLibraryImageFolderComponent {
    @Input() selectedLibraryFolderId;

    constructor(private _libraryService: LibraryService, public activeModal: NgbActiveModal) {}

    deleteLibraryFolder() {
        this._libraryService.deleteLibraryFolder(this.selectedLibraryFolderId).subscribe(
            () => {
                this.activeModal.dismiss('delete');
            },
            () => {
                this.activeModal.dismiss('delete');
            }
        );
    }
}
