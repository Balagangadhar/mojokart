import { Component, OnInit, ViewChild, ElementRef, DoCheck, AfterViewInit, ChangeDetectorRef } from '@angular/core';
import { NgbModal } from '@ng-bootstrap/ng-bootstrap';
import { FileUploader, FileItem, FileLikeObject } from 'ng2-file-upload';
import { SERVER_API_URL } from 'app/app.constants';
import { LocalStorageService, SessionStorageService } from 'ngx-webstorage';
import { LibraryService } from './library.service';
import { AccountService } from '../../core/auth/account.service';
import { Observable } from 'rxjs';
import { Blob, IBlob } from 'app/shared/model/blob.model';
import { Router, ActivatedRoute } from '@angular/router';
import { TemplateService } from '../template/template.service';
import { ITemplate, Template } from '../../shared/model/template.model';
import { Account } from 'app/shared/model/account.model';
import { parseIntAutoRadix } from '@angular/common/src/i18n/format_number';
import { isBoolean } from 'util';
import { CommonUtil } from '../../shared/util/common-util';
import { DeleteImageComponent } from './delete-image.component';
import { DeleteLibraryImageFolderComponent } from './delete-library-image-folder.component';
import { USER_TYPE, CONTENT_TYPE } from '../../shared/model/subgroup.model';
import { MatPaginator } from '@angular/material';
import { map } from 'rxjs/operators';
@Component({
    selector: 'jhi-library',
    templateUrl: './library.component.html',
    styleUrls: ['./library.component.css']
})
export class LibraryComponent implements OnInit, DoCheck, AfterViewInit {
    @ViewChild(MatPaginator) paginator: MatPaginator;
    pageIndex = 0;
    lowValue = 0;
    highValue = 50;
    length = 1000;
    pageSize = 25;
    pageSizeOptions: number[] = [10, 25, 50, 100];

    isAdmin: boolean;
    templateType: string;
    checkBoxSelected = 1;
    templateData: Template;
    selectedImageId: number;
    attachmentId: number;
    queryParamTempId: number;
    subGrpId: number;
    deletePhotos = true;
    checkBoxCounter = false;
    addToTemplate = true;
    selectedImagesArray = [];
    tabNameFromTemplate: '';
    bannerResponse: any;
    stockImageResponse: any;
    currentImageUrl: string;
    public url: string;
    public imageUplodaUrl = SERVER_API_URL + 'api/blobs?type=IMAGE';
    public bannerURL: string = SERVER_API_URL + 'api/blobs?type=BANNER';
    public stockPhotosURL: string = SERVER_API_URL + 'api/blobs?type=STOCK_IMAGE';
    public companyImageURL: string = SERVER_API_URL + 'api/blobs?type=COMPANY_IMAGE';
    public signatureResourceUrl: string = SERVER_API_URL + 'api/blobs?type=EMAIL_SIGNATURE_IMAGE';
    public accept: Array<string> = ['image/gif', 'image/jpeg', 'image/jpg', 'image/bmp'];
    public maxFileSize: number = 10 * 1024 * 1024; // 10MB
    public maxFile: any = 5; // Default 0 is unlimited
    public multiple: any = true; // Default false is single file, true is multiple file
    public errorMessageMaxSize: any = "'File size shouldn't exceeded more than 10MB'";
    public errorMessageWrongType: any = "'Not allow file format'";
    public invalidFileType: any = "'Accepted file formats are JPG/PNG/JPEG'";
    public errorMessageLimit: any = "'Maximum files'";
    public token: string;
    public errorMessage: any = '';
    public uploader: FileUploader = new FileUploader({});
    currentAccount: Account;
    updateTemplateData: Template;
    selectedAttachment: any = [];
    blob: any;
    selectedImages: string;
    isBanner: any;
    isStockImages: any;
    userUploadedImages: any = [];
    userSignImages: any = [];
    bannerCount: number;
    attachmentCount: number;
    tempObj: any;
    @ViewChild('tab') tab;
    pageName: string;
    templateAction: string;
    isTemplateSelected: boolean;
    isMyImages: boolean;
    isSignImages: boolean;
    isCompanyImages: boolean;
    isOrgImages: any;
    imageFolders: any;
    companyImages: any;
    isUploadBtnAvailable: boolean;
    contentType = 'BANNER';
    payload: any;
    subFolderImages: any;
    categoryName: string;
    subCategoryName: string;
    isSubcategory: boolean;
    selectedSubcatId: number;
    isPriviliged: boolean;
    contextmenu = false;
    contextmenuX = 0;
    contextmenuY = 0;
    selectedFolder: any;
    folderOption: string;
    newFolderText: string;
    pageTotalNum = 0;
    constructor(
        private _templateService: TemplateService,
        private modalService: NgbModal,
        private localStorage: LocalStorageService,
        private sessionStorage: SessionStorageService,
        private _libraryService: LibraryService,
        public router: Router,
        private route: ActivatedRoute,
        public _accountService: AccountService,
        private commonUtil: CommonUtil,
        private cdr: ChangeDetectorRef
    ) {}
    getBannerImages() {
        this.getExistingImageFolders(CONTENT_TYPE.BANNER, USER_TYPE.ROLE_ADMIN);
        // this._libraryService.getBannerImages().subscribe((response: IBlob[]) => {
        //     this.bannerResponse = response;
        //     this.bannerCount = this.bannerResponse.length;
        // });
    }
    getStockImages() {
        this.getExistingImageFolders(CONTENT_TYPE.STOCK_IMAGE, USER_TYPE.ROLE_ADMIN);
        // this._libraryService.getStockImages().subscribe((response: IBlob[]) => {
        //     this.stockImageResponse = response;
        //     this.attachmentCount = this.stockImageResponse.length;
        //     this.deletePhotos = true;
        // });
    }
    getComapnyImages() {
        // console.log(' getComapnyImages ', this._accountService['userIdentity'].authorities);
        // console.log('Admin -> ', this._accountService['userIdentity'].authorities.includes('ROLE_COMPANY_ADMIN'));
        // this._libraryService.getCompanyImages('ALL', 'COMPANY').subscribe((response: IBlob[]) => {
        //     this.companyImages = response;
        // });
        this.getExistingImageFolders(CONTENT_TYPE.ALL, USER_TYPE.ROLE_COMPANY_ADMIN);
    }
    getExistingImageFolders(contentType, type) {
        this._libraryService.getImageFolders(contentType, type).subscribe((response: IBlob[]) => {
            this.subFolderImages = [];
            this.subCategoryName = '';
            this.subFolderImages = '';
            this.isSubcategory = false;
            this.selectedSubcatId = 0;
            this.imageFolders = response;
        });
    }

    checkUserRole(currentRole) {
        // console.log (this._accountService.hasAuthority(currentRole) );
        return this._accountService['userIdentity'].authorities.includes(currentRole);
    }
    getSignatureImages() {
        console.log(this.contentType, '1', CONTENT_TYPE.SIGN_IMAGE);
        this._libraryService
            .getSignImages(this.pageSize, this.pageIndex)
            .pipe(
                map(data => {
                    if (data && data.headers) {
                        this.pageTotalNum = data.headers.get('X-Total-Count') ? data.headers.get('X-Total-Count') : 0;
                    }
                    return data;
                })
            )
            .subscribe((response: IBlob[]) => {
                this.userSignImages = response;
                console.log(response);
                this.deletePhotos = true;
            });
    }
    getUserUploadedImages() {
        console.log(this.contentType, '1', CONTENT_TYPE.IMAGE);
        this._libraryService
            .getUserImages(this.pageSize, this.pageIndex)
            .pipe(
                map(data => {
                    this.pageTotalNum = data.headers.get('X-Total-Count') ? data.headers.get('X-Total-Count') : 0;
                    console.log(data.headers.get('X-Total-Count'), data.toString());
                    return data;
                })
            )
            .subscribe((response: IBlob[]) => {
                this.userUploadedImages = response;
                console.log(response);
                this.deletePhotos = true;
                // this.userImages = this.stockImageResponse.length;
            });
    }

    fetchImagesByFolderId(obj) {
        let lType = CONTENT_TYPE.IMAGE;
        console.log('3', lType);
        if (this.tab.activeId === 'tab-1') {
            lType = CONTENT_TYPE.BANNER;
        } else if (this.tab.activeId === 'tab-2') {
            lType = CONTENT_TYPE.STOCK_IMAGE;
        } else if (this.tab.activeId === 'tab-4') {
            lType = CONTENT_TYPE.COMPANY_IMAGE;
        }
        this.selectedSubcatId = obj.id;
        this._libraryService
            .getImagesByFolderId(obj.id, lType, this.pageSize, this.pageIndex)
            .pipe(
                map(data => {
                    this.pageTotalNum = data.headers.get('X-Total-Count') ? data.headers.get('X-Total-Count') : 0;
                    console.log(data.headers.get('X-Total-Count'), data.toString());
                    return data;
                })
            )
            .subscribe((response: IBlob[]) => {
                this.imageFolders = [];
                this.subFolderImages = [];
                this.isSubcategory = true;
                if (this.contentType === CONTENT_TYPE.BANNER) {
                    this.subCategoryName = obj.name;
                    this.subFolderImages = response;
                    this.cdr.detectChanges();
                    // this.paginator = response;
                    // this.bannerResponse = [];
                } else if (this.contentType === CONTENT_TYPE.STOCK_IMAGE) {
                    this.subCategoryName = obj.name;
                    this.subFolderImages = response;
                    // this.stockImageResponse = [];
                    // this.attachmentCount = this.stockImageResponse.length || 0;
                    // this.deletePhotos = true;
                } else if (this.contentType === CONTENT_TYPE.ALL) {
                    this.subCategoryName = obj.name;
                    this.subFolderImages = response;
                } else if (this.contentType === CONTENT_TYPE.IMAGE) {
                    this.subFolderImages = response;
                    // this.deletePhotos = true;
                }
            });
    }
    getPaginatorData(event) {
        console.log(event);
        if (event.pageSize !== this.pageSize) {
            this.pageSize = event.pageSize;
            // setTimeout( () => this.fetchImagesByFolderId({ id: this.selectedSubcatId, name: this.subCategoryName }), 200);
        }
        if (event.pageIndex === this.pageIndex + 1) {
            // this.lowValue = this.lowValue + this.pageSize;
            // this.highValue =  this.highValue + this.pageSize;
            this.pageIndex = this.pageIndex + 1;
            // setTimeout( () => this.fetchImagesByFolderId({ id: this.selectedSubcatId, name: this.subCategoryName }), 200);
        } else if (event.pageIndex === this.pageIndex - 1) {
            // this.lowValue = this.lowValue - this.pageSize;
            // this.highValue =  this.highValue - this.pageSize;
            this.pageIndex = this.pageIndex - 1;
            // setTimeout( () => this.getUserUploadedImages(), 200);
        }
        if (this.contentType === 'IMAGE') {
            this.getUserUploadedImages();
        } else {
            setTimeout(() => this.fetchImagesByFolderId({ id: this.selectedSubcatId, name: this.subCategoryName }), 200);
        }
    }
    openVerticallyCentered(content) {
        this.modalService.open(content, this.commonUtil.getModalPopUpSettings());
    }
    createNewFolderModal(folder) {
        this.folderOption = 'create';
        this.modalService.open(folder, this.commonUtil.getModalPopUpSettings());
    }
    renameFolder(folder) {
        this.folderOption = 'rename';
        this.newFolderText = '';
        this.disableContextMenu();
        this.modalService.open(folder, this.commonUtil.getModalPopUpSettings());
    }
    deleteFolder() {
        if (this.selectedFolder.id) {
            this.disableContextMenu();
            const deleteLibraryFolder = this.modalService.open(DeleteLibraryImageFolderComponent, this.commonUtil.getModalPopUpSettings());
            deleteLibraryFolder.componentInstance.selectedLibraryFolderId = this.selectedFolder.id;
            deleteLibraryFolder.result.then(
                result => {
                    console.log('result delete ', result);
                },
                reason => {
                    if (reason === 'delete') {
                        this.isSubcategory
                            ? this.fetchImagesByFolderId({ id: this.selectedSubcatId, name: this.contentType })
                            : this.reloadData();
                    }
                }
            );
        }
    }
    onCreateNewFolder(value) {
        console.log(value, 'folder');
        if (this.folderOption === 'create') {
            this.payload = { contentType: this.contentType, name: value, type: this.getType() };
            this._libraryService.createNewFolder(this.payload).subscribe(res => {
                console.log(res);
                this.modalService.dismissAll();
                this.reloadData();
            });
        } else {
            if (value) {
                this.selectedFolder.name = value;
                this._libraryService.renameFolder(this.selectedFolder).subscribe(res => {
                    console.log(res);
                    this.closeUploadPopUp();
                });
            }
            console.log('rename', this.selectedFolder);
        }
    }
    getType() {
        let lRole: string;
        if (this.checkUserRole('ROLE_ADMIN')) {
            lRole = USER_TYPE.ROLE_ADMIN;
        } else if (this.checkUserRole('ROLE_COMPANY_ADMIN')) {
            lRole = USER_TYPE.ROLE_COMPANY_ADMIN;
        } else {
            lRole = USER_TYPE.ROLE_USER;
        }
        return lRole;
    }
    onImageChecked(imageid: number, e, imageURL) {
        this.currentImageUrl = imageURL;
        this.selectedImageId = imageid;
        if (this.router.url === '/library') {
            if (e.target.checked) {
                this.deletePhotos = false;
                this.addToTemplate = false;
                this.selectedImagesArray.push(imageid);
            } else {
                this.checkBoxCounter = false;
                const index = this.selectedImagesArray.findIndex(imageId => imageid === imageId);
                this.selectedImagesArray.splice(index, 1);
                this.deletePhotos = this.selectedImagesArray.length > 0 ? false : true;
            }
        } else {
            if (this.pageName === 'templatePage' && this.isStockImages === 'true' && e.target.checked) {
                console.log('when attachment');
                this.deletePhotos = true;
                this.addToTemplate = false;
                this.selectedImagesArray.push(imageURL);
            } else {
                this.checkBoxCounter = false;
                const index = this.selectedImagesArray.findIndex(url => url === imageURL);
                this.selectedImagesArray.splice(index, 1);
            }
        }
        if (this.pageName === 'templatePage' && this.isBanner === 'true') {
            console.log('when banner');
            this.checkBoxSelected = imageid;
            console.log('this.checkBoxSelected', this.checkBoxSelected);
            this.selectedImageId = imageid;
            console.log('this.selectedImageId', this.selectedImageId);
            this.deletePhotos = true;
            if (e.target.checked) {
                this.addToTemplate = false;
            } else {
                this.addToTemplate = true;
            }
        }
        console.log('inside function selct', this.selectedImagesArray);
    }
    addImageToTemplate() {
        if (this.tab.activeId === 'tab-1') {
            this._templateService.find(this.queryParamTempId).subscribe((response: any) => {
                this.templateData = response.body;
                console.log('temp to lib.....', this.templateData);
                const blob = {} as Blob;
                blob.id = this.selectedImageId;
                this.templateData.banner = blob;
                this._templateService.update(this.templateData, this.subGrpId).subscribe((templateResponse: any) => {
                    console.log('...templateResponse..!!', templateResponse);
                    this.router.navigate(['/template'], {
                        queryParams: {
                            pageName: 'libraryPage',
                            tempId: this.queryParamTempId,
                            templateAction: this.templateAction,
                            isTemplateSelected: this.isTemplateSelected,
                            tabNameFromLibrary: this.tabNameFromTemplate,
                            subGroup: this.subGrpId
                        }
                    });
                });
            });
        } else if (this.tab.activeId === 'tab-2') {
            this._templateService.find(this.queryParamTempId).subscribe((response: any) => {
                this.templateData = response.body;
                let textContent = response.body.content;
                this.selectedImagesArray.forEach(element => {
                    //  this.blob = {};
                    //  this.blob.id = element;
                    //  this.selectedAttachment.push(this.blob);
                    const imageContent = '<p> <img src="' + element + '"></p>';
                    textContent = textContent + imageContent;
                    // this.templateData.attachments = this.selectedAttachment;
                    // this.templateData.content = this.templateData.content +
                });
                this.templateData.content = textContent;
                this._templateService.update(this.templateData).subscribe((libraryTemplateResponse: any) => {
                    console.log('libraryTemplateResponse', libraryTemplateResponse);
                    this.router.navigate(['/template'], {
                        queryParams: {
                            pageName: 'libraryPage',
                            tempId: this.queryParamTempId,
                            templateAction: this.templateAction,
                            isTemplateSelected: this.isTemplateSelected,
                            tabNameFromLibrary: this.tabNameFromTemplate
                        }
                    });
                });
            });
        }
    }
    deleteImages() {
        this.selectedImages = this.selectedImagesArray.toString();
        console.log('this.selectedBanners...string', this.selectedImages);
        const deleteImage = this.modalService.open(DeleteImageComponent, this.commonUtil.getModalPopUpSettings());
        deleteImage.componentInstance.seletedImage = this.selectedImages;
        deleteImage.result.then(
            result => {
                this.selectedImagesArray = [];
            },
            reason => {
                if (reason === 'delete') {
                    this.selectedImagesArray = [];
                    this.isSubcategory
                        ? this.fetchImagesByFolderId({ id: this.selectedSubcatId, name: this.subCategoryName })
                        : this.reloadData();
                }
            }
        );
    }
    closeUploadPopUp() {
        this.errorMessage = '';
        this.uploader.clearQueue();
        this.ngDoCheck();
        this.modalService.dismissAll();
        // this.ngDoCheck();
    }
    /**
     * Check file is image
     *
     * @param {*} fileType
     * @returns {boolean}
     */
    public isImage(fileType: any): boolean {
        return /^image\/(.*)$/.test(fileType);
    }

    /**
     * Check max file
     *
     * @returns {boolean}
     */
    public isMaxFile(): boolean {
        if (this.maxFile === 0) {
            return false;
        }
        return this.uploader.queue.length >= this.maxFile;
    }

    /**
     * Remove file item
     *
     * @param {FileItem} item
     */
    public removeItem(item: FileItem): void {
        item.remove();
        // this.fileInput.nativeElement.value = '';
        // this.onItemChanged.emit(this.getQueueFiles());
    }

    /**
     * Get queue files
     *
     * @returns {*}
     */
    public getQueueFiles(): Array<any> {
        return this.uploader.queue;
        console.log('this.uploader.queue...1111.', this.uploader.queue);
    }

    /**
     * Set queue files
     *
     * @returns {*}
     */
    public setQueueFiles(queue: Array<any>): void {
        this.uploader.queue = queue;
    }

    /**
     * Get all files in queue
     *
     * @returns {*}
     */
    public getFiles(): Array<any> {
        return this.uploader.queue.map(item => item.file);
    }

    /**
     * Add file failed hanlde
     *
     * @private
     * @param {FileLikeObject} item
     * @param {*} filter
     * @param {*} options
     */
    private onWhenAddingFileFailed(item: FileLikeObject, filter: any, options: any) {
        //  this.errorMessageMaxSize = '';
        switch (filter.name) {
            case 'fileSize': {
                this.errorMessage = this.errorMessageMaxSize;
                break;
            }
            case 'mimeType': {
                this.errorMessage = this.errorMessageWrongType;
                break;
            }
            default:
        }
    }

    /**
     * Handle choice files
     *
     * @private
     * @param {*} items
     */
    private onAfterAddingAll(items: any) {
        if (items.length > this.maxFile) {
            this.uploader.clearQueue();
            // this.fileInput.nativeElement.value = '';
            this.errorMessage = this.errorMessageLimit;
            //  this.onItemChanged.emit(this.getQueueFiles());
            return;
        }
    }

    /**
     * Handle add file
     *
     * @private
     * @param {*} item
     */
    private onAfterAddingFile(item: any) {
        if (!this.isImage(item.file.type)) {
            this.errorMessage = this.invalidFileType;
            item.remove();
            return;
        }
        this.errorMessage = '';
        if (this.checkDuplicateFiles(item)) {
            item.remove();
            //  this.onItemChanged.emit(this.getQueueFiles());
        }
    }

    /**
     * Check duplicate file
     *
     * @private
     * @param {*} item
     * @returns {boolean}
     */
    private checkDuplicateFiles(item: any): boolean {
        let checkItem: any = 0;
        this.uploader.queue.map(itemQueue => {
            checkItem += itemQueue.file.name === item.file.name && itemQueue.file.size === item.file.size ? 1 : 0;
        });

        return checkItem > 1;
    }
    ngOnInit() {
        this.getBannerImages();
        // this.getStockImages();
        // this.getUserUploadedImages();
        // this.getComapnyImages();
        this.getSignatureImages();
        this.queryParamTempId = this.route.snapshot.queryParams['tempId'];
        this.pageName = this.route.snapshot.queryParams['pageName'];
        this.isBanner = this.route.snapshot.queryParams['isBanner'];
        this.templateType = this.route.snapshot.queryParams['type'];
        this.isMyImages = this.route.snapshot.queryParams['isMyImages'];
        this.isStockImages = this.route.snapshot.queryParams['isStock'];
        this.templateAction = this.route.snapshot.queryParams['action'];
        this.isTemplateSelected = this.route.snapshot.queryParams['isTemplateSelected'];
        this.tabNameFromTemplate = this.route.snapshot.queryParams['tabNameFromTemplate'];
        this.subGrpId = this.route.snapshot.queryParams['subGroupId'];
        this._accountService.hasAuthority('ROLE_ADMIN').then(isAdmin => {
            console.log('role user  isAdmin', isAdmin);
            this.isAdmin = isAdmin;
        });
        if (this.isStockImages === 'true') {
            this.tab.activeId = 'tab-2';
            this.isUploadBtnAvailable = true;
        } else if (this.isBanner === 'true') {
            this.isMyImages = true;
            this.tab.activeId = 'tab-1';
            this.isUploadBtnAvailable = true;
        }
        if (this.router.url.includes('library?CKEditor')) {
            this.tab.activeId = 'tab-5';
            this.contentType = CONTENT_TYPE.SIGN_IMAGE;
        }
        this.pageIndex = 0;
    }
    ngDoCheck() {
        if (this.tab.activeId === 'tab-1') {
            this.url = this.bannerURL;
        } else if (this.tab.activeId === 'tab-2') {
            this.url = this.stockPhotosURL;
        } else if (this.tab.activeId === 'tab-3') {
            this.url = this.imageUplodaUrl;
        } else if (this.tab.activeId === 'tab-4') {
            this.url = this.companyImageURL;
        } else if (this.tab.activeId === 'tab-5') {
            this.url = this.signatureResourceUrl;
        }
        this.token = this.localStorage.retrieve('authenticationToken') || this.sessionStorage.retrieve('authenticationToken');
        this.uploader.setOptions({
            url: this.isSubcategory ? this.url + '&subGroupId=' + this.selectedSubcatId : this.url,
            autoUpload: false,
            maxFileSize: this.maxFileSize,
            method: 'put',
            itemAlias: 'multipartFile',
            queueLimit: this.maxFile,
            authToken: 'Bearer ' + this.token
        });
        this.uploader.onWhenAddingFileFailed = (item, filter, options) => this.onWhenAddingFileFailed(item, filter, options);
        this.uploader.onAfterAddingAll = items => this.onAfterAddingAll(items);
        this.uploader.onAfterAddingFile = item => this.onAfterAddingFile(item);
        this.uploader.onCompleteAll = () => {
            this.uploader.clearQueue();
            this.closeUploadPopUp();
            this.isSubcategory ? this.fetchImagesByFolderId({ id: this.selectedSubcatId, name: this.subCategoryName }) : this.reloadData();
        };
        this.uploader.onSuccessItem = (item: any, response: string, status: number, headers: any) => {
            console.log('onSuccessItem response ', response);
        };
    }
    ngAfterViewInit() {
        //  this.paginator.page.subscribe((event: any) => console.log(event));
    }
    reloadData() {
        this.pageIndex = 0;
        if (this.tab.activeId === 'tab-1') {
            this.getBannerImages();
        } else if (this.tab.activeId === 'tab-2') {
            this.getStockImages();
        } else if (this.tab.activeId === 'tab-4') {
            this.getComapnyImages();
        } else if (this.tab.activeId === 'tab-5') {
            this.getSignatureImages();
        } else {
            this.getUserUploadedImages();
        }
    }
    // Simulate user action of selecting a file to be returned to CKEditor.
    returnFileUrl() {
        console.log('inside file url');
        const funcNum = this.route.snapshot.queryParams['CKEditorFuncNum'];
        const fileUrl = this.currentImageUrl;
        window.opener.CKEDITOR.tools.callFunction(funcNum, fileUrl);
        window.close();
    }
    changeTab($event: any) {
        this.selectedImagesArray = [];
        this.deletePhotos = true;
        this.pageIndex = 0;
        if ($event.nextId === 'tab-1') {
            this.contentType = CONTENT_TYPE.BANNER;
            this.getBannerImages();
            this.isUploadBtnAvailable = true;
        } else if ($event.nextId === 'tab-2') {
            this.contentType = CONTENT_TYPE.STOCK_IMAGE;
            this.getStockImages();
            this.isUploadBtnAvailable = true;
        } else if ($event.nextId === 'tab-4') {
            this.contentType = CONTENT_TYPE.ALL;
            this.getComapnyImages();
            this.isUploadBtnAvailable = false;
        } else if ($event.nextId === 'tab-5') {
            this.contentType = CONTENT_TYPE.SIGN_IMAGE;
            this.getSignatureImages();
            this.isUploadBtnAvailable = false;
        } else {
            this.contentType = CONTENT_TYPE.IMAGE;
            this.getUserUploadedImages();
            this.isUploadBtnAvailable = false;
        }
        /* ////////////////////// changed below code //////////////////////////////
        /// activated id is taken previous tab id instead of new clicked tab id ///
        // if (this.tab.activeId === 'tab-1') {
        //     this.getBannerImages();
        // } else if (this.tab.activeId === 'tab-2') {
        //     this.getStockImages();
        // } else {
        //     this.getUserUploadedImages();
        // }
        //////////////////////////////////////////////////////////////////////// */
    }
    isAccessible() {
        if (this.checkUserRole('ROLE_ADMIN') && (this.tab.activeId === 'tab-1' || this.tab.activeId === 'tab-2')) {
            return true;
        } else if (this.checkUserRole('ROLE_COMPANY_ADMIN') && this.tab.activeId === 'tab-4') {
            return true;
        }
        return false;
    }
    // activates the menu with the coordinates
    onrightClick(event, obj) {
        this.selectedFolder = obj;
        event.preventDefault();
        this.contextmenuX = event.clientX - 12;
        this.contextmenuY = event.clientY - 120;
        console.log(this.contextmenuY, this.contextmenuX);
        this.contextmenu = true;
    }
    // disables the menu
    disableContextMenu() {
        this.contextmenu = false;
    }
}
