import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
    name: 'libraryFilter'
})
export class LibraryFilter implements PipeTransform {
    transform(imageResponse: any, tab: any): any {
        if (imageResponse !== null || imageResponse !== undefined) {
            if (tab.activeId === 'tab-1') {
                console.log('(imageResponse || [])', imageResponse || []);
                return (imageResponse || []).filter(img => img.type === 'BANNER');
            } else {
                return (imageResponse || []).filter(img => img.type === 'STOCK_IMAGE');
            }
        } else {
            return [];
        }
    }
}
