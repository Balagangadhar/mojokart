import { Blob, IBlob } from 'app/shared/model/blob.model';
import { Injectable } from '@angular/core';
import { Observable, of, throwError } from 'rxjs';
import { HttpClient, HttpResponse, HttpHeaders, HttpHandler, HttpErrorResponse } from '@angular/common/http';
import { SERVER_API_URL } from 'app/app.constants';
// type EntityResponseType = HttpResponse<Template>;
// type EntityArrayResponseType = HttpResponse<Template[]>;
@Injectable({
    providedIn: 'root'
})
export class LibraryService {
    private resourceUrl = SERVER_API_URL + 'api/blobs';
    private bannerResourceUrl = SERVER_API_URL + 'api/blobs?type=BANNER';
    private stockImagesResourceUrl = SERVER_API_URL + 'api/blobs?type=STOCK_IMAGE';
    private imageResourceUrl = SERVER_API_URL + 'api/sub-groups';

    constructor(private http: HttpClient) {}
    getBannerImages(): Observable<any> {
        return this.http.get<IBlob[]>(this.bannerResourceUrl);
    }

    getStockImages(): Observable<any> {
        return this.http.get<IBlob[]>(this.stockImagesResourceUrl);
    }
    getUserImages(pageSize, pageNum): Observable<any> {
        return this.http.get<IBlob[]>(this.resourceUrl + '?type=IMAGE' + '&size=' + pageSize + '&page=' + pageNum + '&sort=id,desc', {
            observe: 'response'
        });
    }
    deleteLibrary(id: string): Observable<any> {
        return this.http.delete<any>(this.resourceUrl + '?ids=' + id);
    }
    getImageFolders(contentType, type): Observable<any> {
        return this.http.get<any>(this.imageResourceUrl + '?contentType=' + contentType + '&type=' + type);
    }
    getSignImages(pageSize, pageNum): Observable<any> {
        return this.http.get<IBlob[]>(
            this.resourceUrl + '?type=EMAIL_SIGNATURE_IMAGE' + '&size=' + pageSize + '&page=' + pageNum + '&sort=id,desc',
            {
                observe: 'response'
            }
        );
    }
    createNewFolder(requestObj) {
        return this.http.post<any>(this.imageResourceUrl, requestObj);
    }
    getImagesByFolderId(fid: string, type, pageSize, pageNum): Observable<any> {
        return this.http.get<any>(
            this.resourceUrl + '?subGroupId=' + fid + '&type=' + type + '&size=' + pageSize + '&page=' + pageNum + '&sort=id,desc',
            {
                observe: 'response'
            }
        );
    }
    renameFolder(requestObj) {
        return this.http.put<any>(this.imageResourceUrl, requestObj);
    }
    deleteLibraryFolder(id: string): Observable<any> {
        return this.http.delete<any>(this.imageResourceUrl + '/' + id);
    }
}
