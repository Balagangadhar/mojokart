import { Component, OnInit, AfterViewInit, ViewChild } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { MatPaginator, MatSort, MatTab, MatDialog } from '@angular/material';

import { merge, of as observableOf } from 'rxjs';
import { startWith, switchMap, map, catchError } from 'rxjs/operators';

import { HistoryService } from '../history.service';
import { History } from 'app/shared/model/history.model';
import { Campaign } from 'app/shared/model/email-campaign-regular.model';
import { CampaignPreviewComponent } from 'app/entities/campaigns/campaign-preview.component';

@Component({
    selector: 'jhi-text-history',
    templateUrl: './text-history.component.html',
    styleUrls: ['./text-history.component.css']
})
export class TextHistoryComponent implements AfterViewInit {
    tab: MatTab;
    displayedColumns: string[] = ['campaignName', 'to', 'date', 'campaignType', 'delivered', 'failed'];
    apiService: HistoryService | null;
    dataSource: History[] = [];
    resultsLength = 0;
    isLoadingResults = true;
    isRateLimitReached = false;
    campaignSelected: string;
    status = 'PUBLISHED';
    @ViewChild(MatPaginator) paginator: MatPaginator;
    @ViewChild(MatSort) sort: MatSort;
    searchText = '';

    constructor(private http: HttpClient, public dialog: MatDialog) {
        this.apiService = new HistoryService(this.http);
        this.campaignSelected = 'TEXT';
    }

    ngAfterViewInit() {
        this.textHistoryTable();
    }

    textHistoryTable() {
        this.sort.sortChange.subscribe(() => (this.paginator.pageIndex = 0));
        merge(this.sort.sortChange, this.paginator.page)
            .pipe(
                startWith({}),
                switchMap(() => {
                    this.isLoadingResults = true;
                    return this.apiService!.getTextReports(
                        this.status,
                        this.sort.active,
                        this.sort.direction,
                        this.paginator.pageIndex,
                        this.paginator.pageSize,
                        this.searchText
                    );
                }),
                map(data => {
                    this.isLoadingResults = false;
                    this.isRateLimitReached = false;
                    this.resultsLength = data.headers.get('x-total-count');
                    return data;
                }),
                catchError(() => {
                    this.isLoadingResults = false;
                    this.isRateLimitReached = true;
                    return observableOf([]);
                })
            )
            .subscribe(data => {
                this.dataSource = data.body;
            });
    }
    // filter
    applyFilter(searchText: string) {
        this.searchText = searchText;
        this.ngAfterViewInit();
    }
    onPreview(history: History) {
        // get campaign by Id
        console.log(history);
        this.apiService.getCampaignById(history.campaign.id).subscribe((data: Campaign) => this.previewDialog(data));
    }
    tabChanged($event) {
        console.log($event.tab.textLabel);
        if ($event.tab.textLabel === 'Scheduled') {
            this.status = 'SCHEDULED';
            this.ngAfterViewInit();
        } else if ($event.tab.textLabel === 'Sent') {
            this.status = 'PUBLISHED';
            this.ngAfterViewInit();
        }
    }
    previewDialog(campaign: Campaign): void {
        console.log(campaign);
        const dialogRef = this.dialog.open(CampaignPreviewComponent, {
            width: 'auto',
            data: campaign
        });
        dialogRef.afterClosed().subscribe(result => {
            console.log('The dialog was closed......' + JSON.stringify(result));
        });
    }
    onButton() {
        console.log(this.campaignSelected);
        this.campaignSelected = 'TEXT';
        this.ngAfterViewInit();
    }
    getTextDetails(campaign) {
        if (campaign.textDetails && campaign.textDetails.contacts) {
            const list = campaign.textDetails.contacts.map(c => c.name);
            return list.join(', ');
        } else {
            return '';
        }
    }
}
