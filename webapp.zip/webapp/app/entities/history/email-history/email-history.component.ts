import { Component, OnInit, AfterViewInit, ViewChild, ViewEncapsulation } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { MatPaginator, MatSort, MatTab, MatDialog } from '@angular/material';

import { merge, of as observableOf } from 'rxjs';
import { startWith, switchMap, map, catchError } from 'rxjs/operators';

import { HistoryService } from '../history.service';
import { History } from 'app/shared/model/history.model';
import { Campaign } from 'app/shared/model/email-campaign-regular.model';
import { CampaignPreviewComponent } from 'app/entities/campaigns/campaign-preview.component';

@Component({
    selector: 'jhi-email-history',
    templateUrl: './email-history.component.html',
    styleUrls: ['./email-history.component.css'],
    encapsulation: ViewEncapsulation.None
})
export class EmailHistoryComponent implements AfterViewInit {
    tab: MatTab;
    displayedColumns: string[] = ['campaignName', 'to', 'date', 'campaignType', 'delivered', 'unsubscribed', 'views', 'reportedSpam'];
    apiService: HistoryService | null;
    dataSource: History[] = [];
    campaign: Campaign;
    resultsLength = 0;
    isLoadingResults = true;
    isRateLimitReached = false;
    campaignSelected: string;
    status = 'PUBLISHED';
    @ViewChild(MatPaginator) paginator: MatPaginator;
    @ViewChild(MatSort) sort: MatSort;
    searchText = '';

    constructor(private http: HttpClient, public dialog: MatDialog) {
        this.apiService = new HistoryService(this.http);
        this.campaignSelected = 'EMAIL';
    }
    ngAfterViewInit() {
        this.emailHistoryTable();
    }
    emailHistoryTable() {
        this.sort.sortChange.subscribe(() => (this.paginator.pageIndex = 0));
        merge(this.sort.sortChange, this.paginator.page)
            .pipe(
                startWith({}),
                switchMap(() => {
                    this.isLoadingResults = true;
                    return this.apiService!.getEmailReports(
                        this.status,
                        this.sort.active,
                        this.sort.direction,
                        this.paginator.pageIndex,
                        this.paginator.pageSize,
                        this.searchText
                    );
                }),
                map(data => {
                    this.isLoadingResults = false;
                    this.isRateLimitReached = false;
                    this.resultsLength = data.headers.get('x-total-count');
                    return data;
                }),
                catchError(() => {
                    this.isLoadingResults = false;
                    this.isRateLimitReached = true;
                    return observableOf([]);
                })
            )
            .subscribe(data => {
                this.dataSource = data.body;
            });
    }
    // filter
    applyFilter(searchText: string) {
        this.searchText = searchText;
        this.ngAfterViewInit();
    }
    onPreview(history: History) {
        // get campaign by Id
        this.apiService.getCampaignById(history.campaign.id).subscribe((data: Campaign) => this.previewDialog(data));
    }
    tabChanged($event) {
        if ($event.tab.textLabel === 'Scheduled') {
            this.status = 'SCHEDULED';
            this.ngAfterViewInit();
        } else if ($event.tab.textLabel === 'Sent') {
            this.status = 'PUBLISHED';
            this.ngAfterViewInit();
        }
    }
    previewDialog(campaign: Campaign): void {
        const dialogRef = this.dialog.open(CampaignPreviewComponent, {
            width: 'auto',
            data: campaign
        });
        dialogRef.afterClosed().subscribe(result => {
            console.log('The dialog was closed......' + JSON.stringify(result));
        });
    }
    // onButton() {
    //     console.log(this.campaignSelected);
    //     this.campaignSelected = 'TEXT';
    //     this.ngAfterViewInit();
    // }
    getEmailDetails(campaign) {
        if (campaign.emailDetails && campaign.emailDetails.contactList) {
            let list = campaign.emailDetails.contactList.contacts;
            if (list) {
                list = list.map(c => c.name);
            }
            return list.join(', ');
        } else {
            return '';
        }
    }
}
