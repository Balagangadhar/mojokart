import { Component, DoCheck } from '@angular/core';
@Component({
    selector: 'jhi-history',
    templateUrl: './history.component.html',
    styleUrls: ['./history.component.css']
})
export class HistoryComponent {
    campaignSelected = 'EMAIL';
    constructor() {}
}
