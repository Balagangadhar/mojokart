import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MaterialModule } from './../material.module';
import { MatTabsModule } from '@angular/material/tabs';
import { HistoryRoutingModule } from './history-routing.module';
import { HistoryComponent } from './history/history.component';
import { FormsModule } from '@angular/forms';
import { EmailHistoryComponent } from './email-history/email-history.component';
import { TextHistoryComponent } from './text-history/text-history.component';
import { SharedCommonModule } from '../../shared/shared-common.module';

@NgModule({
    declarations: [HistoryComponent, EmailHistoryComponent, TextHistoryComponent],
    imports: [SharedCommonModule, CommonModule, MaterialModule, MatTabsModule, FormsModule, HistoryRoutingModule]
})
export class HistoryModule {}
