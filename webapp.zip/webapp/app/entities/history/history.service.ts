import { Injectable } from '@angular/core';
import { SERVER_API_URL } from 'app/app.constants';
import { HttpClient, HttpResponse } from '@angular/common/http';
import { Observable, observable } from 'rxjs';
import { Campaign } from 'app/shared/model/email-campaign-regular.model';

type EntityArrayResponseType = HttpResponse<History>;

@Injectable({
    providedIn: 'root'
})
export class HistoryService {
    private requestUrl = SERVER_API_URL + 'api/campaigns/email-delivery-report';
    private textReportUrl = SERVER_API_URL + 'api/campaigns/text-delivery-report';
    private campaignHistoryUrl = SERVER_API_URL + 'api/campaigns/';
    constructor(private http: HttpClient) {}
    emailReports() {
        return this.http.get<any>(this.requestUrl);
    }
    getEmailReports(status: string, sortParam: string, order: string, page: number, pageSize: number, searchText: string): Observable<any> {
        const requestUrl = `${this.requestUrl}?status=${status}&page=${page}&size=${pageSize}&sort=${sortParam}%2C${order}`;
        return this.http.get<EntityArrayResponseType>(requestUrl, { observe: 'response' });
    }
    getTextReports(status: string, sortParam: string, order: string, page: number, pageSize: number, searchText: string): Observable<any> {
        const resourceUrl = `${this.textReportUrl}?status=${status}&page=${page}&size=${pageSize}&sort=${sortParam}%2C${order}`;
        console.log(resourceUrl);
        return this.http.get<EntityArrayResponseType>(resourceUrl, { observe: 'response' });
    }
    // get campaign by id via history object
    getCampaignById(id: number): Observable<any> {
        return this.http.get<Campaign>(this.campaignHistoryUrl + id);
    }
}
