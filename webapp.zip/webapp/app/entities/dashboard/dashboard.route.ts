import { Routes } from '@angular/router';
import { UserRouteAccessService } from 'app/core';
import { JhiResolvePagingParams } from 'ng-jhipster';
import { DashboardComponent } from './dashboard.component';

export const dashBoardRoutes: Routes = [
    {
        path: 'dashboard',
        component: DashboardComponent,
        resolve: {
            pagingParams: JhiResolvePagingParams
        },
        data: {
            authorities: ['ROLE_USER'],
            defaultSort: 'id,asc',
            pageTitle: 'Dashboard'
        },
        canActivate: [UserRouteAccessService]
    }
];
