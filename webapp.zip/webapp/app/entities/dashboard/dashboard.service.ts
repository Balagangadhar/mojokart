import { Injectable } from '@angular/core';
import { Observable, of, throwError } from 'rxjs';
import { catchError } from 'rxjs/operators';
import { HttpClient, HttpResponse, HttpHeaders, HttpHandler, HttpErrorResponse } from '@angular/common/http';
import { SERVER_API_URL } from 'app/app.constants';
import { EmailDeliverySummary, TextDeliverySummary, IAccountCompleteness, IAccountUsage } from '../../shared/model/dashboard.model';
import { IAccount } from '../../shared/model/account.model';

@Injectable({
    providedIn: 'root'
})
export class DashBoardService {
    private emailSummaryUrl = SERVER_API_URL + 'api/campaigns/email-delivery-summary?period=';
    private textSummaryUrl = SERVER_API_URL + 'api/campaigns/text-delivery-summary?period=';
    private accountCompletnessUrl = SERVER_API_URL + 'api/account/completeness';
    private accountUsageUrl = SERVER_API_URL + 'api/account/usage';

    constructor(private http: HttpClient) {}
    getEmailSummaryDetails(period) {
        return this.http.get<EmailDeliverySummary>(this.emailSummaryUrl + period);
    }
    getTextSummaryDetails(period) {
        return this.http.get<TextDeliverySummary>(this.textSummaryUrl + period);
    }
    getAccountCompletnessDetails() {
        return this.http.get<IAccountCompleteness>(this.accountCompletnessUrl);
    }
    getAccountUsageDetails() {
        return this.http.get<IAccountUsage>(this.accountUsageUrl);
    }
}
