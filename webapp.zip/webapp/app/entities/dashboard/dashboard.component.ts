import { Component, OnInit } from '@angular/core';
import {
    EmailDeliverySummary,
    TextDeliverySummary,
    IAccountCompleteness,
    IAccountUsage,
    AccountCompleteness,
    AccountUsage
} from '../../shared/model/dashboard.model';
import { DashBoardService } from './dashboard.service';

@Component({
    selector: 'jhi-dashboard',
    templateUrl: './dashboard.component.html',
    styleUrls: ['./dashboard.component.css']
})
export class DashboardComponent implements OnInit {
    selectedPeriod = 'CURRENT_WEEK';
    emailSummary: any;
    textSummary: any;
    accountUsage: any;
    accountCompletness: any;
    emailUsageLimit: number;
    emailUsageUsed: number;
    textUsageLimit: number;
    textUsageUsed: number;
    constructor(public dashBoardService: DashBoardService) {
        this.emailSummary = new EmailDeliverySummary();
        this.textSummary = new TextDeliverySummary();
        this.accountCompletness = new AccountCompleteness(0);
        this.getAccountCompletnessDetails();
        this.getAccountUsageDetails();
    }

    ngOnInit() {
        this.getEmailSummaryReport('CURRENT_WEEK');
        this.getTextSummaryReport('CURRENT_WEEK');
    }

    getEmailSummaryReport(selectedPeriod) {
        this.dashBoardService.getEmailSummaryDetails(selectedPeriod).subscribe((response: EmailDeliverySummary) => {
            this.emailSummary = response;
        });
    }
    getTextSummaryReport(selectedPeriod) {
        this.dashBoardService.getTextSummaryDetails(selectedPeriod).subscribe((response: TextDeliverySummary) => {
            this.textSummary = response;
        });
    }

    changePeriod(period) {
        this.selectedPeriod = period;
        this.getEmailSummaryReport(this.selectedPeriod);
        this.getTextSummaryReport(this.selectedPeriod);
    }

    getAccountCompletnessDetails() {
        this.dashBoardService.getAccountCompletnessDetails().subscribe((response: IAccountCompleteness) => {
            this.accountCompletness = response;
        });
    }
    getAccountUsageDetails() {
        this.dashBoardService.getAccountUsageDetails().subscribe((response: IAccountUsage) => {
            this.accountUsage = response;
            this.emailUsageLimit = response.emailUsage.limit;
            this.emailUsageUsed = response.emailUsage.used;
            this.textUsageLimit = response.textUsage.limit;
            this.textUsageUsed = response.textUsage.used;
        });
    }
}
