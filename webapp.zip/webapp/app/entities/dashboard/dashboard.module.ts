import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { DashboardComponent } from './dashboard.component';
import { dashBoardRoutes } from './index';
import { FormsModule } from '@angular/forms';
import { RouterModule } from '@angular/router';
import { NgbModule } from '@ng-bootstrap/ng-bootstrap';

const ENTITY_STATES = [...dashBoardRoutes];

@NgModule({
    declarations: [DashboardComponent],
    imports: [CommonModule, NgbModule, FormsModule, RouterModule.forChild(ENTITY_STATES)]
})
export class DashboardModule {}
