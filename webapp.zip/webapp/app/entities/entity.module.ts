import { NgModule, CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { HistoryModule } from './history/history.module';
import { TemplateModule } from './template/template.module';
import { ContactModule } from './contact/contact.module';
import { ContactListModule } from './contact-list/contact-list.module';
import { CampaignsModule } from './campaigns/campaigns.module';
import { GlobalSendEmailDataService } from './global-send-email-data.service';
import { LibraryModule } from './library/library.module';
import { SeriesModule } from './series/series.module';
import { CKEditorModule } from 'ng2-ckeditor';
import { DashboardModule } from './dashboard/dashboard.module';
import { UserProfileModule } from './user-profile/user-profile.module';
import { FormsModule } from '@angular/forms';
import { SubgroupsModule } from './subgroups/subgroups.module';
@NgModule({
    // prettier-ignore
    imports: [
        TemplateModule,
        ContactModule,
        ContactListModule,
        CampaignsModule,
        LibraryModule,
        SeriesModule,
        HistoryModule,
        CKEditorModule,
        DashboardModule,
        UserProfileModule,
        FormsModule,
        SubgroupsModule
    ],
    declarations: [],
    entryComponents: [],
    providers: [GlobalSendEmailDataService],
    schemas: [CUSTOM_ELEMENTS_SCHEMA]
})
export class EntityModule {}
