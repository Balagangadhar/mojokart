import { NgModule } from '@angular/core';
import {
    MatButtonModule,
    MatCheckboxModule,
    MatInputModule,
    MatFormFieldModule,
    MatRippleModule,
    MatTableModule,
    MatPaginatorModule,
    MatDialogModule,
    MatSortModule,
    MatProgressSpinnerModule,
    MatRadioModule
} from '@angular/material';

@NgModule({
    imports: [
        MatButtonModule,
        MatCheckboxModule,
        MatFormFieldModule,
        MatInputModule,
        MatSortModule,
        MatRippleModule,
        MatTableModule,
        MatPaginatorModule,
        MatDialogModule,
        MatProgressSpinnerModule,
        MatRadioModule
    ],
    exports: [
        MatButtonModule,
        MatCheckboxModule,
        MatFormFieldModule,
        MatInputModule,
        MatSortModule,
        MatRippleModule,
        MatTableModule,
        MatPaginatorModule,
        MatDialogModule,
        MatProgressSpinnerModule,
        MatRadioModule
    ]
})
export class MaterialModule {}
