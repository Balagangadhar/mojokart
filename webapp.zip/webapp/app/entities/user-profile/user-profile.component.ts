import { Component, OnInit, ViewChild } from '@angular/core';
import { NgForm } from '@angular/forms';
import { MatDialog } from '@angular/material';
import { ActivatedRoute } from '@angular/router';
import { SenderProfile } from '../../shared/model/sender-profile.model';
import { SocialMedia } from './../../shared/model/sender-profile.model';
import { PreviewSignatureComponent } from './preview-signature.component';
import { UserProfileService } from './user-profile.service';
import { ContactService } from '../contact/contact.service';
@Component({
    selector: 'jhi-user-profile',
    templateUrl: './user-profile.component.html',
    styleUrls: ['./user-profile.component.css']
})
export class UserProfileComponent implements OnInit {
    //  name = 'ng2-ckeditor';
    name: any;
    ckeConfig: any;
    mycontent: any;
    log: string;
    allSenderDetails: any = [];
    currentSenderData: any;
    editDetails = false;
    isReadOnly = true;
    senderId: number;
    personalInfoButton = true;
    emailSignatureButton = true;
    socialMediaButton = true;
    selectedSenderName: string;
    selectedSender: number;
    currentSenderId: number;
    selectedSenderComapny: any;
    selectedSenderSocialMedia: any;
    senderName: any;
    up: any = {
        name: '',
        title: '',
        email: '',
        phone: '',
        cell: '',
        tollFree: '',
        fax: '',
        url2: '',
        url: '',
        address1: '',
        address2: '',
        city: '',
        state: '',
        zip: ''
    };

    accessLevel: any;
    display = 'none';
    exten: any;
    company: any;
    states: any;

    socialMedia = new SocialMedia('', '', '', null, '', '', '');
    senderProfile = new SenderProfile();
    @ViewChild('tab') tab;

    constructor(
        private _userProfileService: UserProfileService,
        private route: ActivatedRoute,
        public dialog: MatDialog,
        private _contactService: ContactService
    ) {
        this.selectedSender = -1;
        this.ckeConfig = {
            uiColor: '#cccccc',
            filebrowserBrowseUrl: '#/library',
            filebrowserWindowWidth: '640',
            filebrowserWindowHeight: '480',
            allowedContent: true,
            extraPlugins: ['field', 'lineheight'],
            removePlugins:
                'save, newpage, preview, wsc, scayt, about, pagebreak, flash, blockquote, dialogadvtab, div, iframe, forms, language, elementspath'
        };
    }

    getSenderInfo() {
        this._userProfileService.getSenderInfo().subscribe((response: SenderProfile[]) => {
            this.allSenderDetails = response;
            this.currentSenderData = response[0];
            this.senderProfile = this.currentSenderData;
            this.socialMedia = this.senderProfile.socialMedia || new SocialMedia('', '', '', null, '', '', '');
            this.selectedSender = this.currentSenderData.id;
            this.selectedSenderComapny = this.currentSenderData.company.name;
            if (this.currentSenderData.signature === '') {
                this.mycontent = 'Thanks and regards,' + `</br>` + this.senderProfile.name;
            } else {
                this.mycontent = this.senderProfile.signature.replace(/\n/g, '');
            }
        });
    }

    onSelectSender(sender) {
        this.currentSenderData = this.allSenderDetails.find(senders => senders.id === Number(sender));
        this.senderProfile = this.currentSenderData;
        this.socialMedia = this.senderProfile.socialMedia || new SocialMedia('', '', '', null, '', '', '');
        this.selectedSender = this.currentSenderData.id;
        this.selectedSenderComapny = this.currentSenderData.company.name;
        if (this.currentSenderData.signature === '') {
            this.mycontent = 'Thanks and regards' + '</br>' + this.senderProfile.name;
        } else {
            this.mycontent = this.senderProfile.signature;
        }
    }

    goToExtraSender() {
        window.open('http://iboomerang.com/email-marketing#product', '_blank');
    }

    editSenderInfo() {
        this.isReadOnly = false;
    }

    onSubmit(form: NgForm) {
        this._userProfileService.find(this.selectedSender).subscribe((response: SenderProfile) => {
            this._userProfileService.updateSenderInfo(this.senderProfile).subscribe((updatedResponse: SenderProfile) => {
                this.getSenderInfo();
            });
        });
        this.isReadOnly = true;
    }

    previewSignature() {
        this._userProfileService.find(this.selectedSender).subscribe((findResponse: SenderProfile) => {
            findResponse.signature = this.mycontent;
            this._userProfileService.updateSenderInfo(findResponse).subscribe((updatedResponse: SenderProfile) => {
                this.previewSignatureDialog(updatedResponse);
            });
        });
    }

    previewSignatureDialog(senderProfile: SenderProfile): void {
        const dialogRef = this.dialog.open(PreviewSignatureComponent, {
            width: 'auto',
            height: 'auto',
            data: senderProfile
        });
    }

    saveSocialMedia() {
        this._userProfileService.find(this.selectedSender).subscribe((findResponse: SenderProfile) => {
            this.senderProfile.socialMedia = this.socialMedia;
            this._userProfileService.updateSenderInfo(this.senderProfile).subscribe();
        });
    }

    ngOnInit() {
        this._contactService.getStates().subscribe(results => {
            console.log(results);
            this.states = results;
        });
        this.getSenderInfo();
        const pageName = this.route.snapshot.queryParams['pageName'];
        const tabName = this.route.snapshot.queryParams['tabName'];
        if (pageName === 'dashboard') {
            if (tabName === 'emailSignature') {
                this.tab.activeId = 'tab-2';
            } else {
                this.tab.activeId = 'tab-3';
            }
        }
    }

    onFileUploadRequest($event) {
        // do nothing
    }
    createSenderInfo() {
        this.up = {
            name: '',
            title: '',
            email: '',
            phone: '',
            cell: '',
            tollFree: '',
            fax: '',
            url2: '',
            url: '',
            address1: '',
            address2: '',
            city: '',
            state: '',
            zip: ''
        };
        this.display = 'block';
    }
    onCloseHandled() {
        this.display = 'none';
    }

    openSender(obj) {
        console.log(obj);
        this._userProfileService.createSender(obj).subscribe(data => {
            console.log(data);
            this.getSenderInfo();

            this.display = 'none';
        });
    }
}
