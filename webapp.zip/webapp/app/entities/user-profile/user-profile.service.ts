import { SenderProfile, ISenderProfile } from 'app/shared/model/sender-profile.model';
import { Injectable } from '@angular/core';
import { Observable, of, throwError } from 'rxjs';
import { HttpClient, HttpResponse, HttpHeaders, HttpHandler, HttpErrorResponse } from '@angular/common/http';
import { SERVER_API_URL } from 'app/app.constants';
type EntityResponseType = HttpResponse<SenderProfile>;
type EntityArrayResponseType = HttpResponse<ISenderProfile[]>;
@Injectable({
    providedIn: 'root'
})
export class UserProfileService {
    private resourceUrl = SERVER_API_URL + 'api/senders/';

    constructor(private http: HttpClient) {}

    find(id: number): Observable<SenderProfile> {
        return this.http.get<SenderProfile>(this.resourceUrl + id);
    }

    getSenderInfo(): Observable<SenderProfile[]> {
        return this.http.get<SenderProfile[]>(this.resourceUrl);
    }

    updateSenderInfo(senderInfo: SenderProfile): Observable<any> {
        // this.http.put<Template>(this.resourceUrl, template).subscribe(data => console.log(JSON.stringify(data)));
        return this.http.put<SenderProfile>(this.resourceUrl, senderInfo);
    }

    create(senderInfo: SenderProfile): Observable<any> {
        // this.http.post<Template>(this.resourceUrl, template).subscribe(data => console.log(JSON.stringify(data)));
        return this.http.post<SenderProfile>(this.resourceUrl, senderInfo);
    }

    // delete(id: number): Observable<any> {
    //     return this.http.delete<any>(this.resourceUrl + '/' + id);
    // }

    createSender(senderInfo: SenderProfile): Observable<any> {
        console.log(senderInfo);
        return this.http.post<SenderProfile>(this.resourceUrl, senderInfo);
    }
}
