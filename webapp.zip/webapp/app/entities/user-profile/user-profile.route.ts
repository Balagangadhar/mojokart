import { Routes } from '@angular/router';
import { HelpComponent } from './help/help.component';
import { UserRouteAccessService } from 'app/core';
import { JhiResolvePagingParams } from 'ng-jhipster';
import { UserProfileComponent } from '../user-profile/user-profile.component';

export const userProfileRoutes: Routes = [
    {
        path: 'user-profile',
        component: UserProfileComponent,
        resolve: {
            pagingParams: JhiResolvePagingParams
        },
        data: {
            authorities: ['ROLE_USER'],
            defaultSort: 'id,asc',
            pageTitle: 'My Profile'
        },
        canActivate: [UserRouteAccessService]
    },
    {
        path: 'help',
        component: HelpComponent,
        resolve: {
            pagingParams: JhiResolvePagingParams
        },
        data: {
            authorities: ['ROLE_USER'],
            defaultSort: 'id,asc',
            pageTitle: 'Help'
        },
        canActivate: [UserRouteAccessService]
    }
];
