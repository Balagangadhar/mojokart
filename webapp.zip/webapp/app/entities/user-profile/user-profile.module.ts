import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { RouterModule } from '@angular/router';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { NgbModule } from '@ng-bootstrap/ng-bootstrap';
import { SharedCommonModule } from '../../shared/shared-common.module';
import { UserProfileComponent } from './user-profile.component';
import { userProfileRoutes } from './user-profile.route';
import { CKEditorModule } from 'ng2-ckeditor';
import { MAT_DIALOG_DATA, MatDialogRef, MatSortModule } from '@angular/material';
import { PreviewSignatureComponent } from './preview-signature.component';
import { HelpComponent } from './help/help.component';
import { FormatMobileNumberPipe } from './format-mobile-number.pipe';

const ENTITY_STATES = [...userProfileRoutes];

@NgModule({
    declarations: [UserProfileComponent, PreviewSignatureComponent, HelpComponent, FormatMobileNumberPipe],
    imports: [
        BrowserAnimationsModule,
        CommonModule,
        FormsModule,
        ReactiveFormsModule,
        NgbModule,
        SharedCommonModule,
        CKEditorModule,
        RouterModule.forChild(ENTITY_STATES)
    ],
    exports: [SharedCommonModule],
    providers: [{ provide: MAT_DIALOG_DATA, useValue: {} }, { provide: MatDialogRef, useValue: {} }],
    entryComponents: [PreviewSignatureComponent]
})
export class UserProfileModule {}
