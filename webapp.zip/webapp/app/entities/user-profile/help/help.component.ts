import { Component, OnInit } from '@angular/core';

@Component({
    selector: 'jhi-help',
    templateUrl: './help.component.html',
    styles: []
})
export class HelpComponent implements OnInit {
    constructor() {}

    ngOnInit() {}
}
