import { Pipe, PipeTransform } from '@angular/core';
@Pipe({
    name: 'formatMobileNumber'
})
export class FormatMobileNumberPipe implements PipeTransform {
    transform(value: any, event: any): any {
        if (!value) {
            return '';
        }
        if (value.match(/[^0-9]/)) {
            if (event) {
                event.value = '';
            }
        }
        let country, city, number;

        switch (value.length) {
            case 10:
                country = 1;
                city = value.slice(0, 3);
                number = value.slice(3);
                break;
            default:
                return value;
        }
        // if (country === 1) {
        //     country = '';
        // }
        number = number.slice(0, 3) + '-' + number.slice(3);
        return (' (' + city + ') ' + number).trim();
    }
}
