import { Component, Inject, OnInit } from '@angular/core';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material';
import { SenderProfile } from '../../shared/model/sender-profile.model';

@Component({
    selector: 'jhi-preview-signature',
    templateUrl: './preview-signature.component.html',
    styles: []
})
export class PreviewSignatureComponent implements OnInit {
    constructor(public dialogRef: MatDialogRef<PreviewSignatureComponent>, @Inject(MAT_DIALOG_DATA) public senderProfile: SenderProfile) {}

    ngOnInit() {}
    onNoClick(): void {
        this.dialogRef.close();
    }
}
