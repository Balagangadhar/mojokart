import { Component, EventEmitter, Input, OnInit, Output } from '@angular/core';
import { Router } from '@angular/router';
import { NgbActiveModal } from '@ng-bootstrap/ng-bootstrap';
import { AccountService } from '../../../core/auth/account.service';
import { DAYS_OF_WEEKS, MONTHS, YEARS } from '../../../shared/constants/schedule.constants';
import { Schedule, Series } from '../../../shared/model/series.model';
import { Template } from '../../../shared/model/template.model';
import { TemplateService } from '../../template/template.service';
import { SeriesService } from '../series.service';
import { JhiEventManager } from 'ng-jhipster';

@Component({
    selector: 'jhi-add-template-series',
    templateUrl: './add-template-series.component.html',
    styleUrls: ['./add-template-series.component.css']
})
export class AddTemplateSeriesComponent implements OnInit {
    dayNumbers;
    dropdownSettings = {};
    dayOfWeekdropdownSettings = {};
    selectedMonth = [];
    selectedDay = [];
    selectedYear = [{ item_id: 0, item_text: 'Current Year' }];
    tempObj: any;
    days: any = [];
    months: any = [];
    years: any = [];
    templateResponse: any;
    selectedTemplate = -1;
    isSunDay = false;
    isMonday = true;
    isTuesday = false;
    isWednesday = false;
    isThursDay = false;
    isFirday = false;
    isSaturday = false;
    dayOfWeek = [];
    daysOfMonth = [];
    monthsList = [];
    yearOffsets = [];
    series: any;
    templates: any;
    schedule: any;
    selectAllDays = false;
    scheduleTime: any;
    validationErrorMessage = '';
    @Input() seriesResponse;
    @Input() templateId;
    @Input() action;
    @Input() cancelAction;
    daysOfWeekData: any = [];
    selectedDayOfWeek = [];
    dayOfWeekModel: any = '';
    dayOfMonthModel: any = '';
    @Output() newSereisResponse: EventEmitter<any> = new EventEmitter();

    constructor(
        private eventManager: JhiEventManager,
        public activeModal: NgbActiveModal,
        public _templateService: TemplateService,
        public _seriesService: SeriesService,
        public _accountService: AccountService,
        public router: Router
    ) {}

    ngOnInit() {
        this.getTemplateData();
        this.dayNumbers = this.fillArrayWithNumbers(31);
        for (const day of this.dayNumbers) {
            this.tempObj = {};
            this.tempObj.item_id = day;
            this.tempObj.item_text = day.toString();
            this.days.push(this.tempObj);
        }
        this.dayNumbers = this.fillArrayWithNumbers(12);
        for (const day of this.dayNumbers) {
            this.tempObj = {};
            this.tempObj.item_id = day;
            this.tempObj.item_text = MONTHS[day];
            this.months.push(this.tempObj);
        }
        this.years = [
            { item_id: 0, item_text: 'Current Year' },
            { item_id: 1, item_text: 'First Year' },
            { item_id: 2, item_text: 'Second Year' },
            { item_id: 3, item_text: 'Third Year' },
            { item_id: 4, item_text: 'Fourth Year' },
            { item_id: 5, item_text: 'Fifth Year' },
            { item_id: 6, item_text: 'Sixth Year' },
            { item_id: 7, item_text: 'Seventh Year' },
            { item_id: 8, item_text: 'Eighth Year' },
            { item_id: 9, item_text: 'Ninth Year' }
        ];
        this.daysOfWeekData = [
            { item_id: 'SUN', item_text: 'Sunday' },
            { item_id: 'MON', item_text: 'Monday' },
            { item_id: 'TUE', item_text: 'Tuesday' },
            { item_id: 'WED', item_text: 'Wednesday' },
            { item_id: 'THU', item_text: 'Thursday' },
            { item_id: 'FRI', item_text: 'Friday' },
            { item_id: 'SAT', item_text: 'Saturday' }
        ];
        this.dropdownSettings = {
            singleSelection: false,
            idField: 'item_id',
            textField: 'item_text',
            itemsShowLimit: 3,
            selectAllText: 'Select All',
            unSelectAllText: 'Unselect All',
            allowSearchFilter: false,
            enableCheckAll: true
        };
        this.dayOfWeekdropdownSettings = {
            singleSelection: false,
            idField: 'item_id',
            textField: 'item_text',
            itemsShowLimit: 3,
            selectAllText: 'Select All',
            unSelectAllText: 'Unselect All',
            allowSearchFilter: false,
            enableCheckAll: true
        };
        if (this.action !== null && this.action !== undefined && this.action === 'editSchedule') {
            this.intializeScheduleDetails();
        }
    }

    getTemplateData() {
        this._templateService.getTemplates().subscribe((response: Template[]) => {
            if (this.seriesResponse.ownerType) {
                console.log(this.seriesResponse.ownerType, 'result: ', response);
                this.templateResponse = response.filter(result => result.ownerType === this.seriesResponse.ownerType);
            } else {
                this.templateResponse = response;
            }
            if (this.action !== null && this.action !== undefined && this.action === 'editSchedule') {
                this.selectedTemplate = parseInt(this.templateId, 0);
            }
        });
    }

    createWeekArray() {
        for (const key of this.seriesResponse.templates[this.templateId].daysOfWeek) {
            this.tempObj = {};
            this.tempObj.item_id = key;
            this.tempObj.item_text = DAYS_OF_WEEKS[key];
            this.selectedDayOfWeek.push(this.tempObj);
        }
    }

    createDayArray() {
        for (const key of this.seriesResponse.templates[this.templateId].daysOfMonth) {
            this.tempObj = {};
            this.tempObj.item_id = key;
            this.tempObj.item_text = key.toString();
            this.selectedDay.push(this.tempObj);
        }
    }

    createMonthArray() {
        for (const key of this.seriesResponse.templates[this.templateId].months) {
            this.tempObj = {};
            this.tempObj.item_id = key;
            this.tempObj.item_text = MONTHS[parseInt(key, 0)];
            this.selectedMonth.push(this.tempObj);
        }
    }

    createYearArray() {
        this.selectedYear = [];
        for (const key of this.seriesResponse.templates[this.templateId].yearOffsets) {
            this.tempObj = {};
            this.tempObj.item_id = key;
            this.tempObj.item_text = YEARS[parseInt(key, 0)].replace('_', ' ');
            this.selectedYear.push(this.tempObj);
        }
    }

    intializeScheduleDetails() {
        this.selectedTemplate = this.templateId;
        if (this.seriesResponse.templates[this.templateId] !== null) {
            if (
                this.seriesResponse.templates[this.templateId].daysOfWeek != null &&
                this.seriesResponse.templates[this.templateId].daysOfWeek.length > 0
            ) {
                this.createWeekArray();
                this.dayOfWeekModel = 'dayOfWeekRadio';
            }
            if (
                this.seriesResponse.templates[this.templateId].daysOfMonth != null &&
                this.seriesResponse.templates[this.templateId].daysOfMonth.length > 0
            ) {
                this.createDayArray();
                this.dayOfMonthModel = 'dayOfMonthRadio';
            }
            this.createMonthArray();
            this.createYearArray();
            this.scheduleTime = this.seriesResponse.templates[this.templateId].at;
        }
    }

    closePopUp() {
        this.activeModal.close('Close click');
        if (this.cancelAction !== 'campaignRedirection') {
            this.router.navigate(['/series']);
        }
    }

    getKeys(obj) {
        const keys = [];
        for (const b of obj) {
            keys.push(b.item_id);
        }
        return keys;
    }

    getWeekKeys(obj) {
        const keys = [];
        for (const b of obj) {
            keys.push(b.item_id);
        }
        return keys;
    }

    checkBasicValidations() {
        if (this.action !== null && this.action !== undefined && this.action !== 'editSchedule') {
            if (this.selectedTemplate === -1) {
                this.validationErrorMessage = 'Please select a template';
                return;
            } else {
                this.validationErrorMessage = '';
            }
        }
        if (this.scheduleTime === undefined || this.scheduleTime === null) {
            this.validationErrorMessage = 'Please select time';
            return;
        } else {
            this.validationErrorMessage = '';
        }
        if (this.dayOfMonthModel === '' && this.dayOfWeekModel === '') {
            this.validationErrorMessage = 'Please select either day of week or day of month';
            return;
        } else {
            this.validationErrorMessage = '';
        }
    }

    addTemplate() {
        this.checkBasicValidations();
        this.schedule = this.seriesResponse.templates[this.selectedTemplate] || new Schedule();
        if (this.dayOfMonthModel !== '' && this.dayOfMonthModel.length > 0) {
            delete this.schedule.daysOfMonth;
            this.schedule.daysOfMonth = this.getKeys(this.selectedDay);
            delete this.schedule.daysOfWeek;
        } else {
            delete this.schedule.daysOfWeek;
            this.schedule.daysOfWeek = this.getKeys(this.selectedDayOfWeek);
            delete this.schedule.daysOfMonth;
        }
        delete this.schedule.months;
        this.schedule.months = this.getKeys(this.selectedMonth);
        delete this.schedule.yearOffsets;
        this.schedule.yearOffsets = this.getKeys(this.selectedYear);
        delete this.schedule.at;
        this.schedule.at = this.scheduleTime;
        this.seriesResponse.templates[this.selectedTemplate] = this.schedule;
        this._seriesService.createSchedule(this.seriesResponse).subscribe(
            (response: Series) => {
                this.newSereisResponse.emit(response.id);
                this.validationErrorMessage = '';
                this.activeModal.close('Close click');
                this.eventManager.broadcast({
                    name: 'scheduleUpdated',
                    content: response.templates[this.selectedTemplate]
                });
            },
            err => {
                this.validationErrorMessage = 'Failed to update series, please try again';
                delete this.seriesResponse.templates[this.selectedTemplate];
            }
        );
    }

    onSelectTemplate(id) {
        this.selectedTemplate = id;
        this.validationErrorMessage = '';
    }

    onMonthSelect(item: any) {}

    onDaySelect(item: any) {}

    onYearSelect(item: any) {}

    onDayOfWeekSelect(item: any) {}

    fillArrayWithNumbers(n) {
        const arr = Array.apply(null, Array(n));
        return arr.map((x, y) => y + 1);
    }

    changeDayOfMonthRadio(obj) {
        console.log('sun,mon,tue');
        this.dayOfMonthModel = 'dayOfMonthRadio';
        this.dayOfWeekModel = '';
        this.selectedDayOfWeek = [];
    }

    changeDayOfWeekRadio(obj) {
        console.log('1,2,3');
        this.dayOfWeekModel = 'dayOfWeekRadio';
        this.dayOfMonthModel = '';
        this.selectedDay = [];
    }
}
