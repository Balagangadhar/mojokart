import { Injectable } from '@angular/core';
import { Resolve, ActivatedRouteSnapshot, RouterStateSnapshot, Routes, RouterModule } from '@angular/router';
import { HttpResponse } from '@angular/common/http';
import { Observable, of } from 'rxjs';
import { filter, map } from 'rxjs/operators';

import { ContactService } from '../contact/contact.service';
import { ISeries, Series } from 'app/shared/model/series.model';
import { UserRouteAccessService } from 'app/core';
import { JhiResolvePagingParams } from 'ng-jhipster';
import { SeriesComponent } from './series/series.component';

export const seriesRoutes: Routes = [
    {
        path: 'series',
        component: SeriesComponent,
        resolve: {
            pagingParams: JhiResolvePagingParams
        },
        data: {
            authorities: ['ROLE_USER'],
            defaultSort: 'id,asc',
            pageTitle: 'Series'
        },
        canActivate: [UserRouteAccessService]
    }
];
