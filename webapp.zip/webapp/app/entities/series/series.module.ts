import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { SeriesBodyComponent } from './series/series-body.component';
import { SeriesComponent } from './series/series.component';
import { seriesRoutes } from './index';
import { FormsModule } from '@angular/forms';
import { RouterModule } from '@angular/router';
import { NgbModule } from '@ng-bootstrap/ng-bootstrap';
import { AddTemplateSeriesComponent } from './add-template-series/add-template-series.component';
import { CreateSeriesComponent } from './series/series.component';
import { NgMultiSelectDropDownModule } from 'ng-multiselect-dropdown';
import { FilterSeriesPipe } from './filter-series.pipe';
import { SharedCommonModule } from '../../shared/shared-common.module';
import { PreviewSeriesComponent } from './series/preview-series.component';
import { EditSeriesNameComponent } from './series/edit-series-name.component';
import { SeriesDeleteConfirmationComponent } from './series/series-delete-confirmation.component';

const ENTITY_STATES = [...seriesRoutes];

@NgModule({
    declarations: [
        SeriesBodyComponent,
        CreateSeriesComponent,
        SeriesComponent,
        AddTemplateSeriesComponent,
        FilterSeriesPipe,
        PreviewSeriesComponent,
        EditSeriesNameComponent,
        SeriesDeleteConfirmationComponent
    ],
    imports: [
        CommonModule,
        FormsModule,
        NgbModule,
        SharedCommonModule,
        NgMultiSelectDropDownModule.forRoot(),
        RouterModule.forChild(ENTITY_STATES)
    ],
    entryComponents: [
        CreateSeriesComponent,
        AddTemplateSeriesComponent,
        PreviewSeriesComponent,
        EditSeriesNameComponent,
        SeriesDeleteConfirmationComponent
    ]
})
export class SeriesModule {}
