import { Injectable } from '@angular/core';
import { Observable, of, throwError } from 'rxjs';
import { catchError } from 'rxjs/operators';
import { HttpClient, HttpResponse, HttpHeaders, HttpHandler, HttpErrorResponse } from '@angular/common/http';
import { SERVER_API_URL } from 'app/app.constants';
import { ISeries, Series } from '../../shared/model/series.model';
import { IAccount } from '../../shared/model/account.model';

@Injectable({
    providedIn: 'root'
})
export class SeriesService {
    private seriesUrl = SERVER_API_URL + 'api/series';
    // private createScheduleURL = SERVER_API_URL + 'api/account';

    constructor(private http: HttpClient) {}
    getSeriesDetails() {
        return this.http.get<Series>(this.seriesUrl);
    }
    createSeries(seriesRequest) {
        return this.http.post<Series>(this.seriesUrl, seriesRequest).pipe(
            catchError(err => {
                console.error('create series is failed ...........', err.message);
                return Observable.throw(err);
            })
        );
    }
    createSchedule(seriesRequest): Observable<Series> {
        return this.http.put<Series>(this.seriesUrl, seriesRequest).pipe(
            catchError(err => {
                console.error('create Scheduled ...........', err.message);
                return Observable.throw(err);
            })
        );
    }
    delete(id: number): Observable<any> {
        console.log('delete series ', this.seriesUrl + '/' + id);
        return this.http.delete<any>(this.seriesUrl + '/' + id);
    }
    getSeriesDetailsById(id) {
        return this.http.get<Series>(this.seriesUrl + '/' + id);
    }
}
