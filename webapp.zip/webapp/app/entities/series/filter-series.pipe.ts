import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
    name: 'filterSeries'
})
export class FilterSeriesPipe implements PipeTransform {
    transform(seriesResponse: any, tab: any): any {
        if (seriesResponse !== null || seriesResponse !== undefined) {
            if (tab.activeId === 'tab-1') {
                return (seriesResponse || []).filter(temp => temp.ownerType === 'STANDARD');
            } else {
                return (seriesResponse || []).filter(temp => temp.ownerType === 'USER');
            }
        } else {
            return [];
        }
    }
}
