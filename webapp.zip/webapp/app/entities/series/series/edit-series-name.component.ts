import { Component, OnInit, Input, EventEmitter, Output } from '@angular/core';
import { NgbModal, NgbActiveModal } from '@ng-bootstrap/ng-bootstrap';
import { SeriesService } from '../series.service';
import { Series } from '../../../shared/model/series.model';

@Component({
    selector: 'jhi-edit-series-name',
    templateUrl: './edit-series-name.component.html',
    styleUrls: ['./edit-series-name.component.css']
})
export class EditSeriesNameComponent implements OnInit {
    @Input() seriesResponse;
    @Input() seriesName: any;
    errorMessage: any;
    constructor(public activeModal: NgbActiveModal, public _seriesService: SeriesService) {}

    ngOnInit() {}

    editSeries() {
        if (this.seriesName.replace(/ /g, '').length === 0) {
            this.errorMessage = 'Please enter series name';
            return;
        } else {
            this.errorMessage = '';
        }
        const oldName = this.seriesResponse.name;
        this.seriesResponse.name = this.seriesName;
        this._seriesService.createSchedule(this.seriesResponse).subscribe(
            (response: Series) => {
                console.log(' edit series name response..', response);
                this.activeModal.dismiss('Cross click');
            },
            err => {
                this.seriesResponse.name = oldName;
                console.error('edit series  is failed ...........');
            }
        );
    }
}
