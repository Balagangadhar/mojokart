import { Component, OnInit, Input, EventEmitter, Output } from '@angular/core';
import { SeriesService } from '../series.service';
import { Series } from '../../../shared/model/series.model';
import { NgbModal } from '@ng-bootstrap/ng-bootstrap';
import { Router, ActivatedRoute } from '@angular/router';
import { TemplateService } from '../../template/template.service';
import { AddTemplateSeriesComponent } from '../add-template-series/add-template-series.component';
import { PreviewSeriesComponent } from './preview-series.component';
import { AccountService } from '../../../core/auth/account.service';
import { CommonUtil } from '../../../shared/util/common-util';

@Component({
    selector: 'jhi-series-body',
    templateUrl: './series-body.component.html',
    styleUrls: ['./series-body.component.css']
})
export class SeriesBodyComponent implements OnInit {
    seriesResponse: any;
    seriesName: any;
    selectedSeries: any = null;
    keys = [];
    modalRef: any;
    objectKeys = Object.keys;
    selectedSeriesWithSchedule: any;
    isAdmin: boolean;
    isStandard: boolean;
    @Input() tabName: any;
    @Output() onSelectedSeries = new EventEmitter();
    hasCount: boolean;
    constructor(
        public _seriesService: SeriesService,
        private modalService: NgbModal,
        public router: Router,
        public templateService: TemplateService,
        public _accountService: AccountService,
        private commonUtil: CommonUtil,
        private route: ActivatedRoute
    ) {}
    ngOnInit() {
        this.onSelectedSeries.emit(null);
        this.isStandard = this.tabName.activeId === 'tab-1' ? true : false;
        this.getSeriesDetails();
        this._accountService.hasAuthority('ROLE_ADMIN').then(isAdmin => {
            this.isAdmin = isAdmin;
        });
        const page_name = this.route.snapshot.queryParams['pageName'];
        if (page_name !== undefined && page_name !== null && page_name === 'template') {
            const series_id = this.route.snapshot.queryParams['seriesId'];
            this.onSelectSeries(series_id);
        }
    }
    onSelectSeries(id) {
        this._seriesService.getSeriesDetailsById(id).subscribe((response: Series) => {
            this.selectedSeriesWithSchedule = response;
            this.onSelectedSeries.emit(response);
        });
        this.selectedSeries = id;
    }
    getSeriesDetails() {
        this._seriesService.getSeriesDetails().subscribe((response: Series) => {
            this.seriesResponse = response;
            if (response) {
                this.hasCount = false;
                Object.keys(response).forEach(key => {
                    const checkTab = this.tabName.activeId === 'tab-1' ? 'STANDARD' : 'USER';
                    if (checkTab === response[key].ownerType) {
                        this.hasCount = true;
                    }
                });
            }
        });
    }
    getSeriesDetailsById(id) {
        this._seriesService.getSeriesDetailsById(id).subscribe((response: Series) => {
            return response;
        });
    }
    deleteSeries(templateId) {
        /* removed the deleted selected template from all templates from series,
         as well as removing same teplate from template details array also */
        delete this.selectedSeriesWithSchedule.templates[templateId.toString()];
        delete this.selectedSeriesWithSchedule.templateDetails[templateId.toString()];
        // again sending remaining template series to api to update
        this._seriesService.createSchedule(this.selectedSeriesWithSchedule).subscribe();
    }
    editSchedule(templateId) {
        const options = this.commonUtil.getModalPopUpSettings();
        options.size = 'lg';
        this.modalRef = this.modalService.open(AddTemplateSeriesComponent, options);
        this.modalRef.componentInstance.seriesResponse = this.selectedSeriesWithSchedule;
        this.modalRef.componentInstance.templateId = templateId;
        this.modalRef.componentInstance.action = 'editSchedule';
        this.modalRef.componentInstance.cancelAction = 'seriesRedirection';
    }
    editTemplate(id, item) {
        let subGrp = -1;
        if (item && item.subGroup) {
            subGrp = item.subGroup.id;
        }
        this.router.navigate(['/template'], {
            queryParams: {
                pageName: 'seriesPage',
                templateId: id,
                templateAction: 'editTemplate',
                seriesId: this.selectedSeries,
                subGroupId: subGrp
            }
        });
    }
    preview(templateId) {
        const options = this.commonUtil.getModalPopUpSettings();
        options.size = 'lg';
        this.modalRef = this.modalService.open(PreviewSeriesComponent, options);
        this.modalRef.componentInstance.templateId = templateId;
    }
}
