import { Component, OnInit, Input } from '@angular/core';
import { TemplateService } from '../../template/template.service';
import { NgbActiveModal } from '@ng-bootstrap/ng-bootstrap';

@Component({
    selector: 'jhi-preview-series',
    templateUrl: './preview-series.component.html',
    styleUrls: ['./preview-series.component.css']
})
export class PreviewSeriesComponent implements OnInit {
    @Input() templateId;
    templateResponse: any;
    bannerURL: any = '';
    templateAttachments: any;
    emailContent: any = '';
    constructor(public _templateService: TemplateService, public activeModal: NgbActiveModal) {}

    ngOnInit() {
        this.getTemplateDetails();
    }

    getTemplateDetails() {
        console.log('template id in preview series ', this.templateId);
        this._templateService.find(this.templateId).subscribe((response: any) => {
            console.log('series preview template response ', response.body);
            this.templateResponse = response.body;
            if (response.body.banner !== null) {
                this.bannerURL = response.body.banner.url;
            }
            if (response.body.content != null) {
                this.emailContent = response.body.content;
            }
            if (response.body.attachments !== null) {
                this.templateAttachments = response.body.attachments;
            }
        });
    }
}
