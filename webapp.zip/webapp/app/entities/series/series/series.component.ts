import { Component, DoCheck, EventEmitter, Input, OnInit, Output, ViewChild } from '@angular/core';
import { NgbActiveModal, NgbModal } from '@ng-bootstrap/ng-bootstrap';
import { AccountService } from '../../../core/auth/account.service';
import { Series } from '../../../shared/model/series.model';
import { CommonUtil } from '../../../shared/util/common-util';
import { AddTemplateSeriesComponent } from '../add-template-series/add-template-series.component';
import { SeriesService } from '../series.service';
import { EditSeriesNameComponent } from './edit-series-name.component';
import { SeriesBodyComponent } from './series-body.component';
import { SeriesDeleteConfirmationComponent } from './series-delete-confirmation.component';

@Component({
    selector: 'jhi-popup-series',
    templateUrl: './create.series.component.html',
    styleUrls: ['./series.component.css']
})
export class CreateSeriesComponent implements OnInit {
    accountResponse: any;
    series: any;
    seriesName: string;
    modalRef: any;
    validationErrorMessage: any = '';
    @Input() tabName;
    @Output() newSeriesId: EventEmitter<any> = new EventEmitter();
    constructor(
        private modalService: NgbModal,
        public activeModal: NgbActiveModal,
        public _seriesService: SeriesService,
        public _accountService: AccountService,
        private commonUtil: CommonUtil
    ) {}
    ngOnInit() {
        this.getUserDetails();
    }
    startSeries() {
        this.series = new Series();
        this.series.companyId = this.accountResponse.companyId;
        this.series.name = this.seriesName;
        this.series.ownerId = this.accountResponse.id;
        if (this.tabName === 'tab-1') {
            this.series.ownerType = 'STANDARD';
        } else {
            this.series.ownerType = 'USER';
        }
        if (this.seriesName === undefined || this.seriesName.replace(/ /g, '').length === 0) {
            this.validationErrorMessage = 'Please enter valid name';
            return;
        } else {
            this.validationErrorMessage = '';
        }
        this._seriesService.createSeries(this.series).subscribe((response: Series) => {
            this.activeModal.close();
            const options = this.commonUtil.getModalPopUpSettings();
            options.size = 'lg';
            this.modalRef = this.modalService.open(AddTemplateSeriesComponent, options);
            this.modalRef.componentInstance.seriesResponse = response;
            this.modalRef.componentInstance.action = 'createSeries';
            this.modalRef.componentInstance.newSereisResponse.subscribe(id => {
                this.newSeriesId.emit(id);
            });
        });
    }
    getUserDetails() {
        this._accountService.identity().then(account => {
            this.accountResponse = account;
        });
    }
}

@Component({
    selector: 'jhi-series',
    templateUrl: 'series.component.html',
    styleUrls: ['./series.component.css']
})
export class SeriesComponent implements OnInit, DoCheck {
    standardDetailsDiv: any = true;
    mySeriesDetailsDiv: any = false;
    selectedSeries: any;
    isAdmin: boolean;
    modalRef: any;
    isStandard: boolean;
    JSON: any;
    @ViewChild('tab') tab;
    @ViewChild(SeriesBodyComponent) child: SeriesBodyComponent;

    constructor(
        private modalService: NgbModal,
        public _seriesService: SeriesService,
        public _accountService: AccountService,
        private commonUtil: CommonUtil
    ) {}

    createSeries() {
        const options = this.commonUtil.getModalPopUpSettings();
        delete options.size;
        this.modalRef = this.modalService.open(CreateSeriesComponent, options);
        this.modalRef.componentInstance.tabName = this.tab.activeId;
        this.modalRef.componentInstance.newSeriesId.subscribe(id => {
            this.child.getSeriesDetails();
            this.child.onSelectSeries(id);
        });
    }

    intializeSeriesId(selectedSeries) {
        this.selectedSeries = selectedSeries;
    }

    editSeriesName() {
        const options = this.commonUtil.getModalPopUpSettings();
        delete options.size;
        this.modalRef = this.modalService.open(EditSeriesNameComponent, options);
        this.modalRef.componentInstance.seriesResponse = this.selectedSeries;
        this.modalRef.componentInstance.seriesName = this.selectedSeries.name;
    }

    deleteSeries() {
        const options = this.commonUtil.getModalPopUpSettings();
        delete options.size;
        this.modalRef = this.modalService.open(SeriesDeleteConfirmationComponent, options);
        this.modalRef.componentInstance.seriesId = this.selectedSeries.id;
        this.modalRef.result.then(
            result => {},
            reason => {
                if (reason === 'delete') {
                    this.child.selectedSeriesWithSchedule = null;
                    this.child.getSeriesDetails();
                    this.selectedSeries = null;
                    this.child.selectedSeries = null;
                }
            }
        );
    }

    addTemplate() {
        const options = this.commonUtil.getModalPopUpSettings();
        options.size = 'lg';
        this.modalRef = this.modalService.open(AddTemplateSeriesComponent, options);
        this.modalRef.componentInstance.seriesResponse = this.selectedSeries;
        this.modalRef.componentInstance.action = 'addTemplate';
        this.modalRef.componentInstance.cancelAction = 'seriesRedirection';
        this.modalRef.componentInstance.newSereisResponse.subscribe(id => {
            this.child.onSelectSeries(id);
        });
    }
    ngDoCheck() {
        this.isStandard = this.tab.activeId === 'tab-1' ? true : false;
    }
    ngOnInit() {
        this.JSON = JSON;
        this.tab.activeId = 'tab-2';
        this._accountService.hasAuthority('ROLE_ADMIN').then(isAdmin => {
            this.isAdmin = isAdmin;
        });
    }
}
