import { Component, Input } from '@angular/core';
import { NgbActiveModal } from '@ng-bootstrap/ng-bootstrap';
import { SeriesService } from '../series.service';

@Component({
    selector: 'jhi-series-delete-confirmation',
    templateUrl: './series-delete-confirmation.component.html',
    styles: []
})
export class SeriesDeleteConfirmationComponent {
    @Input() seriesId;

    constructor(public activeModal: NgbActiveModal, public _seriesService: SeriesService) {}

    deleteSeries() {
        this._seriesService.delete(this.seriesId).subscribe(
            () => {
                this.activeModal.dismiss('delete');
            },
            () => {
                this.activeModal.dismiss('delete');
            }
        );
    }
}
