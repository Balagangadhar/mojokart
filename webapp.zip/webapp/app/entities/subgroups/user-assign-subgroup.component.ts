import { Component, OnInit, Input } from '@angular/core';
import { NgbActiveModal } from '@ng-bootstrap/ng-bootstrap';
import { AccountService } from '../../core/auth/account.service';
import { SubGroupService } from './subgroups.service';
import { IUser, ISubgroup, USER_TYPE, CONTENT_TYPE } from '../../shared/model/subgroup.model';

@Component({
    selector: 'jhi-user-assign-subgroup',
    templateUrl: './user-assign-subgroup.component.html',
    styleUrls: ['./user-assign-subgroup.component.css']
})
export class UserAssignSubgroupComponent implements OnInit {
    accountResponse: any;
    usersList: IUser[];
    selectedUser: any;
    groupsList: ISubgroup[];
    selectedGroup = '-1';
    dropdownSettings = {};
    subgroupName: string;
    @Input() editGroupId;
    @Input() btnAction;
    @Input() isAdmin;
    @Input() editGroupName;
    constructor(public subGroupService: SubGroupService, public activeModal: NgbActiveModal, public _accountService: AccountService) {
        this._accountService.identity().then(account => {
            this.accountResponse = account;
        });
    }

    getUserList() {
        this.subGroupService.getUserList(this.accountResponse.companyId).subscribe((usersList: any) => {
            this.usersList = this.fetchUsers(usersList);
        });
    }
    getUserListBySubgroupId(subgroupId) {
        this.subGroupService.getUserListBysubgroupId(subgroupId).subscribe((subgroup: ISubgroup) => {
            this.selectedUser = this.fetchUsers(subgroup.users);
        });
    }
    fetchUsers(users) {
        const list = [];
        if (users) {
            for (const user of users) {
                const obj = { id: 0, name: '' };
                obj.id = user.id;
                obj.name = user.lastName && user.lastName.trim() !== '' ? user.lastName + ', ' + user.firstName : user.firstName;
                list.push(obj);
            }
        }
        return list;
    }
    ngOnInit() {
        this.getUserList();
        this.getGroupsList();
        this.dropdownSettings = {
            singleSelection: false,
            idField: 'id',
            textField: 'name',
            itemsShowLimit: 3,
            selectAllText: 'Select All',
            unSelectAllText: 'Unselect All',
            allowSearchFilter: false,
            enableCheckAll: true
        };
        if (this.btnAction === 'edit') {
            this.getUserListBySubgroupId(this.editGroupId);
            this.selectedGroup = this.editGroupId;
            this.subgroupName = this.editGroupName;
        }
    }
    onSelectUser() {}
    onSelectGroup(event) {
        this.getUserListBySubgroupId(event.target.value);
    }
    removedUser() {
        if (this.selectedUser && this.selectedUser.length === 0) {
            this.selectedUser = '';
        }
    }
    getGroupsList() {
        let usertype;
        if (this.isAdmin) {
            usertype = USER_TYPE.ROLE_ADMIN;
        } else {
            usertype = USER_TYPE.ROLE_COMPANY_ADMIN;
        }
        this.subGroupService.getTemplateGroups(usertype, CONTENT_TYPE.ALL).subscribe((response: any) => {
            this.groupsList = response;
        });
    }
    removeDuplicates(myArr, prop) {
        return myArr.filter((obj, pos, arr) => {
            return arr.map(mapObj => mapObj[prop]).indexOf(obj[prop]) === pos;
        });
    }
    assignUserToGroup() {
        const groupObj = this.groupsList.find(g => parseInt(this.selectedGroup, 0) === g.id);
        if (this.btnAction === 'edit') {
            groupObj.name = this.subgroupName;
        }
        if (groupObj.users) {
            delete groupObj.users;
            groupObj.users = this.selectedUser;
        } else {
            groupObj.users = this.selectedUser;
        }
        this.subGroupService.assignUserToSubgroup(groupObj).subscribe((response: any) => {
            this.activeModal.close('assignUser');
        });
    }
}
