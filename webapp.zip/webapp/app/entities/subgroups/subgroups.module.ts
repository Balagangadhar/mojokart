import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { SubgroupsComponent } from './subgroups.component';
import { subGroupsRoutes } from './index';
import { FormsModule } from '@angular/forms';
import { NgbModule } from '@ng-bootstrap/ng-bootstrap';
import { RouterModule } from '@angular/router';
import { DeleteSubgroupComponent } from './delete-subgroup.component';
import { CreateSubgroupComponent } from './create-subgroup.component';
import { UserAssignSubgroupComponent } from './user-assign-subgroup.component';
import { NgMultiSelectDropDownModule } from 'ng-multiselect-dropdown';
import { SharedCommonModule } from '../../shared/shared-common.module';

const ENTITY_STATES = [...subGroupsRoutes];

@NgModule({
    declarations: [SubgroupsComponent, DeleteSubgroupComponent, CreateSubgroupComponent, UserAssignSubgroupComponent],
    imports: [
        CommonModule,
        FormsModule,
        NgbModule,
        SharedCommonModule,
        RouterModule.forChild(ENTITY_STATES),
        NgMultiSelectDropDownModule.forRoot()
    ],
    entryComponents: [UserAssignSubgroupComponent, DeleteSubgroupComponent, CreateSubgroupComponent]
})
export class SubgroupsModule {}
