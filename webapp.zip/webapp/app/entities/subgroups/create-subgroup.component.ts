import { Component, OnInit, EventEmitter, Output, Input } from '@angular/core';
import { NgbActiveModal } from '@ng-bootstrap/ng-bootstrap';
import { SubGroupService } from './subgroups.service';
import { ISubgroup, Subgroup } from '../../shared/model/subgroup.model';
import { USER_TYPE, CONTENT_TYPE } from '../../shared/model/subgroup.model';

@Component({
    selector: 'jhi-create-subgroup',
    templateUrl: './create-subgroup.component.html',
    styleUrls: ['./subgroups.component.css']
})
export class CreateSubgroupComponent implements OnInit {
    groupName: string;
    validationErrorMessage: string;
    @Input() isAdmin;
    constructor(public subGroupService: SubGroupService, public activeModal: NgbActiveModal) {}

    ngOnInit() {}

    createSubgroup() {
        let usertype;
        console.log('create group  isAdmin....', this.isAdmin);
        if (this.isAdmin) {
            usertype = USER_TYPE.ROLE_ADMIN;
        } else {
            usertype = USER_TYPE.ROLE_COMPANY_ADMIN;
        }
        const reqObj = new Subgroup(CONTENT_TYPE.ALL, null, this.groupName, usertype, null);
        console.log('reqObj', reqObj);
        this.subGroupService.createSubgroup(reqObj).subscribe((response: any) => {
            console.log('groupList........', response);
            this.activeModal.close('createSubgroup');
        });
    }
}
