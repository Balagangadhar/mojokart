import { Component, OnInit, Input } from '@angular/core';
import { NgbActiveModal } from '@ng-bootstrap/ng-bootstrap';
import { SubGroupService } from './subgroups.service';

@Component({
    selector: 'jhi-delete-subgroup',
    templateUrl: './delete-subgroup.component.html',
    styles: []
})
export class DeleteSubgroupComponent implements OnInit {
    @Input() subgroupId;
    constructor(public subGroupService: SubGroupService, public activeModal: NgbActiveModal) {}
    ngOnInit() {}

    deleteGroup() {
        console.log('delete sub group');
        this.subGroupService.deleteSubgroup(this.subgroupId).subscribe((response: any) => {
            console.log('groupList........', response);
            this.activeModal.close('deleteSubgroup');
        });
    }
}
