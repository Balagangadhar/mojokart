import { Component, OnInit } from '@angular/core';
import { SubGroupService } from './subgroups.service';
import { UserAssignSubgroupComponent } from './user-assign-subgroup.component';
import { DeleteSubgroupComponent } from './delete-subgroup.component';
import { CommonUtil } from '../../shared/util/common-util';
import { NgbModal } from '@ng-bootstrap/ng-bootstrap';
import { CreateSubgroupComponent } from './create-subgroup.component';
import { USER_TYPE, CONTENT_TYPE } from '../../shared/model/subgroup.model';
import { ISubgroup } from '../../shared/model/subgroup.model';
import { AccountService } from '../../core/auth/account.service';

@Component({
    selector: 'jhi-subgroups',
    templateUrl: './subgroups.component.html',
    styleUrls: ['./subgroups.component.css']
})
export class SubgroupsComponent implements OnInit {
    groupsList: ISubgroup[];
    isAdmin: boolean;
    constructor(
        public accountService: AccountService,
        public subGroupService: SubGroupService,
        private commonUtil: CommonUtil,
        private modalService: NgbModal
    ) {
        this.accountService.hasAuthority('ROLE_ADMIN').then(isAdmin => {
            this.isAdmin = isAdmin;
        });
    }
    ngOnInit() {
        this.getGroupsList();
    }

    getGroupsList() {
        let usertype;
        console.log('isAdmin....', this.isAdmin);
        if (this.isAdmin) {
            usertype = USER_TYPE.ROLE_ADMIN;
        } else {
            usertype = USER_TYPE.ROLE_COMPANY_ADMIN;
        }
        console.log('subgroup component usertype', usertype);
        this.subGroupService.getTemplateGroups(usertype, CONTENT_TYPE.ALL).subscribe((response: any) => {
            console.log('groupList........', response);
            this.groupsList = response;
        });
    }

    editSubGroup(groupId) {
        console.log('edit groud id ', groupId);
        const options = this.commonUtil.getModalPopUpSettings();
        delete options.size;
        const modalRef = this.modalService.open(UserAssignSubgroupComponent, options);
        const groupObj = this.groupsList.find(g => parseInt(groupId, 0) === g.id);
        console.log('this.groupsList  ', this.groupsList);
        modalRef.componentInstance.btnAction = 'edit';
        modalRef.componentInstance.editGroupId = groupObj.id;
        modalRef.componentInstance.editGroupName = groupObj.name;
        modalRef.componentInstance.isAdmin = this.isAdmin;
        modalRef.result.then(result => {
            if (result === 'assignUser') {
                this.getGroupsList();
            }
        });
    }
    deleteSubGroup(groupId) {
        const options = this.commonUtil.getModalPopUpSettings();
        delete options.size;
        const modalRef = this.modalService.open(DeleteSubgroupComponent, options);
        const groupObj = this.groupsList.find(g => parseInt(groupId, 0) === g.id);
        modalRef.componentInstance.subgroupId = groupObj.id;
        modalRef.result.then(result => {
            if (result === 'deleteSubgroup') {
                console.log('sub group deleted successfully...');
                this.getGroupsList();
            }
        });
    }
    createSubGroup() {
        const options = this.commonUtil.getModalPopUpSettings();
        delete options.size;
        const modalRef = this.modalService.open(CreateSubgroupComponent, options);
        modalRef.componentInstance.isAdmin = this.isAdmin;
        modalRef.result.then(result => {
            if (result === 'createSubgroup') {
                console.log('sub group created successfully...');
                this.getGroupsList();
            }
        });
    }
    assignUserToSubgroup() {
        const options = this.commonUtil.getModalPopUpSettings();
        delete options.size;
        const modalRef = this.modalService.open(UserAssignSubgroupComponent, options);
        modalRef.componentInstance.btnAction = 'create';
        modalRef.componentInstance.isAdmin = this.isAdmin;
        modalRef.result.then(result => {
            if (result === 'assignUser') {
                this.getGroupsList();
            }
        });
    }
}
