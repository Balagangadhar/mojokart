import { Injectable } from '@angular/core';
import { Observable, of, throwError } from 'rxjs';
import { catchError } from 'rxjs/operators';
import { HttpClient, HttpResponse, HttpHeaders, HttpHandler, HttpErrorResponse } from '@angular/common/http';
import { SERVER_API_URL } from 'app/app.constants';
import { ISubgroup, Subgroup, IUser } from '../../shared/model/subgroup.model';

@Injectable({
    providedIn: 'root'
})
export class SubGroupService {
    private subgroupUrl = SERVER_API_URL + 'api/sub-groups';
    private usersUrl = SERVER_API_URL + 'api/companies';
    constructor(private http: HttpClient) {}
    getTemplateGroups(type: string, contentType: string): Observable<ISubgroup> {
        return this.http.get<ISubgroup>(this.subgroupUrl + '/?type=' + type + '&contentType=' + contentType);
    }

    createSubgroup(requestObj: Subgroup): Observable<ISubgroup> {
        return this.http.post<ISubgroup>(this.subgroupUrl, requestObj);
    }

    getUserList(companyId): Observable<IUser> {
        return this.http.get<ISubgroup>(`${this.usersUrl}/${companyId}/users`);
    }
    getUserListBysubgroupId(subgroupId): Observable<IUser> {
        return this.http.get<ISubgroup>(`${this.subgroupUrl}/${subgroupId}`);
    }

    assignUserToSubgroup(requestObj: Subgroup): Observable<ISubgroup> {
        return this.http.put<ISubgroup>(this.subgroupUrl, requestObj);
    }

    deleteSubgroup(subgroupId): Observable<any> {
        return this.http.delete(`${this.subgroupUrl}/${subgroupId}`);
    }
}
