import { Routes } from '@angular/router';
import { SubgroupsComponent } from './subgroups.component';
import { UserRouteAccessService } from 'app/core';
import { JhiResolvePagingParams } from 'ng-jhipster';

export const subGroupsRoutes: Routes = [
    {
        path: 'subgroups',
        component: SubgroupsComponent,
        resolve: {
            pagingParams: JhiResolvePagingParams
        },
        data: {
            authorities: ['ROLE_USER'],
            defaultSort: 'id,asc',
            pageTitle: 'Subgroups'
        },
        canActivate: [UserRouteAccessService]
    }
];
