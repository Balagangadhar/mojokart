import { Component, Inject } from '@angular/core';
import { Contact } from './../../shared/model/contact.model';
import { MAT_DIALOG_DATA, MatDialogRef } from '@angular/material';
@Component({
    selector: 'jhi-view-contact',
    templateUrl: 'jhi-view-contact.html',
    styleUrls: ['./contact-list.component.css']
})
export class ViewContactComponent {
    constructor(public dialogRef: MatDialogRef<ViewContactComponent>, @Inject(MAT_DIALOG_DATA) public contact: Contact) {}

    onNoClick(): void {
        this.dialogRef.close();
    }
}
