import { Component, Inject } from '@angular/core';

import { MAT_DIALOG_DATA, MatDialogRef } from '@angular/material';
import { ContactList } from 'app/shared/model/contact-list.model';
@Component({
    selector: 'jhi-update-list',
    templateUrl: 'jhi-update-list.html',
    styleUrls: ['./contact-list.component.css']
})
export class UpdateListComponent {
    constructor(public dialogRef: MatDialogRef<UpdateListComponent>, @Inject(MAT_DIALOG_DATA) public contactList: ContactList) {}
}
