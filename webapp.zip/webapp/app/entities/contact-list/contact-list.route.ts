import { Injectable } from '@angular/core';
import { Resolve, ActivatedRouteSnapshot, RouterStateSnapshot, Routes, RouterModule } from '@angular/router';
import { HttpResponse } from '@angular/common/http';
import { Observable, of } from 'rxjs';
import { filter, map } from 'rxjs/operators';
import { ContactListComponent } from './contact-list.component';
import { ContactListService } from './contact-list.service';
import { IContactList, ContactList } from 'app/shared/model/contact-list.model';
import { UserRouteAccessService } from 'app/core';
import { JhiResolvePagingParams } from 'ng-jhipster';
import { ViewListComponent } from './view-list/view-list.component';

export const contactListRoutes: Routes = [
    {
        path: 'contact-list',
        component: ContactListComponent,
        resolve: {
            pagingParams: JhiResolvePagingParams
        },
        data: {
            authorities: ['ROLE_USER'],
            defaultSort: 'id,asc',
            pageTitle: 'Contact Lists'
        },
        canActivate: [UserRouteAccessService]
    },
    {
        path: 'view-list/:id',
        component: ViewListComponent,
        resolve: {
            pagingParams: JhiResolvePagingParams
        },
        data: {
            authorities: ['ROLE_USER'],
            defaultSort: 'id,asc',
            pageTitle: 'Contact Lists'
        },
        canActivate: [UserRouteAccessService]
    }
];

@Injectable({ providedIn: 'root' })
export class ContactListResolve implements Resolve<IContactList> {
    constructor(private service: ContactListService) {}

    resolve(route: ActivatedRouteSnapshot, state: RouterStateSnapshot): Observable<ContactList> {
        const id = route.params['id'] ? route.params['id'] : null;
        if (id) {
            return this.service.find(id).pipe(
                filter((response: HttpResponse<ContactList>) => response.ok),
                map((contactList: HttpResponse<ContactList>) => contactList.body)
            );
        }
        return of(new ContactList());
    }
}
