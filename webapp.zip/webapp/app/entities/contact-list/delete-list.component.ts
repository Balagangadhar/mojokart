import { Component, Inject } from '@angular/core';
import { MAT_DIALOG_DATA, MatDialogRef } from '@angular/material';
import { ContactList } from 'app/shared/model/contact-list.model';

@Component({
    selector: 'jhi-delete-contact',
    templateUrl: 'jhi-delete-list.html',
    styleUrls: ['./contact-list.component.css']
})
export class DeleteContactListComponent {
    constructor(public dialogRef: MatDialogRef<DeleteContactListComponent>, @Inject(MAT_DIALOG_DATA) public contactList: ContactList) {}

    onNoClick(): void {
        this.dialogRef.close();
    }
}
