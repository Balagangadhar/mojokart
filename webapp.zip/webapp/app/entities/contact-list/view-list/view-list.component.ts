import { Component, AfterViewInit, ViewChild } from '@angular/core';
import { ContactList } from 'app/shared/model/contact-list.model';
import { MatDialog, MatDialogRef, MAT_DIALOG_DATA, MatPaginator, MatSort } from '@angular/material';
import { HttpClient } from '@angular/common/http';
import { merge, Observable, of as observableOf } from 'rxjs';
import { startWith, switchMap, map, catchError } from 'rxjs/operators';
import { ContactListService } from '..';
import { ActivatedRoute } from '@angular/router';
import { Contact } from 'app/shared/model/contact.model';
import { ViewContactComponent } from '../view-contact.component';
import { DeleteContactViewComponent } from '../delete-view-contact.component';
@Component({
    selector: 'jhi-view-list',
    templateUrl: './view-list.component.html',
    styleUrls: ['../contact-list.component.css']
})
export class ViewListComponent implements AfterViewInit {
    displayedColumns: string[] = ['name', 'email', 'phone', 'actions'];
    apiService: ContactListService | null;
    dataSource = [];
    contactSource: Contact[] = [];
    listName = '';
    searchText = '';
    resultsLength = 0;
    isLoadingResults = true;
    isRateLimitReached = false;
    @ViewChild(MatPaginator) paginator: MatPaginator;

    @ViewChild(MatSort) sort: MatSort;

    listById: any;

    constructor(private http: HttpClient, public dialog: MatDialog, private route: ActivatedRoute) {}
    ngAfterViewInit() {
        this.apiService = new ContactListService(this.http);
        this.sort.sortChange.subscribe(() => (this.paginator.pageIndex = 0));
        this.getListById();
        merge(this.sort.sortChange, this.paginator.page)
            .pipe(
                startWith({}),
                switchMap(() => {
                    this.isLoadingResults = true;
                    return this.apiService!.getContactViewListById(
                        this.listById,
                        this.sort.active,
                        this.sort.direction,
                        this.paginator.pageIndex,
                        this.paginator.pageSize,
                        this.searchText
                    );
                }),
                map(data => {
                    this.isLoadingResults = false;
                    this.isRateLimitReached = false;
                    this.resultsLength = data.headers.get('X-Total-Count');
                    return data;
                }),
                catchError(() => {
                    this.isLoadingResults = false;
                    this.isRateLimitReached = true;
                    return observableOf([]);
                })
            )
            .subscribe(data => {
                this.dataSource = data.body;
            });
    }
    onEdit(contactList: ContactList): void {
        const dialogRef2 = this.dialog.open(ViewContactComponent, {
            width: 'auto',
            data: contactList
        });
        dialogRef2.afterClosed().subscribe((result: ContactList) => {
            console.log('The dialog was closed' + JSON.stringify(result));
            if (result) {
                result.lastModifiedDate = null;
                console.log('updating..' + result);

                this.apiService.update(result);
            }
        });
    }
    // delete contact
    onDelete(contactRef: Contact): void {
        // http://test.ett-iboomerang.com/api/contact-lists/3/contacts
        const dialogRef2 = this.dialog.open(DeleteContactViewComponent, {
            width: 'auto',
            data: contactRef
        });
        dialogRef2.afterClosed().subscribe(contact => {
            console.log('The dialog was closed' + JSON.stringify(contact));
            if (contact) {
                console.log(contactRef.id, 'deleting..' + this.listById);
                this.apiService.deleteContactFromContactList(contact.id, this.listById).subscribe(() => this.ngAfterViewInit());
            }
        });
    }
    onView(contact: Contact): void {
        console.log(contact);
        const dialogRef2 = this.dialog.open(ViewContactComponent, {
            width: 'auto',
            data: contact
        });
        dialogRef2.afterClosed().subscribe((result: Contact) => {
            console.log('The dialog was closed' + JSON.stringify(result));
        });
    }
    getListById() {
        const routeId: any = this.route.snapshot.paramMap.get('id');
        this.listById = routeId;
        this.apiService.getContactListById(routeId).subscribe((data: ContactList) => {
            this.listName = data.name;
            console.log(data);
        });
    }
    applyFilter(searchText: string) {
        this.searchText = searchText;
        this.ngAfterViewInit();
    }
}
