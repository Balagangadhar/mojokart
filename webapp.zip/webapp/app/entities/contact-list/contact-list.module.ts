import { NgModule, CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MaterialModule } from '../material.module';
import { FormsModule } from '@angular/forms';
import { RouterModule } from '@angular/router';
import { ContactListComponent, contactListRoutes } from './';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material';
import { DeleteContactListComponent } from './delete-list.component';
import { UpdateListComponent } from './update-list.component';
import { ViewListComponent } from './view-list/view-list.component';
import { ViewContactComponent } from './view-contact.component';
import { ListFileUploadComponent } from './list-file-upload.component';
import { FileUploadModule } from 'ng2-file-upload';
import { DeleteContactComponent } from '../contact/delete-contact.component';
import { DeleteContactViewComponent } from './delete-view-contact.component';
import { SharedCommonModule } from '../../shared/shared-common.module';

const ENTITY_STATES = [...contactListRoutes];

@NgModule({
    declarations: [
        ContactListComponent,
        DeleteContactListComponent,
        DeleteContactViewComponent,
        UpdateListComponent,
        ViewListComponent,
        ViewContactComponent,
        ListFileUploadComponent
    ],
    imports: [CommonModule, FileUploadModule, FormsModule, MaterialModule, SharedCommonModule, RouterModule.forChild(ENTITY_STATES)],
    exports: [SharedCommonModule],
    entryComponents: [
        DeleteContactListComponent,
        UpdateListComponent,
        ViewContactComponent,
        DeleteContactViewComponent,
        ListFileUploadComponent
    ],
    schemas: [CUSTOM_ELEMENTS_SCHEMA],
    providers: [{ provide: MAT_DIALOG_DATA, useValue: {} }, { provide: MatDialogRef, useValue: {} }]
})
export class ContactListModule {}
