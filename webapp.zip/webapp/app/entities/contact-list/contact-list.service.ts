import { Injectable } from '@angular/core';
import { Contact } from './../../shared/model/contact.model';
import { HttpClient, HttpResponse, HttpHeaders } from '@angular/common/http';
import { Observable } from 'rxjs';
import { SERVER_API_URL } from 'app/app.constants';
import { ContactList } from '../../shared/model/contact-list.model';
import { IContactList } from '../../shared/model/contact-list.model';
type EntityResponseType = HttpResponse<ContactList>;
type EntityArrayResponseType = HttpResponse<ContactList[]>;
type EntityArrayResponseTypeContact = HttpResponse<Contact[]>;
@Injectable({
    providedIn: 'root'
})
export class ContactListService {
    private resourceUrl = SERVER_API_URL + 'api/contact-lists';

    constructor(private http: HttpClient) {}

    find(id: number): Observable<EntityResponseType> {
        return this.http.get<ContactList>(`${this.resourceUrl}/${id}`, { observe: 'response' });
    }

    // getContactLists(): Observable<ContactList[]> {
    //     return this.http.get<ContactList[]>(this.resourceUrl);
    // }
    getContactListsWithPagination(): Observable<EntityArrayResponseType> {
        return this.http.get<IContactList[]>(this.resourceUrl, { observe: 'response' });
    }
    getContactLists(sortParam: string, order: string, page: number, pageSize: number, name: string): Observable<any> {
        // console.log(sortParam, order, page);
        const requestUrl = `${this.resourceUrl}?page=${page}&size=${pageSize}&sort=${sortParam}%2C${order}&name=${name}`;
        console.log('inside contact List service...........');
        // this.http.get<EntityArrayResponseType>(requestUrl, { observe: 'response' }).subscribe(data => console.log(data.body));
        return this.http.get<EntityArrayResponseTypeContact>(requestUrl, { observe: 'response' });
    }

    update(contactList: ContactList): Observable<any> {
        // this.http.put<ContactList>(this.resourceUrl, contactList).subscribe(data => console.log(JSON.stringify(data)));
        return this.http.put<ContactList>(this.resourceUrl, contactList, { observe: 'response' });
    }

    create(contactList: ContactList): Observable<any> {
        // this.http.post<ContactList>(this.resourceUrl, contactList).subscribe(data => console.log(JSON.stringify(data)));
        return this.http.post<ContactList>(this.resourceUrl, contactList);
    }

    delete(id: number): Observable<any> {
        return this.http.delete<any>(this.resourceUrl + '/' + id);
    }

    async export(listId: number) {
        return await this.http.post<Blob>(this.resourceUrl + `/export/${listId}`, null, { responseType: 'blob' as 'json' }).toPromise();
    }

    getContactListById(listId: number): Observable<ContactList> {
        const url = this.resourceUrl + '/' + listId;
        console.log('list url ', url);
        return this.http.get<ContactList>(url);
    }
    getContactViewListById(
        listId: number,
        sortParam: string,
        order: string,
        page: number,
        pageSize: number,
        searchText: string
    ): Observable<any> {
        const url = this.resourceUrl + '/' + listId + '/filter-contacts'; //
        const requestUrl = `${url}?page=${page}&size=${pageSize}&sort=${sortParam}%2C${order}&searchText=${searchText}`;
        console.log('inside contact List service...........', requestUrl);
        // this.http.get<EntityArrayResponseType>(requestUrl, { observe: 'response' }).subscribe(data => console.log(data.body));
        return this.http.get<EntityResponseType>(requestUrl, { observe: 'response' });
    }
    getContactListName(listId: number): Observable<ContactList> {
        const url = this.resourceUrl + '/' + listId;
        return this.http.get<ContactList>(url);
    }
    deleteContactFromContactList(contactId: number, listId: number): Observable<any> {
        console.log(listId, contactId);
        // /101/contacts?ids=81
        return this.http.delete<any>(this.resourceUrl + '/' + listId + '/contacts?ids=' + contactId);
    }
    getAllLists(): Observable<any> {
        console.log(this.resourceUrl);
        return this.http.get<EntityArrayResponseType>(this.resourceUrl + '?size=2147483647', { observe: 'response' });
    }
    updateContactList(id: number, contacts: Contact[]): Observable<any> {
        // this.http.post<ContactList>(this.resourceUrl, contactList).subscribe(data => console.log(JSON.stringify(data)));
        // POST / api / contact - lists / { id } / contacts
        return this.http.post<Contact[]>(this.resourceUrl + '/' + id + '/' + 'contacts', contacts);
    }
}
