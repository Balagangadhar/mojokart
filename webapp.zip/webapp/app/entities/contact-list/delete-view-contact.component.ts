import { Contact } from '../../shared/model/contact.model';
import { Component, Inject } from '@angular/core';
import { MAT_DIALOG_DATA, MatDialogRef } from '@angular/material';

@Component({
    selector: 'jhi-delete-view-contact',
    templateUrl: 'jhi-delete-view-contact.component.html',
    styleUrls: ['./contact-list.component.css']
})
export class DeleteContactViewComponent {
    constructor(public dialogRef: MatDialogRef<DeleteContactViewComponent>, @Inject(MAT_DIALOG_DATA) public contact: Contact) {}

    onNoClick(): void {
        this.dialogRef.close();
    }
}
