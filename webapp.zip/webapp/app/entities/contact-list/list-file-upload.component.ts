import { ContactListService } from './contact-list.service';
import { MAT_DIALOG_DATA, MatDialogRef } from '@angular/material';
import { SERVER_API_URL } from 'app/app.constants';
import { Component, OnInit, DoCheck, Inject } from '@angular/core';
import { FileUploader, FileLikeObject } from 'ng2-file-upload';
import { LocalStorageService, SessionStorageService } from 'ngx-webstorage';
@Component({
    selector: 'jhi-file-upload',
    templateUrl: 'jhi-list-file-upload.html',
    styleUrls: ['./contact-list.component.css']
})
export class ListFileUploadComponent implements OnInit, DoCheck {
    public resourceUrl: any = SERVER_API_URL + 'api/contact-lists/';
    public url = '';
    public accept: Array<string> = ['text/csv'];
    public maxFileSize: number = 10 * 1024 * 1024; // 10MB
    public maxFile: any = 1; // Default 0 is unlimited
    public multiple: any = false; // Default false is single file, true is multiple file
    public errorMessageMaxSize: any = "'File size great than 10 MB Not Allowed'";
    public errorMessageWrongType: any = "'Not allow file format'";
    public errorMessageLimit: any = "'Maximum files'";
    public token: string;
    public errorMessage: any = '';
    public uploader: FileUploader = new FileUploader({});
    public listName: string;
    allListName;
    campaignSelected;
    selectedLevel;
    uploadEnable: Boolean = false;

    constructor(
        private contactService: ContactListService,
        private localStorage: LocalStorageService,
        private sessionStorage: SessionStorageService,
        public dialogRef: MatDialogRef<ListFileUploadComponent>,
        @Inject(MAT_DIALOG_DATA) public name: string
    ) {
        this.allListName = name;
    }
    // constructor(private localStorage: LocalStorageService, private sessionStorage: SessionStorageService) { }
    public ngDoCheck() {
        console.log('ngDoCheck view init ', this.listName);
        this.token = this.token = this.localStorage.retrieve('authenticationToken') || this.sessionStorage.retrieve('authenticationToken');
        this.urlBuilder();
        this.uploader.setOptions({
            url: this.url,
            autoUpload: false,
            maxFileSize: this.maxFileSize,
            method: 'post',
            itemAlias: 'file',
            authToken: 'Bearer ' + this.token
            // additionalParameter: [{name: 'viajy'}]
        });
    }
    public ngOnInit() {
        this.contactService.getAllLists().subscribe(data => {
            console.log(JSON.stringify(data.body));
            this.allListName = data.body;
        });
    }
    public urlBuilder() {
        if (this.campaignSelected === 'NewList') {
            this.url = '';
            this.url = this.resourceUrl + 'import?name=' + this.listName;
            console.log(this.url);
            if (this.listName) {
                this.uploadEnable = true;
            } else {
                this.uploadEnable = false;
            }
        } else if (this.campaignSelected === 'ExistingList') {
            this.url = '';
            if (this.selectedLevel) {
                this.url = this.resourceUrl + this.selectedLevel.id + '/import';
                this.uploadEnable = true;
                console.log(this.url);
            }
        }
    }
    /**
     * Check file is image
     *
     * @param {*} fileType
     * @returns {boolean}
     */
    public isImage(fileType: any): boolean {
        return /^image\/(.*)$/.test(fileType);
    }

    /**
     * Check max file
     *
     * @returns {boolean}
     */
    public isMaxFile(): boolean {
        if (this.maxFile === 0) {
            return false;
        }
        return this.uploader.queue.length >= this.maxFile;
    }

    /**
     * Get queue files
     *
     * @returns {*}
     */
    public getQueueFiles(): Array<any> {
        return this.uploader.queue;
    }

    /**
     * Set queue files
     *
     * @returns {*}
     */
    public setQueueFiles(queue: Array<any>): void {
        this.uploader.queue = queue;
    }

    /**
     * Get all files in queue
     *
     * @returns {*}
     */
    public getFiles(): Array<any> {
        return this.uploader.queue.map(item => item.file);
    }

    /**
     * Add file failed hanlde
     *
     * @private
     * @param {FileLikeObject} item
     * @param {*} filter
     * @param {*} options
     */
    private onWhenAddingFileFailed(item: FileLikeObject, filter: any, options: any) {
        console.log('filter.name ', filter);
        switch (filter.name) {
            case 'fileSize': {
                this.errorMessage = this.errorMessageMaxSize;
                break;
            }
            case 'mimeType': {
                this.errorMessage = this.errorMessageWrongType;
                break;
            }
            default:
        }
    }

    /**
     * Handle choice files
     *
     * @private
     * @param {*} items
     */
    private onAfterAddingAll(items: any) {
        if (items.length > this.maxFile) {
            this.uploader.clearQueue();
            // this.fileInput.nativeElement.value = '';
            this.errorMessage = this.errorMessageLimit;
            //  this.onItemChanged.emit(this.getQueueFiles());
            return;
        }
    }

    /**
     * Handle add file
     *
     * @private
     * @param {*} item
     */
    private onAfterAddingFile(item: any) {
        if (this.checkDuplicateFiles(item)) {
            item.remove();
            //    this.onItemChanged.emit(this.getQueueFiles());
        }
    }

    /**
     * Check duplicate file
     *
     * @private
     * @param {*} item
     * @returns {boolean}
     */
    private checkDuplicateFiles(item: any): boolean {
        let checkItem: any = 0;
        this.uploader.queue.map(itemQueue => {
            checkItem += itemQueue.file.name === item.file.name && itemQueue.file.size === item.file.size ? 1 : 0;
        });

        return checkItem > 1;
    }
    onUpdateExistingList() {
        // required url request
    }

    public UploadDocFiles() {
        console.log('calling');
        this.uploader.uploadAll();
        console.log('suc');
        // setTimeout(() => this.uploadDone.emit(true), 1150);
    }
}
