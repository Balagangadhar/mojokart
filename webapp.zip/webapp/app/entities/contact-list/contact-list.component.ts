import { Component, OnInit, ViewChild, ViewEncapsulation, AfterViewInit, ElementRef } from '@angular/core';
import { ListFileUploadComponent } from './list-file-upload.component';
import { MatDialog, MatDialogRef, MAT_DIALOG_DATA, MatPaginator, MatSort } from '@angular/material';
import { ContactListService } from './contact-list.service';
import { ContactList } from 'app/shared/model/contact-list.model';
import { HttpClient } from '@angular/common/http';
import { merge, Observable, of as observableOf } from 'rxjs';
import { startWith, switchMap, map, catchError } from 'rxjs/operators';
import { DeleteContactListComponent } from '../contact-list/delete-list.component';
import { UpdateListComponent } from './update-list.component';
import { Router } from '@angular/router';
import { FileUpload } from 'app/shared/model/file-upload.model';
@Component({
    selector: 'jhi-contact-list',
    templateUrl: './contact-list.component.html',
    encapsulation: ViewEncapsulation.None,
    styleUrls: ['./contact-list.component.css']
})
export class ContactListComponent implements AfterViewInit {
    displayedColumns: string[] = ['name', 'createdDate', 'lastModifiedDate', 'actions'];
    apiService: ContactListService | null;
    dataSource: ContactList[] = [];
    contactList: ContactList;
    resultsLength = 0;
    isLoadingResults = true;
    isRateLimitReached = false;
    @ViewChild(MatPaginator) paginator: MatPaginator;
    @ViewChild(MatSort) sort: MatSort;
    @ViewChild('exportLink')
    exportLink: ElementRef;
    listName = 'list1';
    searchText = '';

    constructor(private http: HttpClient, public dialog: MatDialog, private router: Router) {}

    ngAfterViewInit() {
        this.apiService = new ContactListService(this.http);
        this.sort.sortChange.subscribe(() => (this.paginator.pageIndex = 0));
        merge(this.sort.sortChange, this.paginator.page)
            .pipe(
                startWith({}),
                switchMap(() => {
                    this.isLoadingResults = true;
                    return this.apiService!.getContactLists(
                        this.sort.active,
                        this.sort.direction,
                        this.paginator.pageIndex,
                        this.paginator.pageSize,
                        this.searchText
                    );
                }),
                map(data => {
                    // Flip flag to show that loading has finished.
                    this.isLoadingResults = false;
                    this.isRateLimitReached = false;
                    this.resultsLength = data.headers.get('X-Total-Count');
                    console.log('in map' + JSON.stringify(data));
                    return data;
                }),
                catchError(() => {
                    this.isLoadingResults = false;
                    // Catch if the  API has reached its rate limit. Return empty data.
                    this.isRateLimitReached = true;
                    return observableOf([]);
                })
            )
            .subscribe(data => {
                this.dataSource = data.body;
                console.log('in component' + JSON.stringify(this.dataSource));
            });
    }

    onEdit(contactList: ContactList): void {
        const dialogRef2 = this.dialog.open(UpdateListComponent, {
            width: 'auto',
            data: contactList,
            disableClose: true
        });
        dialogRef2.afterClosed().subscribe((result: ContactList) => {
            if (result) {
                console.log(result, 'edit values');
                result.lastModifiedDate = null;
                this.apiService.update(result).subscribe(res => {
                    this.ngAfterViewInit();
                });
            }
        });
    }

    onDelete(contactList: ContactList): void {
        const dialogRef2 = this.dialog.open(DeleteContactListComponent, {
            width: 'auto',
            data: contactList,
            disableClose: true
        });
        dialogRef2.afterClosed().subscribe(result => {
            if (result) {
                this.apiService.delete(result).subscribe(() => this.ngAfterViewInit());
            }
        });
    }

    onView(listId: number): void {
        this.router.navigate(['/view-list', listId]);
    }

    async onExport(id: number, name: string) {
        const blob = await this.apiService.export(id);
        const url = window.URL.createObjectURL(blob);
        const link = this.exportLink.nativeElement;
        link.href = url;
        link.download = `${name}.csv`;
        link.click();
        window.URL.revokeObjectURL(url);
    }

    fileUploadDilaog() {
        const dialogRef2 = this.dialog.open(ListFileUploadComponent, {
            width: 'auto',
            data: this.listName,
            disableClose: true
        });
        dialogRef2.afterClosed().subscribe(result => {
            // if (result) {
            //     console.log('Uploading..' + result);
            // }
            setTimeout(() => {
                this.ngAfterViewInit();
            }, 1600);
        });
    }
    applyFilter(searchText: string) {
        this.searchText = searchText;
        this.ngAfterViewInit();
    }
}
