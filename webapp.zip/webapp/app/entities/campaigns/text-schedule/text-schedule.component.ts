import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { ScheduleDate } from 'app/shared/model/email-campaign-regular.model';
import { NgbDate } from '@ng-bootstrap/ng-bootstrap';

@Component({
    selector: 'jhi-text-schedule',
    templateUrl: './text-schedule.component.html',
    styles: []
})
export class TextScheduleComponent implements OnInit {
    campaignName: any;

    year: string;
    month: string;
    day: string;
    scheduleDate: string;
    number: any;
    constructor(private route: ActivatedRoute) {}

    ngOnInit() {
        this.campaignName = this.route.snapshot.queryParams['campaignName'];
        this.year = this.route.snapshot.queryParams['year'];
        this.day = this.route.snapshot.queryParams['day'];
        this.month = this.route.snapshot.queryParams['month'];
        this.scheduleDate = this.day + '/' + this.month + '/' + this.year;
        console.log(this.scheduleDate);
    }
}
