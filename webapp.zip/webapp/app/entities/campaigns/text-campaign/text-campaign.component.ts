import { CampaignTextDialogComponent } from './text-dialog.component';
import { Campaign } from './../../../shared/model/email-campaign-regular.model';
import { CampaignService } from './../campaigns.service';
import { TextCampaign, TextDetails } from './../../../shared/model/text-campaign.model';
import { ScheduleDialogComponent } from './schedule-dialog.component';
import { CannedMessage } from './../../../shared/model/canned-message.model';
import { Component, ViewChild, AfterViewInit, DoCheck } from '@angular/core';
import { MatPaginator, MatSort, MatDialog } from '@angular/material';
import { SelectionModel } from '@angular/cdk/collections';
import { HttpClient } from '@angular/common/http';
import { merge, Observable, of as observableOf } from 'rxjs';
import { startWith, switchMap, map, catchError } from 'rxjs/operators';
import { Account } from 'app/shared/model/account.model';
import { AccountService } from 'app/core';
import { ContactService } from 'app/entities/contact';
import { Contact } from 'app/shared/model/contact.model';
import { TextCannedDialogComponent } from './text-canned.component';
import { CampaignSchedule } from 'app/shared/model/email-campaign-regular.model';
import { ActivatedRoute, Router } from '@angular/router';
import { EditTextCampaignComponent } from './edit-text-campaign/edit-text-campaign.component';
import { CampaignDeleteComponent } from '../campaign-delete.component';

@Component({
    selector: 'jhi-text-campaign',
    templateUrl: './text-campaign.component.html',
    styleUrls: ['./text-campaign.component.css']
})
export class TextCampaignComponent implements AfterViewInit, DoCheck {
    @ViewChild(MatPaginator) paginator!: MatPaginator;
    @ViewChild(MatSort) sort!: MatSort;
    marketingListName = '';
    startCampaign: Boolean = false;
    marketingListNameEdit: Boolean = false;
    // currentAccount: Account;
    displayedColumns: string[] = ['select', 'name', 'phone', 'actions'];
    apiService: ContactService | null;
    dataSource: Contact[] = [];
    scheduleButton: Boolean = false;
    sendButton: Boolean = false;
    composeMessage = '';
    resultsLength = 0;
    isLoadingResults = true;
    isRateLimitReached = false;
    selection = new SelectionModel<Contact>(true, []);
    searchText = '';
    textCampaign: TextCampaign = {};
    textCampaignSchedule: CampaignSchedule = {};
    accountResponse: any;

    constructor(
        private accountService: AccountService,
        public dialog: MatDialog,
        private http: HttpClient,
        private campaignService: CampaignService,
        public router: Router,
        private route: ActivatedRoute
    ) {
        this.getIdFromUrl();
        this.accountService.identity().then(account => {
            this.accountResponse = account;
        });
    }

    isAllSelected() {
        const numSelected = this.selection.selected.length;
        const numRows = this.dataSource.length;
        return numSelected === numRows;
    }
    masterToggle() {
        this.isAllSelected() ? this.selection.clear() : this.dataSource.forEach(row => this.selection.select(row));
    }
    ngAfterViewInit() {
        this.contactTable();
    }
    onDelete(campaign): void {
        console.log(campaign);
        const dialogRef = this.dialog.open(CampaignDeleteComponent, {
            width: 'auto',
            data: campaign,
            disableClose: true
        });
        dialogRef.afterClosed().subscribe(result => {
            console.log(result);

            if (result && result.id) {
                this.apiService.deleteOptedInContact(result.id).subscribe(() => this.ngAfterViewInit());
            }
        });
    }
    contactTable() {
        this.apiService = new ContactService(this.http);
        this.sort.sortChange.subscribe(() => (this.paginator.pageIndex = 0));
        merge(this.sort.sortChange, this.paginator.page)
            .pipe(
                startWith({}),
                switchMap(() => {
                    this.isLoadingResults = true;
                    return this.apiService!.getOptedInContact(
                        this.sort.active,
                        this.sort.direction,
                        this.paginator.pageIndex,
                        this.paginator.pageSize,
                        this.searchText
                    );
                }),
                map(data => {
                    this.isLoadingResults = false;
                    this.isRateLimitReached = false;
                    this.resultsLength = data.headers.get('X-Total-Count');
                    return data;
                }),
                catchError(() => {
                    this.isLoadingResults = false;
                    this.isRateLimitReached = true;
                    return observableOf([]);
                })
            )
            .subscribe(data => {
                this.dataSource = data.body;
            });
    }

    applyFilter(searchText: string) {
        this.searchText = searchText;
        this.contactTable();
    }
    //  capture name of text marketing list
    textDialog(): void {
        const dialogRef6 = this.dialog.open(CampaignTextDialogComponent, {
            disableClose: true,
            width: 'auto',
            data: ''
        });
        dialogRef6.afterClosed().subscribe(result => {
            if (result) {
                this.startCampaign = true;
                this.marketingListName = result;
                this.contactTable();
                console.log('The dialog was closed......' + JSON.stringify(this.marketingListName));
                this.createTextCampaign();
            }
        });
    }
    textCannedDialog(): void {
        const dialogRef2 = this.dialog.open(TextCannedDialogComponent, {
            width: 'auto',
            data: this.composeMessage
        });
        dialogRef2.afterClosed().subscribe(result => {
            if (result) {
                this.updateComposeMessage(result);
                console.log('The dialog was closed......' + JSON.stringify(result));
            }
        });
    }
    updateComposeMessage(data: CannedMessage[]) {
        let cannedMessage = '';
        data.forEach(element => {
            cannedMessage += ' ' + element.message;
        });
        this.composeMessage = this.composeMessage + cannedMessage;
    }
    // draft message on event change
    autoSave($event: any) {
        console.log($event.target.value);
        if (!this.sendButton) {
            this.onUpdateTextCampaign();
        }
    }
    activeButton() {
        if (this.selection.selected.length > 0 && this.composeMessage !== '') {
            this.scheduleButton = true;
            this.sendButton = true;
        } else {
            this.scheduleButton = false;
            this.sendButton = false;
        }
    }
    ngDoCheck(): void {
        this.activeButton();
    }
    // scheduling
    onSchedule() {
        this.onUpdateTextCampaign();
        const dialogRef2 = this.dialog.open(ScheduleDialogComponent, {
            disableClose: true,
            width: '200px;',
            height: '400px',
            data: this.textCampaignSchedule
        });
        dialogRef2.afterClosed().subscribe(result => {
            if (result) {
                console.log('The dialog was scheduling......' + JSON.stringify(result));
                console.log(this.textCampaignSchedule, this.textCampaign.id);
                this.campaignService.scheduleTextCampaign(this.textCampaign.id, result).subscribe(data => console.log(data));
                console.log(this.textCampaignSchedule.date);
                this.router.navigate(['/scheduleTextSuccess'], {
                    queryParams: {
                        campaignName: this.textCampaign.name,
                        year: this.textCampaignSchedule.date.year,
                        month: this.textCampaignSchedule.date.month,
                        day: this.textCampaignSchedule.date.day,
                        pageName: 'textSchedule'
                    }
                });
            } else {
                console.log('Scheduling text campaign... FAILED');
            }
        });
    }
    callOnsend() {
        console.log('calling ... after 2Sec');
        this.campaignService.sendTextCampaign(this.textCampaign.id).subscribe(data => console.log(data));
        const users = this.textCampaign.textDetails.contacts.length;
        this.router.navigate(['/sendTextSuccess'], {
            queryParams: {
                campaignName: this.textCampaign.name,
                totalContacts: users,
                pageName: 'textSent'
            }
        });
    }
    onSend() {
        if (this.textCampaign.id) {
            this.onUpdateTextCampaign();
            setTimeout(() => this.callOnsend(), 2000);
        } else {
            console.log('sending text campaign... FAILED');
        }
    }
    createTextCampaign() {
        this.textCampaign.name = this.marketingListName;
        this.textCampaign.type = 'TEXT';
        const text = new TextDetails(this.selection.selected, this.composeMessage);
        this.textCampaign.textDetails = text;
        console.log(this.textCampaign);
        this.campaignService.createTextCampaign(this.textCampaign).subscribe(data => {
            console.log('creating campaign', data);
            this.getTextCampaign(data.id);
        });
    }
    getTextCampaign(id: number) {
        this.campaignService.getCampaignDetailsById(id).subscribe((data: Campaign) => {
            console.log(data);
            this.textCampaign = data;
            this.marketingListName = data.name;
            if (data.textDetails != null) {
                this.composeMessage = this.textCampaign.textDetails.message;
                // this.selection = new SelectionModel<Contact>(true, data.textDetails.contacts);
            }
            //  this.selection.select(... data.textDetails.contacts);
            // this.isAllSelected() ? this.selection.clear() : this.dataSource.forEach(row => this.selection.select(...data.textDetails.contacts));
        });
        console.log('fetching text campaign ', this.textCampaign);
    }
    onUpdateTextCampaign() {
        // const text2 = new TextDetails(this.selection.selected, this.composeMessage);
        let markedContacts = [];
        markedContacts = this.selection.selected.map(item => item['contact']);
        this.marketingListNameEdit = false;
        this.textCampaign.name = this.marketingListName;
        this.textCampaign.textDetails = { message: this.composeMessage, contacts: markedContacts };
        console.log('inside update', this.textCampaign);
        this.campaignService.updateTextCampaign(this.textCampaign).subscribe(() => console.log('updated text campaign'));
    }
    getIdFromUrl() {
        const id = this.route.snapshot.queryParams['id'];
        const update = this.route.snapshot.queryParams['update'];
        console.log(id, update);
        if (id && update) {
            this.startCampaign = true;
            this.getTextCampaign(id);
        } else {
            this.textDialog();
        }
    }
    editCampaignDialog() {
        const dialogRef2 = this.dialog.open(EditTextCampaignComponent, {
            width: 'auto',
            data: this.marketingListName
        });
        dialogRef2.afterClosed().subscribe(result => {
            if (result) {
                this.marketingListName = result;
                this.onUpdateTextCampaign();
                // console.log('The dialog was closed......' + this.marketingListName);
            }
        });
    }
}
