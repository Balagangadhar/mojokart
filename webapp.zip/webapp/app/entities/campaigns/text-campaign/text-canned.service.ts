import { Injectable } from '@angular/core';
import { SERVER_API_URL } from 'app/app.constants';
import { HttpClient, HttpResponse } from '@angular/common/http';
import { Observable } from 'rxjs';
import { CannedMessage } from 'app/shared/model/canned-message.model';
type EntityResponseType = HttpResponse<CannedMessage>;
type EntityArrayResponseType = HttpResponse<CannedMessage[]>;
@Injectable({
    providedIn: 'root'
})
export class TextCannedService {
    private requestUrl = SERVER_API_URL + 'api/canned-messages';
    constructor(private http: HttpClient) {}
    getAllCannedMessage(): Observable<any> {
        return this.http.get<EntityArrayResponseType>(this.requestUrl, { observe: 'response' });
    }
    delete(id: number): Observable<any> {
        const url = this.requestUrl + '/' + id;
        console.log(id + url);
        return this.http.delete<any>(url);
    }
    create(cannedMessage: CannedMessage): Observable<any> {
        const url = this.requestUrl;
        console.log(url, 'inside text canned serv.>>>', cannedMessage);
        return this.http.post<EntityResponseType>(this.requestUrl, cannedMessage);
    }
    update(cannedMessage: CannedMessage): Observable<any> {
        console.log(this.requestUrl, 'inside text canned serv.>>>', cannedMessage);

        return this.http.put<EntityResponseType>(this.requestUrl, cannedMessage);
    }
}
