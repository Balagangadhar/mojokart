import { Component, Inject } from '@angular/core';
import { MatDialogRef, MAT_DIALOG_DATA, MatDialog } from '@angular/material';

@Component({
    selector: 'jhi-edit-text-campaign',
    templateUrl: './edit-text-campaign.component.html',
    styleUrls: ['../text-campaign.component.css']
})
export class EditTextCampaignComponent {
    constructor(public dialogRef: MatDialogRef<EditTextCampaignComponent>, @Inject(MAT_DIALOG_DATA) public marketingListName: string) {}

    onNoClick(): void {
        this.dialogRef.close();
    }
}
