import { Component, Inject, OnInit } from '@angular/core';
import { TextCampaignComponent } from './text-campaign.component';
import { CannedMessageDeleteComponent } from './canned-message-delete';
import { MAT_DIALOG_DATA, MatDialogRef } from '@angular/material';
import { ViewChild } from '@angular/core';
import { MatPaginator, MatSort, MatDialog } from '@angular/material';
import { SelectionModel } from '@angular/cdk/collections';
import { HttpClient } from '@angular/common/http';
import { merge, Observable, of as observableOf } from 'rxjs';
import { startWith, switchMap, map, catchError } from 'rxjs/operators';
import { Account } from 'app/shared/model/account.model';
import { AccountService } from 'app/core';
import { TextCannedService } from './text-canned.service';
import { CannedMessage } from 'app/shared/model/canned-message.model';
@Component({
    selector: 'jhi-text-canned-dialog',
    templateUrl: 'text-canned.component.html',
    styleUrls: ['./text-campaign.component.css']
})
export class TextCannedDialogComponent implements OnInit {
    @ViewChild(MatPaginator) paginator!: MatPaginator;
    @ViewChild(MatSort) sort!: MatSort;
    marketingListName = '';
    startCampaign: Boolean = false;
    currentAccount: Account;
    displayedColumns: string[] = ['select', 'message', 'actions'];
    apiService: TextCannedService | null;
    dataSource: CannedMessage[] = [];
    scheduleButton: Boolean = false;
    sendButton: Boolean = false;
    resultsLength = 0;
    isLoadingResults = true;
    isRateLimitReached = false;
    newCannedMessage = '';
    updateButton = false;
    saveButton = true;
    textAreTitle = 'Create new';
    updateCannedMessage: CannedMessage;
    selection = new SelectionModel<CannedMessage>(true, []);
    constructor(
        private accountService: AccountService,
        public dialog: MatDialog,
        private http: HttpClient,
        public dialogRef: MatDialogRef<TextCampaignComponent>,
        @Inject(MAT_DIALOG_DATA) public composeMessage: string
    ) {
        this.accountService.identity().then(account => {
            this.currentAccount = account;
        });
    }
    ngOnInit() {
        this.contactTable();
    }
    contactTable() {
        this.apiService = new TextCannedService(this.http);
        merge(this.sort.sortChange)
            .pipe(
                startWith({}),
                switchMap(() => {
                    this.isLoadingResults = true;
                    return this.apiService!.getAllCannedMessage();
                }),
                map(data => {
                    this.isLoadingResults = false;
                    this.isRateLimitReached = false;
                    this.resultsLength = this.dataSource.length;
                    return data;
                }),
                catchError(() => {
                    this.isLoadingResults = false;
                    this.isRateLimitReached = true;
                    return observableOf([]);
                })
            )
            .subscribe(data => {
                this.dataSource = data.body;
            });
    }
    isAllSelected() {
        const numSelected = this.selection.selected.length;
        const numRows = this.dataSource.length;
        return numSelected === numRows;
    }
    masterToggle() {
        this.isAllSelected() ? this.selection.clear() : this.dataSource.forEach(row => this.selection.select(row));
    }
    onEdit(cannedMessage: CannedMessage) {
        this.textAreTitle = 'Update';
        console.log(cannedMessage);
        this.newCannedMessage = cannedMessage.message;
        this.updateCannedMessage = cannedMessage;
        this.updateButton = true;
        this.saveButton = false;
    }
    onDelete(cannedMessage: CannedMessage) {
        this.deleteDialog(cannedMessage);
    }
    onSave() {
        const cannedMessage = new CannedMessage(null, this.newCannedMessage);
        console.log('saving message', cannedMessage);
        this.apiService.create(cannedMessage).subscribe(() => this.ngOnInit());
        // reset value
        this.newCannedMessage = '';
    }
    //  delete canned message
    deleteDialog(cannedMessage: CannedMessage): void {
        const dialogRef = this.dialog.open(CannedMessageDeleteComponent, {
            width: 'auto',
            data: cannedMessage
        });
        dialogRef.afterClosed().subscribe(result => {
            if (result) {
                console.log('delete...', result);
                this.apiService.delete(result.id).subscribe(() => this.ngOnInit());
            }
        });
    }
    onAddToMessage() {
        console.log(this.selection.selected);
        this.composeMessage = this.composeMessage + this.selection.selected;
        console.log(this.composeMessage);
    }
    onUpdate() {
        this.updateCannedMessage.message = this.newCannedMessage;
        this.apiService.update(this.updateCannedMessage).subscribe(() => this.ngOnInit());
        console.log('update api...');
        this.updateButton = false;
        this.saveButton = true;
        this.newCannedMessage = '';
    }
    onCancel() {
        this.textAreTitle = 'Create new';
        this.updateButton = false;
        this.saveButton = true;
        this.newCannedMessage = '';
    }
}
