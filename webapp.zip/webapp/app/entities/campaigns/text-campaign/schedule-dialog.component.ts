import { Component, Inject } from '@angular/core';
import { CampaignSchedule } from './../../../shared/model/email-campaign-regular.model';
import { MAT_DIALOG_DATA, MatDialogRef } from '@angular/material';
import { NgbDatepickerConfig, NgbDate, NgbCalendar, NgbDateStruct, NgbDateParserFormatter } from '@ng-bootstrap/ng-bootstrap';
// import { Scheduler } from 'app/shared/model/scheduler.model';
import { NgbDateFRParserFormatter } from './../../../shared/util/ngb-date-format-parser';
@Component({
    selector: 'jhi-schedule-campaign-dialog',
    templateUrl: 'schedule-dialog.component.html',
    styleUrls: ['./text-campaign.component.css'],
    providers: [NgbDatepickerConfig, { provide: NgbDateParserFormatter, useClass: NgbDateFRParserFormatter }]
})
export class ScheduleDialogComponent {
    model: NgbDateStruct = { year: 2019, month: 1, day: 1 };
    time = { hour: 13, minute: 30 };
    constructor(
        public config: NgbDatepickerConfig,
        public calendar: NgbCalendar,
        public dialogRef: MatDialogRef<ScheduleDialogComponent>,
        @Inject(MAT_DIALOG_DATA) public textCampaignSchedule: CampaignSchedule
    ) {
        config.minDate = calendar.getToday();
        // config.maxDate = { year: 2099, month: 12, day: 31 };
        config.outsideDays = 'hidden';
    }
    onNoClick(): void {
        this.dialogRef.close();
    }
    // onSchedule() {
    //     console.log(JSON.stringify(this.model));
    //     console.log(JSON.stringify(this.time.hour));
    // }
    onDateSelect($event) {
        console.log($event);
        this.textCampaignSchedule.time = { hour: this.time.hour, minute: this.time.minute };
        this.textCampaignSchedule.date = { day: $event.day, month: $event.month, year: $event.year };
        console.log(this.textCampaignSchedule);
    }
}
