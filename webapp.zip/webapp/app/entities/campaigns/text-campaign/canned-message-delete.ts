import { Component, Inject } from '@angular/core';
import { CannedMessage } from './../../../shared/model/canned-message.model';
import { MAT_DIALOG_DATA, MatDialogRef } from '@angular/material';

@Component({
    selector: 'jhi-canned-message-delete',
    templateUrl: 'canned-message-delete.html',
    styleUrls: ['./text-campaign.component.css']
})
export class CannedMessageDeleteComponent {
    constructor(
        public dialogRef: MatDialogRef<CannedMessageDeleteComponent>,
        @Inject(MAT_DIALOG_DATA) public cannedMessage: CannedMessage
    ) {}

    onNoClick(): void {
        this.dialogRef.close();
    }
}
