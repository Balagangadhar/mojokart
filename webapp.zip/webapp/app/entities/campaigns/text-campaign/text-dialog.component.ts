import { Component, Inject } from '@angular/core';
import { MAT_DIALOG_DATA, MatDialogRef } from '@angular/material';
import { Router } from '@angular/router';

@Component({
    selector: 'jhi-text-campaign-dialog',
    templateUrl: 'text-dialog.component.html',
    styleUrls: ['./text-campaign.component.css']
})
export class CampaignTextDialogComponent {
    constructor(
        private router: Router,
        public dialogRef: MatDialogRef<CampaignTextDialogComponent>,
        @Inject(MAT_DIALOG_DATA) public marketingListName: string
    ) {}

    onNoClick(): void {
        this.dialogRef.close();
    }

    closeTextCampaignPopup() {
        this.router.navigate(['/campaigns']);
    }
}
