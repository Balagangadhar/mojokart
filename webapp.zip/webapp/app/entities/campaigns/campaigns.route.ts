import { Injectable } from '@angular/core';
import { CampaignListComponent } from './campaign-list/campaign-list.component';
import { Resolve, ActivatedRouteSnapshot, RouterStateSnapshot, Routes, RouterModule } from '@angular/router';
import { HttpResponse } from '@angular/common/http';
import { Observable, of } from 'rxjs';
import { filter, map } from 'rxjs/operators';

import { ContactService } from '../contact/contact.service';
import { IContact, Contact } from 'app/shared/model/contact.model';
import { Campaign, RegularCampaign } from 'app/shared/model/email-campaign-regular.model';
import { UserRouteAccessService } from 'app/core';
import { JhiResolvePagingParams } from 'ng-jhipster';
import { CampaignsComponent } from './campaigns.component';
import { EmailCampaignRegularComponent } from './email-campaign-regular.component';
import { TextCampaignComponent } from './text-campaign/text-campaign.component';
import { CampaignSendEmailSuccessComponent } from './campaign-send-email-success/campaign-send-email-success.component';
import { CampaignScheduleSuccessComponent } from './campaign-schedule-success/campaign-schedule-success.component';
import { TextSendComponent } from './text-send/text-send.component';
import { TextScheduleComponent } from './text-schedule/text-schedule.component';

export const campaignsRoutes: Routes = [
    {
        path: 'createCampaign',
        component: CampaignsComponent,
        resolve: {
            pagingParams: JhiResolvePagingParams
        },
        data: {
            authorities: ['ROLE_USER'],
            defaultSort: 'id,asc',
            pageTitle: 'Email Campaign'
        },
        canActivate: [UserRouteAccessService]
    },
    {
        path: 'campaigns',
        component: CampaignListComponent,
        resolve: {
            pagingParams: JhiResolvePagingParams
        },
        data: {
            authorities: ['ROLE_USER'],
            defaultSort: 'id,asc',
            pageTitle: 'Campaigns'
        },
        canActivate: [UserRouteAccessService]
    },
    {
        path: 'text-campaigns',
        component: TextCampaignComponent,
        resolve: {
            pagingParams: JhiResolvePagingParams
        },
        data: {
            authorities: ['ROLE_USER'],
            defaultSort: 'id,asc',
            pageTitle: 'Campaigns'
        },
        canActivate: [UserRouteAccessService]
    },
    {
        path: 'regularEmailCampaign',
        component: EmailCampaignRegularComponent,
        data: {
            authorities: ['ROLE_USER'],
            defaultSort: 'id,asc',
            pageTitle: 'Email Campaign'
        },
        canActivate: [UserRouteAccessService]
    },
    {
        path: 'sendEmailSuccess',
        component: CampaignSendEmailSuccessComponent,
        data: {
            authorities: ['ROLE_USER'],
            defaultSort: 'id,asc',
            pageTitle: 'Email Campaign'
        },
        canActivate: [UserRouteAccessService]
    },
    {
        path: 'scheduleEmailSuccess',
        component: CampaignScheduleSuccessComponent,
        data: {
            authorities: ['ROLE_USER'],
            defaultSort: 'id,asc',
            pageTitle: 'Email Campaign'
        },
        canActivate: [UserRouteAccessService]
    },
    {
        path: 'sendTextSuccess',
        component: TextSendComponent,
        data: {
            authorities: ['ROLE_USER'],
            defaultSort: 'id,asc',
            pageTitle: 'Campaigns'
        },
        canActivate: [UserRouteAccessService]
    },
    {
        path: 'scheduleTextSuccess',
        component: TextScheduleComponent,
        data: {
            authorities: ['ROLE_USER'],
            defaultSort: 'id,asc',
            pageTitle: 'Campaigns'
        },
        canActivate: [UserRouteAccessService]
    },
    {
        path: 'sendEmailSuccess',
        component: CampaignSendEmailSuccessComponent,
        data: {
            authorities: ['ROLE_USER'],
            defaultSort: 'id,asc',
            pageTitle: 'Email Campaign'
        },
        canActivate: [UserRouteAccessService]
    }
];
