import { NgModule } from '@angular/core';
import { ScheduleDialogComponent } from './text-campaign/schedule-dialog.component';
import { CommonModule } from '@angular/common';
import { MaterialModule } from './../material.module';
import { FormsModule } from '@angular/forms';
import { RouterModule } from '@angular/router';
import { CampaignsComponent, campaignsRoutes, NgbdModalContentComponent } from './';
import { NgbModule } from '@ng-bootstrap/ng-bootstrap';
import { EmailCampaignRegularComponent } from './email-campaign-regular.component';
import { FileUploadModule } from 'ng2-file-upload';
import { UploadFieldComponent } from './upload.component';
import { CampaignListComponent } from './campaign-list/campaign-list.component';
import { MatTabsModule } from '@angular/material/tabs';
import { MatInputModule } from '@angular/material/input';
import { CampaignDeleteComponent } from './campaign-delete.component';
import { SharedCommonModule } from '../../shared/shared-common.module';
import { CampaignPreviewComponent } from './campaign-preview.component';
import { TextCampaignComponent } from './text-campaign/text-campaign.component';
import { CampaignTextDialogComponent } from './text-campaign/text-dialog.component';
import { MAT_DIALOG_DATA, MatDialogRef, MatSortModule } from '@angular/material';
import { TextCannedDialogComponent } from './text-campaign/text-canned.component';
import { CannedMessageDeleteComponent } from './text-campaign/canned-message-delete';
import { CampaignScheduleComponent } from './campaign-schedule.component';
import { CampaignSendEmailConfirmationComponent } from './campaign-send-email-confirmation/campaign-send-email-confirmation.component';
import { CampaignSendEmailSuccessComponent } from './campaign-send-email-success/campaign-send-email-success.component';
import { CampaignScheduleSuccessComponent } from './campaign-schedule-success/campaign-schedule-success.component';
import { TextScheduleComponent } from './text-schedule/text-schedule.component';
import { TextSendComponent } from './text-send/text-send.component';
import { EditCampaignNameComponent } from './edit-campaign-name.component';
// import { SafeHtmlPipePipe } from './safe-html-pipe.pipe';
import { EditTextCampaignComponent } from './text-campaign/edit-text-campaign/edit-text-campaign.component';

const ENTITY_STATES = [...campaignsRoutes];

@NgModule({
    declarations: [
        CampaignsComponent,
        CampaignDeleteComponent,
        NgbdModalContentComponent,
        EmailCampaignRegularComponent,
        UploadFieldComponent,
        CampaignListComponent,
        CampaignPreviewComponent,
        TextCampaignComponent,
        CampaignTextDialogComponent,
        TextCannedDialogComponent,
        CannedMessageDeleteComponent,
        ScheduleDialogComponent,
        CampaignScheduleComponent,
        CampaignSendEmailConfirmationComponent,
        CampaignSendEmailSuccessComponent,
        CampaignScheduleSuccessComponent,
        TextScheduleComponent,
        TextSendComponent,
        EditCampaignNameComponent,
        // SafeHtmlPipePipe,
        EditTextCampaignComponent
    ],
    imports: [
        CommonModule,
        NgbModule,
        FormsModule,
        MaterialModule,
        MatTabsModule,
        MatInputModule,
        FileUploadModule,
        CommonModule,
        FormsModule,
        MatSortModule,
        FileUploadModule,
        SharedCommonModule,
        RouterModule.forChild(ENTITY_STATES)
    ],
    entryComponents: [
        EditCampaignNameComponent,
        CampaignsComponent,
        EditTextCampaignComponent,
        NgbdModalContentComponent,
        CampaignDeleteComponent,
        CampaignTextDialogComponent,
        CampaignPreviewComponent,
        TextCannedDialogComponent,
        CannedMessageDeleteComponent,
        ScheduleDialogComponent,
        CampaignScheduleComponent,
        CampaignSendEmailConfirmationComponent,
        EditTextCampaignComponent
    ],
    providers: [{ provide: MAT_DIALOG_DATA, useValue: {} }, { provide: MatDialogRef, useValue: {} }]
})
export class CampaignsModule {}
