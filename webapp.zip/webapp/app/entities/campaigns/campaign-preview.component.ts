import { Component, Inject, OnInit } from '@angular/core';
import { Campaign } from './../../shared/model/email-campaign-regular.model';
import { MAT_DIALOG_DATA, MatDialogRef } from '@angular/material';
@Component({
    selector: 'jhi-campaign-preview',
    templateUrl: 'campaign-preview.component.html',
    styleUrls: ['./campaign-preview.component.css']
})
export class CampaignPreviewComponent implements OnInit {
    emailCampaign = false;
    textCampaign = false;
    seriesCampaign = false;
    constructor(public dialogRef: MatDialogRef<CampaignPreviewComponent>, @Inject(MAT_DIALOG_DATA) public campaign: Campaign) {}
    ngOnInit(): void {
        if (this.campaign.type === 'EMAIL') {
            this.emailCampaign = true;
        } else if (this.campaign.type === 'TEXT') {
            this.textCampaign = true;
        } else if (this.campaign.type === 'SERIES') {
            this.seriesCampaign = true;
        }
    }
    onNoClick(): void {
        this.dialogRef.close();
    }
}
