import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';

@Component({
    selector: 'jhi-text-send',
    templateUrl: './text-send.component.html',
    styles: []
})
export class TextSendComponent implements OnInit {
    campaignName: any;
    totalContacts: number;
    constructor(private route: ActivatedRoute) {}

    ngOnInit() {
        this.campaignName = this.route.snapshot.queryParams['campaignName'];
        this.totalContacts = this.route.snapshot.queryParams['totalContacts'];
    }
}
