import { Component, OnInit, Input } from '@angular/core';
import { CampaignService } from './campaigns.service';
import { NgbActiveModal } from '@ng-bootstrap/ng-bootstrap';
import { Router } from '@angular/router';
import { CampaignSchedule, ScheduleDate, IRegularCampaign } from '../../shared/model/email-campaign-regular.model';
import { NgbDateMomentAdapter } from '../../shared/util/datepicker-adapter';
import { NgbDatepickerConfig, NgbDate, NgbCalendar, NgbDateStruct, NgbDateParserFormatter } from '@ng-bootstrap/ng-bootstrap';
import { NgbDateFRParserFormatter } from '../../shared/util/ngb-date-format-parser';

@Component({
    selector: 'jhi-campaign-schedule',
    templateUrl: './campaign-schedule.component.html',
    styleUrls: ['./campaign-schedule.component.css'],
    providers: [{ provide: NgbDateParserFormatter, useClass: NgbDateFRParserFormatter }]
})
export class CampaignScheduleComponent implements OnInit {
    selectedDate: any;
    startTime: any;
    campaignSchedule: any;
    minDate: any;
    date: any;
    dateJson: ScheduleDate;
    errorMessage: any;
    @Input() campaignName;
    @Input() campaignId;
    @Input() action;
    // @Input() scheduleDetails;
    @Input() campaingDetails;
    constructor(
        public format: NgbDateMomentAdapter,
        public router: Router,
        public campaignService: CampaignService,
        public activeModal: NgbActiveModal
    ) {
        const current = new Date();
        this.minDate = {
            year: current.getFullYear(),
            month: current.getMonth() + 1,
            day: current.getDate()
        };
    }
    ngOnInit() {
        console.log('campaign schedule page this.action', this.action);
        if (this.action === 'edit') {
            console.log('this.campaingDetails ', this.campaingDetails);
            if (this.campaingDetails.date !== null) {
                console.log('this.scheduleDetails.date ', this.campaingDetails.date.date);
                console.log('this.scheduleDetails.time ', this.campaingDetails.date.time);
                this.selectedDate = this.format.toModel(this.campaingDetails.date.date);
                this.startTime = this.campaingDetails.date.time;
            }
        }
    }

    addSchedule() {
        console.log('selectedDate ', this.selectedDate);
        console.log('startTime ', this.startTime);
        if (this.selectedDate === undefined || this.selectedDate === null) {
            this.errorMessage = '*Please select date';
            return;
        } else {
            this.errorMessage = '';
        }

        if (this.startTime === undefined || this.startTime === null) {
            this.errorMessage = '*Please select time';
            return;
        } else {
            this.errorMessage = '';
        }

        console.log('fromModel.............', this.format.fromModel(this.selectedDate));
        this.campaignSchedule = new CampaignSchedule();
        this.campaignSchedule.date = this.format.fromModel(this.selectedDate);
        this.campaignSchedule.time = this.startTime;
        if (this.action === 'edit') {
            this.campaignService.updateCampaign(this.campaingDetails).subscribe((campaignResponse: IRegularCampaign) => {
                console.log('update campaign details alone  response', campaignResponse);
            });
            this.saveSchedule(this.campaingDetails.id, this.campaignSchedule);
        } else {
            this.saveSchedule(this.campaignId, this.campaignSchedule);
        }
    }
    saveSchedule(campaignId, scheduleDetails) {
        this.campaignService.createSchedule(campaignId, scheduleDetails).subscribe((response: any) => {
            this.activeModal.dismiss('Cross click');
            console.log(' campaign  schedule create', response);
            const dateWithTime =
                this.campaignSchedule.date.year +
                '-' +
                this.campaignSchedule.date.month +
                '-' +
                this.campaignSchedule.date.day +
                '-' +
                this.campaignSchedule.time.hour +
                '-' +
                this.campaignSchedule.time.minute;
            this.router.navigate(['/scheduleEmailSuccess'], { queryParams: { campaignName: this.campaignName, date: dateWithTime } });
        });
    }
}
