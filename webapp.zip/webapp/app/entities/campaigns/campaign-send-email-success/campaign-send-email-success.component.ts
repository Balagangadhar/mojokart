import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';

@Component({
    selector: 'jhi-campaign-send-email-success',
    templateUrl: './campaign-send-email-success.component.html',
    styles: []
})
export class CampaignSendEmailSuccessComponent implements OnInit {
    campaignName;
    date;
    isSeries: any;
    constructor(private route: ActivatedRoute) {}

    ngOnInit() {
        this.campaignName = this.route.snapshot.queryParams['campaignName'];
        this.isSeries = this.route.snapshot.queryParams['isSeries'];
    }
}
