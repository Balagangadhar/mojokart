import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { MONTHS } from '../../../shared/constants/schedule.constants';

@Component({
    selector: 'jhi-campaign-schedule-success',
    templateUrl: './campaign-schedule-success.component.html',
    styles: []
})
export class CampaignScheduleSuccessComponent implements OnInit {
    campaignName: any;
    dateObj: any;
    meridian: any;
    constructor(private route: ActivatedRoute) {}

    ngOnInit() {
        this.campaignName = this.route.snapshot.queryParams['campaignName'];
        const dateTimeJson = this.route.snapshot.queryParams['date'];
        console.log('this.dateTimeJson', dateTimeJson);
        const dateTime = dateTimeJson.split('-');
        this.dateObj = new Date(dateTime[0], parseInt(dateTime[1], 0) - 1, dateTime[2], dateTime[3], dateTime[4]);
    }
    getMonthName(monthId) {
        return MONTHS[monthId];
    }
}
