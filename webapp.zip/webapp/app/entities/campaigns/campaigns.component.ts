import { Component, Input, OnInit, ViewChild } from '@angular/core';
import { NgbActiveModal, NgbModal } from '@ng-bootstrap/ng-bootstrap';
import { Router, ActivatedRoute } from '@angular/router';
import { GlobalSendEmailDataService } from '../global-send-email-data.service';
import { PersistData } from '../global-send-email-data.service';
import { Campaign, RegularCampaign } from '../../shared/model/email-campaign-regular.model';
import { SeriesService } from '../series/series.service';
import { Series } from '../../shared/model/series.model';
import { toBase64String } from '@angular/compiler/src/output/source_map';
import { CampaignService } from './campaigns.service';
import { IRegularCampaign } from '../../shared/model/email-campaign-regular.model';
import { AccountService } from '../../core/auth/account.service';
import { CommonUtil } from '../../shared/util/common-util';

@Component({
    selector: 'jhi-ngbd-modal-content',
    templateUrl: './campaigns.component.html',
    styleUrls: ['./campaigns.component.css']
})
export class NgbdModalContentComponent implements OnInit {
    //  @Input() seriesResponse;
    seriesResponse: any;
    selectedSeries: any;
    selectedCampaign: any;
    campaignName: any = '';
    emailData: any;
    persistData: PersistData;
    accountResponse: any;
    isSeries;
    seriesId;
    pageName = '';
    isFromContactList: any;
    editCampaignIdFromCampaignListPage: any;
    isEditCampaignFromCampaignListPage: any;
    errorMessage: any;
    isNewCamp: boolean;
    newCamp: string;
    isExistingCamp: boolean;
    existCamp: string;
    receipientListFlag: Boolean;
    publishedCampaigns: any;
    isPublishedCampaignsAavailable = false;
    existingCampaignObject: any;
    @ViewChild('tab') tab;
    constructor(
        private route: ActivatedRoute,
        public activeModal: NgbActiveModal,
        public router: Router,
        public emailDataService: GlobalSendEmailDataService,
        public _seriesService: SeriesService,
        public campaignService: CampaignService,
        public _accountService: AccountService
    ) {
        this.getUserDetails();
    }
    redirectToEmailDetails() {
        if (this.tab.activeId === 'tab-1') {
            if (this.isNewCamp) {
                if (this.campaignName === undefined || this.campaignName.replace(/ /g, '').length === 0) {
                    this.errorMessage = 'Please enter valid name';
                    return;
                } else {
                    this.errorMessage = '';
                }
                this.isSeries = false;
                this.campaignService.isDuplicateCampaign(this.campaignName).subscribe((response: boolean) => {
                    console.log(response, 'is duplicate', !response);
                    if (response === true) {
                        this.errorMessage = 'This campaign is already exists';
                        return;
                    } else {
                        this.campaignInformation();
                    }
                });
            } else {
                if (this.selectedCampaign === undefined || this.selectedCampaign === '-1') {
                    this.errorMessage = 'Please select campaign';
                    return;
                } else {
                    this.errorMessage = '';
                }
                this.isSeries = false;
                this.campaignName = this.selectedCampaign.name;
                this.seriesId = this.selectedCampaign.id;
                this.campaignInformation();
            }
        } else {
            if (this.selectedSeries === undefined || this.selectedSeries === '-1') {
                this.errorMessage = 'Please select series';
                return;
            } else {
                this.errorMessage = '';
            }
            this.campaignName = this.selectedSeries.name;
            this.seriesId = this.selectedSeries.id;
            console.log('series id ', this.selectedSeries.id);
            this.isSeries = true;
            this.campaignInformation();
        }
    }
    campaignInformation() {
        if (this.isExistingCamp) {
            this.campaignService.createNewRegularCampaignId(this.selectedCampaign.id).subscribe((response: Campaign) => {
                console.log(response);
                this.activeModal.close('Close click');
                this.router.navigate(['/regularEmailCampaign'], {
                    queryParams: {
                        seriesId: this.seriesId,
                        isSereis: this.isSeries,
                        campaignName: this.campaignName,
                        isFromContactList: this.isFromContactList,
                        campaingId: response.id,
                        isCampaign: 'existing'
                    }
                });
            });
        } else {
            this.campaignService.createRegularCampaign(this.createCampaign()).subscribe((response: Campaign) => {
                console.log(' create campaign with name response', response);
                this.activeModal.close('Close click');
                this.router.navigate(['/regularEmailCampaign'], {
                    queryParams: {
                        seriesId: this.seriesId,
                        isSereis: this.isSeries,
                        campaignName: this.campaignName,
                        isFromContactList: this.isFromContactList,
                        campaingId: response.id,
                        isCampaign: 'new'
                    }
                });
            });
        }
    }
    createCampaign() {
        let campaign;
        if (this.isSeries) {
            campaign = new Campaign(0, '', 'DRAFT', 'SERIES', new RegularCampaign());
            campaign.emailDetails.series = this.selectedSeries;
        } else {
            campaign = new Campaign(0, '', 'DRAFT', 'EMAIL', null);
        }
        campaign.name = this.campaignName;
        campaign.ownerId = this.accountResponse.id;
        campaign.companyId = this.accountResponse.id;
        return campaign;
    }
    getUserDetails() {
        this._accountService.identity().then(account => {
            this.accountResponse = account;
        });
    }
    onSelectSeries(selectedSeries) {
        this.selectedSeries = selectedSeries;
        console.log('selectedSeries in email campaign', this.selectedSeries);
    }
    onSelectCampaign(selectedCampaign) {
        this.selectedCampaign = selectedCampaign;
        console.log('selected campaign in email campaign', this.selectedCampaign);
    }
    closePopUp() {
        this.activeModal.close('Close click');
        this.router.navigate(['/campaigns']);
    }
    ngOnInit() {
        this.isNewCamp = true;
        this.isExistingCamp = false;
        this.campaignName = this.route.snapshot.queryParams['campaignName'];
        this.editCampaignIdFromCampaignListPage = this.route.snapshot.queryParams['editCampaignIdFromCampaignListPage'];
        this.isEditCampaignFromCampaignListPage = this.route.snapshot.queryParams['isEditCampaignFromCampaignListPage'];
        this.isFromContactList = this.route.snapshot.queryParams['isFromContactList'];
        this.pageName = this.route.snapshot.queryParams['pageName'];
        console.log('this.isFromContactList', this.isFromContactList);
        if (this.isFromContactList == null || this.isFromContactList === undefined) {
            if (this.pageName === 'contactList') {
                this.isFromContactList = true;
            } else {
                this.isFromContactList = false;
            }
        }
        this.getCampaignDetails();
        this.getSeriesDetails();
    }
    getCampaignDetails() {
        this.campaignService.getCampaignDetails().subscribe((response: Campaign) => {
            console.log('campaign list response');
            this.isPublishedCampaignsAavailable = true;
            this.publishedCampaigns = response;
        });
    }
    getSeriesDetails() {
        this._seriesService.getSeriesDetails().subscribe((response: Series) => {
            console.log('list response', response);
            this.seriesResponse = response;
        });
    }
    tabChanged() {
        this.campaignName = '';
        this.selectedSeries = '-1';
        this.errorMessage = '';
        this.isNewCamp = true;
        this.isExistingCamp = false;
    }
    campaignNewSelected() {
        this.isNewCamp = true;
        this.isExistingCamp = false;
        this.campaignName = '';
        this.errorMessage = '';
    }
    campaignExistingSelected() {
        this.isNewCamp = false;
        this.isExistingCamp = true;
        this.campaignName = '';
        this.errorMessage = '';
    }
}

@Component({
    selector: 'jhi-ngbd-modal-component',
    template: ''
})
export class CampaignsComponent implements OnInit {
    constructor(public modalService: NgbModal, private commonUtil: CommonUtil) {
        const options = this.commonUtil.getModalPopUpSettings();
        delete options.size;
        const modalRef = this.modalService.open(NgbdModalContentComponent, options);
    }
    ngOnInit() {}
}
