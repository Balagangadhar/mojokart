import { Component, OnInit, ViewChild } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { NgbModal } from '@ng-bootstrap/ng-bootstrap';
import { SERVER_API_URL } from 'app/app.constants';
import { Series } from 'app/shared/model/series.model';
import { FileUploader } from 'ng2-file-upload/ng2-file-upload';
import { LocalStorageService } from 'ngx-webstorage';
import { AccountService } from '../../core/auth/account.service';
import { Campaign, RegularCampaign } from '../../shared/model/email-campaign-regular.model';
import { SenderProfile } from '../../shared/model/sender-profile.model';
import { CommonUtil } from '../../shared/util/common-util';
import { ContactListService } from '../contact-list/contact-list.service';
import { GlobalSendEmailDataService } from '../global-send-email-data.service';
import { AddTemplateSeriesComponent } from '../series/add-template-series/add-template-series.component';
import { SeriesService } from '../series/series.service';
import { UserProfileService } from '../user-profile/user-profile.service';
import { CampaignScheduleComponent } from './campaign-schedule.component';
import { CampaignSendEmailConfirmationComponent } from './campaign-send-email-confirmation/campaign-send-email-confirmation.component';
import { CampaignService } from './campaigns.service';
import { EditCampaignNameComponent } from './edit-campaign-name.component';
import { UploadFieldComponent } from './upload.component';
@Component({
    selector: 'jhi-email-campaign-regular',
    templateUrl: './email-campaign-regular.component.html',
    styleUrls: ['./email-campaign-regular.component.css']
})
export class EmailCampaignRegularComponent implements OnInit {
    isWelcomeDivDisplay: any;
    isFromDivDisplay: any = false;
    isSubjectDivDisplay: any = false;
    isContentDivDisplay: any = false;
    public uploader: FileUploader;
    public accountResponse: any;
    public resourceUrl: any = SERVER_API_URL + 'api/blobs?type=ATTACHMENT';
    emailData: any;
    toChk: any = false;
    subjectChk: any = false;
    fromChk: any = false;
    campaignName: string;
    receipientListFlag: boolean;
    bannerURL: any = '';
    subject: string;
    emailContent: string;
    templateAttachments: any;
    pageName: string = null;
    templateDetailsDiv: any = true;
    templateAttachmentDetailsDiv: any = false;
    isIndividual: boolean;
    isList: boolean;
    isListFromContactPage: boolean;
    selectedContactList: any;
    selectedContactListObj: any;
    contactResponse: any = [];
    sendErrorMessage: any = '';
    indEmail: any;
    listEmail: any;
    listFromContactPage: any;
    isSeries: any;
    isCampaign: any;
    seriesDetails: any;
    campaingDetails: any;
    campaingId: any;
    toName: any;
    ccList: any;
    toEmail: any;
    bccList: any;
    seriesId: any;
    seriesName: any;
    scheduleModalRef: any;
    objectKeys = Object.keys;
    attachments: any = [];
    userUploadedFiles: any = [];
    allSenderDetails: any;
    selectedProfile = -1;
    senderEmail: any;
    isFromContactList: any;
    constatDetailsFromContactPage: any;
    contentChk = false;
    contentChkSeries = false;
    @ViewChild(UploadFieldComponent) public uploadField: UploadFieldComponent;
    constructor(
        private localStorage: LocalStorageService,
        public emailDataService: GlobalSendEmailDataService,
        public campaignService: CampaignService,
        public router: Router,
        private route: ActivatedRoute,
        public _contactListService: ContactListService,
        public _accountService: AccountService,
        public _seriesService: SeriesService,
        private modalService: NgbModal,
        private _userProfileService: UserProfileService,
        private commonUtil: CommonUtil
    ) {}
    ngOnInit() {
        this.campaingId = parseInt(this.route.snapshot.queryParams['campaingId'], 0);
        this.pageName = this.route.snapshot.queryParams['pageName'];
        this.isSeries = this.route.snapshot.queryParams['isSereis'];
        this.isCampaign = this.route.snapshot.queryParams['isCampaign'];
        this.isFromContactList = this.route.snapshot.queryParams['isFromContactList'];
        this.campaignName = this.route.snapshot.queryParams['campaignName']; // campaign name is either campaign name or series name
        if (this.isSeries === 'true') {
            this.seriesId = parseInt(this.route.snapshot.queryParams['seriesId'], 0);
            this.getSeriesDetailsById(this.seriesId);
        }
        if (this.isCampaign === 'existing') {
            // this.FetchCampaignDetailsById(this.campaingId);
            this.pageName = 'template';
        }
        this.uploadField.uploader.onCompleteAll = () => {
            this.campaingDetails.emailDetails.attachments = this.attachments;
            this.updateCampaignDetails();
            this.uploadField.uploader.clearQueue();
        };
        this.uploadField.uploader.onSuccessItem = (item: any, response: string, status: number, headers: any) => {
            this.attachments.push(JSON.parse(response));
        };
        this.getUserDetails();
        this.getContactLists();
        this.getSenderInfo();
        this.getEmailUsageStatstics();

        if ((this.pageName !== undefined && this.pageName === 'template') || this.pageName === 'campaignList') {
            this.isWelcomeDivDisplay = false;
        } else {
            this.isWelcomeDivDisplay = true;
        }
        if (this.isFromContactList === 'true') {
            this.constatDetailsFromContactPage = this.localStorage.retrieve('listOfContacts');
            this.isListFromContactPage = true;
            this.listFromContactPage = 'listFromContactPage';
            this.indEmail = '';
            this.isList = false;
            this.isIndividual = false;
            this.listEmail = '';
        } else {
            this.indEmail = 'individual';
            this.isIndividual = true;
            this.isList = false;
            this.listEmail = '';
            this.listFromContactPage = '';
            this.isListFromContactPage = false;
        }
        if (this.campaingId !== undefined && this.campaingId !== null) {
            this.getCampaignDetailsById(this.campaingId);
        }
    }

    getEmailUsageStatstics() {
        this.campaignService.getEmailUsageStats().subscribe(response => {
            response.emailUsage.used >= response.emailUsage.limit ? (this.receipientListFlag = true) : (this.receipientListFlag = false);
        });
    }

    getSeriesDetailsById(id) {
        this._seriesService.getSeriesDetailsById(id).subscribe((response: Series) => {
            this.seriesDetails = response;
        });
    }
    getCampaignDetailsById(id) {
        this.campaignService.getCampaignDetailsById(id).subscribe((response: Campaign) => {
            this.campaingDetails = response;
            this.campaignName = this.campaingDetails.name;
            if (this.campaingDetails.emailDetails !== undefined && this.campaingDetails.emailDetails !== null) {
                if (this.campaingDetails.emailDetails.template !== undefined && this.campaingDetails.emailDetails.template !== null) {
                    this.contentChk = true;
                    if (this.campaingDetails.emailDetails.template.banner !== null) {
                        this.bannerURL = this.campaingDetails.emailDetails.template.banner.url;
                    }
                    /* these are template attachments */
                    if (this.campaingDetails.emailDetails.template.attachments !== null) {
                        this.templateAttachments = this.campaingDetails.emailDetails.template.attachments;
                    }
                } else {
                    this.contentChk = false;
                }
                /*  after redirect from template to campaign saved user uploaded fiels  */
                if (this.campaingDetails.emailDetails.attachments !== null) {
                    this.userUploadedFiles = this.campaingDetails.emailDetails.attachments;
                }
                /* this is only when user is upload files.
                 making empty becoz may be user again will add files after
                 redirect from template to campaign */
                this.attachments = [];
                this.emailContent =
                    this.campaingDetails.emailDetails.template !== null ? this.campaingDetails.emailDetails.template.content : '';
                this.uploadField.setQueueFiles([]);
                this.toChk = false;
                if (this.campaingDetails.emailDetails.contactList !== undefined && this.campaingDetails.emailDetails.contactList !== null) {
                    this.selectedContactList = this.campaingDetails.emailDetails.contactList.id;
                    const contactList = this.contactResponse.filter(contact => contact.id === parseInt(this.selectedContactList, 0));
                    this.selectedContactListObj = contactList[0];
                    this.isList = true;
                    this.isIndividual = false;
                    this.listEmail = 'list';
                    this.toChk = true;
                } else if (
                    this.campaingDetails.emailDetails.contacts !== undefined &&
                    this.campaingDetails.emailDetails.contacts !== null &&
                    this.campaingDetails.emailDetails.contacts.length > 0
                ) {
                    this.listFromContactPage = 'listFromContactPage';
                    this.isList = false;
                    this.isIndividual = false;
                    this.isListFromContactPage = true;
                    this.isFromContactList = 'true';
                    this.constatDetailsFromContactPage = this.campaingDetails.emailDetails.contacts;
                    this.toChk = true;
                } else {
                    this.toName = this.campaingDetails.emailDetails.toName;
                    this.ccList = this.campaingDetails.emailDetails.ccList;
                    this.toEmail = this.campaingDetails.emailDetails.toEmail;
                    this.bccList = this.campaingDetails.emailDetails.bccList;
                    this.isIndividual = true;
                    this.isList = false;
                    this.indEmail = 'individual';
                    if (this.toName && this.toEmail) {
                        this.toChk = true;
                    }
                }
                this.subjectChk = false;
                this.subject = this.campaingDetails.emailDetails.subject;
                if (this.subject !== undefined && this.subject !== null) {
                    this.subjectChk = true;
                }
                this.fromChk = false;
                if (this.campaingDetails.emailDetails.senderId !== null && this.campaingDetails.emailDetails.senderId !== undefined) {
                    this.fromChk = true;
                    this.selectedProfile = this.campaingDetails.emailDetails.senderId;
                    this.senderEmail = this.campaingDetails.emailDetails.senderEmail;
                }
                if (this.campaingDetails.emailDetails.series !== undefined && this.campaingDetails.emailDetails.series !== null) {
                    this.seriesDetails = this.campaingDetails.emailDetails.series;
                    this.isSeries = 'true';
                } else {
                    this.isSeries = 'false';
                }
            } else {
                // emailDetails Object is null
                this.campaingDetails.emailDetails = new RegularCampaign();
            }
        });
    }
    individual() {
        this.isList = false;
        this.isIndividual = true;
        this.isListFromContactPage = false;
        this.indEmail = 'individual';
    }
    listContacts() {
        this.isIndividual = false;
        this.isList = true;
        this.isListFromContactPage = false;
        this.listEmail = 'list';
    }
    contactsFromContactPageChange() {
        this.isIndividual = false;
        this.isList = false;
        this.isListFromContactPage = true;
        this.listFromContactPage = 'listFromContactPage';
    }
    onSelectContactList(id) {
        this.selectedContactList = id;
        const contactList = this.contactResponse.filter(contact => contact.id === parseInt(id, 0));
        this.selectedContactListObj = contactList[0];
    }
    getUserDetails() {
        this._accountService.identity().then(account => {
            this.accountResponse = account;
        });
    }
    getContactLists() {
        this._contactListService.getAllLists().subscribe((response: any) => {
            this.contactResponse = response.body;
        });
    }
    welcomeClick() {
        this.isWelcomeDivDisplay = !this.isWelcomeDivDisplay;
    }
    welcomeDivSave(toForm) {
        this.isFromDivDisplay = true;
        this.isWelcomeDivDisplay = false;
        this.isSubjectDivDisplay = false;
        this.isContentDivDisplay = false;
        if (this.isIndividual) {
            if (toForm.valid) {
                this.toChk = true;
            } else {
                this.toChk = false;
            }
            if (this.toName === undefined || this.toName === null || this.toName.replace(/ /g, '').length === 0) {
                this.toChk = false;
            } else {
                this.toChk = true;
            }
            this.IntializeIndividualFileds();
            this.clearContactsAndContactList();
        } else if (this.isList) {
            if (this.selectedContactList !== undefined && parseInt(this.selectedContactList, 0) > 0) {
                this.toChk = true;
            } else {
                this.toChk = false;
            }
            this.campaingDetails.emailDetails.contactList = this.selectedContactListObj;
            this.clearIndividualFileds();
            this.campaingDetails.emailDetails.contacts = null;
        } else if (this.isFromContactList === 'true') {
            if (
                this.constatDetailsFromContactPage !== undefined &&
                this.constatDetailsFromContactPage !== null &&
                this.constatDetailsFromContactPage.length > 0
            ) {
                this.toChk = true;
            } else {
                this.toChk = false;
            }
            this.campaingDetails.emailDetails.contacts = this.constatDetailsFromContactPage;
            this.campaingDetails.emailDetails.contactList = null;
            this.clearIndividualFileds();
        }

        if (!this.IndividualValiation()) {
            this.editWelcome();
            return;
        } else {
            this.sendErrorMessage = '';
        }
        this.updateCampaignDetails();
    }
    fromDivSave(fromForm) {
        this.isSubjectDivDisplay = true;
        this.isFromDivDisplay = false;
        this.isWelcomeDivDisplay = false;
        this.isContentDivDisplay = false;
        if (this.selectedProfile > 0) {
            this.fromChk = true;
            this.contentChkSeries = true;
        } else {
            this.fromChk = false;
        }
        if (!this.fromValidation()) {
            this.editFrom();
            return;
        } else {
            this.sendErrorMessage = '';
        }
        this.campaingDetails.emailDetails.senderId = this.selectedProfile;
        this.campaingDetails.emailDetails.senderEmail = this.senderEmail;
        for (const profile of this.allSenderDetails) {
            if (profile.id === this.selectedProfile) {
                this.campaingDetails.emailDetails.senderName = profile.name;
            }
        }
        this.updateCampaignDetails();
    }
    subjectSave(subjectFrom) {
        this.isContentDivDisplay = true;
        this.isSubjectDivDisplay = false;
        this.isFromDivDisplay = false;
        this.isWelcomeDivDisplay = false;
        if (subjectFrom.valid) {
            this.subjectChk = true;
        } else {
            this.subjectChk = false;
        }
        if (!this.subjectValidation()) {
            this.editSubject();
            return;
        } else {
            this.sendErrorMessage = '';
        }
        this.campaingDetails.emailDetails.subject = this.subject;
        this.updateCampaignDetails();
    }
    subjectCancel() {
        this.isFromDivDisplay = true;
        this.isWelcomeDivDisplay = false;
        this.isSubjectDivDisplay = false;
        this.isContentDivDisplay = false;
    }
    fromDivCancel() {
        this.isWelcomeDivDisplay = true;
        this.isFromDivDisplay = false;
        this.isSubjectDivDisplay = false;
        this.isContentDivDisplay = false;
    }
    editSubject() {
        this.isFromDivDisplay = false;
        this.isWelcomeDivDisplay = false;
        this.isSubjectDivDisplay = true;
        this.isContentDivDisplay = false;
    }
    editFrom() {
        this.isFromDivDisplay = true;
        this.isWelcomeDivDisplay = false;
        this.isSubjectDivDisplay = false;
        this.isContentDivDisplay = false;
    }
    editWelcome() {
        this.isFromDivDisplay = false;
        this.isWelcomeDivDisplay = true;
        this.isSubjectDivDisplay = false;
        this.isContentDivDisplay = false;
    }

    openTemplateDetails() {
        this.templateDetailsDiv = true;
        this.templateAttachmentDetailsDiv = false;
    }
    openTemplateAttachDetails() {
        this.templateDetailsDiv = false;
        this.templateAttachmentDetailsDiv = true;
    }
    IndividualValiation() {
        if (!this.toChk) {
            if (this.isIndividual) {
                this.sendErrorMessage = 'Please enter all mandatory fileds';
                this.editWelcome();
                return false;
            } else {
                this.sendErrorMessage = 'Please select list from drop down';
                return false;
            }
        } else {
            return true;
        }
    }
    fromValidation() {
        if (!this.fromChk) {
            this.sendErrorMessage = 'Please selecte profile';
            this.editFrom();
            return false;
        }
        if (this.selectedProfile < 0) {
            this.sendErrorMessage = 'Please selecte profile';
            return false;
        }
        return true;
    }
    subjectValidation() {
        if (this.isSeries !== 'true') {
            if (!this.subjectChk) {
                this.sendErrorMessage = 'Please Enter subject';
                this.editSubject();
                return false;
            } else {
                return true;
            }
        }
    }
    createCampaignObjectForUpdate() {
        if (!this.IndividualValiation()) {
            return;
        }
        if (!this.fromValidation()) {
            return;
        }
        if (!this.subjectValidation()) {
            return;
        }
        this.sendErrorMessage = '';
        if (this.isSeries === 'true') {
            this.campaingDetails.emailDetails.series = this.seriesDetails;
        }
        // merge existing attachments to newly addedd attachments
        for (const att of this.userUploadedFiles) {
            this.attachments.push(att);
        }
        this.campaingDetails.emailDetails.attachments = this.attachments;
        for (const profile of this.allSenderDetails) {
            if (profile.id === this.selectedProfile) {
                this.campaingDetails.emailDetails.senderName = profile.name;
            }
        }
        if (this.isIndividual) {
            this.IntializeIndividualFileds();
            this.clearContactsAndContactList();
        } else if (this.isList) {
            this.campaingDetails.emailDetails.contactList = this.selectedContactListObj;
            if (this.campaingDetails.emailDetails.contactList === undefined || this.campaingDetails.emailDetails.contactList === null) {
                this.sendErrorMessage = 'select list from dropdown';
                this.editWelcome();
                this.isList = true;
                this.isIndividual = false;
                this.isListFromContactPage = false;
                this.clearIndividualFileds();
                this.campaingDetails.emailDetails.contacts = null;
                return;
            } else {
                this.clearIndividualFileds();
                this.campaingDetails.emailDetails.contacts = null;
            }
        } else {
            if (this.isFromContactList === 'true') {
                this.campaingDetails.emailDetails.contacts = this.constatDetailsFromContactPage;
                if (this.campaingDetails.emailDetails.contacts === undefined || this.campaingDetails.emailDetails.contacts === null) {
                    this.sendErrorMessage = 'Please choose either Individual ,List and Contacts';
                    this.editWelcome();
                    return;
                } else {
                    this.campaingDetails.emailDetails.contactList = null;
                    this.clearIndividualFileds();
                }
            }
        }
    }
    send() {
        this.createCampaignObjectForUpdate();
        const options = this.commonUtil.getModalPopUpSettings();
        delete options.size;
        this.scheduleModalRef = this.modalService.open(CampaignSendEmailConfirmationComponent, options);
        this.scheduleModalRef.componentInstance.campaingDetails = this.campaingDetails;
        this.scheduleModalRef.componentInstance.pageName = this.pageName;
        this.scheduleModalRef.componentInstance.isSeries = this.isSeries;
        this.sendErrorMessage = '';
    }
    schedule(id) {
        if (this.pageName === 'campaignList') {
            this.createCampaignObjectForUpdate();
            this.editEmailSchedule();
        } else {
            const options = this.commonUtil.getModalPopUpSettings();
            delete options.size;
            this.scheduleModalRef = this.modalService.open(CampaignScheduleComponent, options);
            this.scheduleModalRef.componentInstance.campaignId = id;
            this.scheduleModalRef.componentInstance.campaignName = this.campaingDetails.name;
            this.scheduleModalRef.componentInstance.action = 'create';
        }
    }
    editEmailSchedule() {
        const options = this.commonUtil.getModalPopUpSettings();
        delete options.size;
        this.scheduleModalRef = this.modalService.open(CampaignScheduleComponent, options);
        this.scheduleModalRef.componentInstance.campaingDetails = this.campaingDetails;
        this.scheduleModalRef.componentInstance.action = 'edit';
    }
    welcomeDivCancel() {
        this.isWelcomeDivDisplay = false;
        // this.router.navigate(['/createCampaign']);
    }
    selectTemplate() {
        this.router.navigate(['/template'], { queryParams: { pageName: 'campaignPage', campaignId: this.campaingDetails.id } });
    }

    editSchedule(templateId) {
        const options = this.commonUtil.getModalPopUpSettings();
        options.size = 'lg';
        this.scheduleModalRef = this.modalService.open(AddTemplateSeriesComponent, options);
        this.scheduleModalRef.componentInstance.seriesResponse = this.seriesDetails;
        this.scheduleModalRef.componentInstance.templateId = templateId;
        this.scheduleModalRef.componentInstance.action = 'editSchedule';
        this.scheduleModalRef.componentInstance.cancelAction = 'campaignRedirection';
    }
    deleteSeries(templateId) {
        delete this.seriesDetails.templates[templateId.toString()];
        this._seriesService.createSchedule(this.seriesDetails).subscribe((response: Series) => {
            console.log(' delete series response..', response);
        });
    }
    addTemplate() {
        const options = this.commonUtil.getModalPopUpSettings();
        options.size = 'lg';
        this.scheduleModalRef = this.modalService.open(AddTemplateSeriesComponent, options);
        this.scheduleModalRef.componentInstance.seriesResponse = this.seriesDetails;
        this.scheduleModalRef.componentInstance.action = 'addTemplate';
        this.scheduleModalRef.componentInstance.cancelAction = 'campaignRedirection';
    }

    createCampaign() {}

    deleteAttachment(attachmentId) {
        this.campaignService.deleteAttachment(attachmentId).subscribe((response: any) => {
            console.log('attachment is deleted successfully.....', response);
        });
        this.userUploadedFiles = this.userUploadedFiles.filter(att => att.id !== attachmentId);
    }

    deleteUserAttachment(attachmentId) {
        this.campaignService.deleteAttachment(attachmentId).subscribe((response: any) => {
            console.log('attachment is deleted successfully.....', response);
        });
        this.attachments = this.attachments.filter(att => att.id !== attachmentId);
    }

    getSenderInfo() {
        this._userProfileService.getSenderInfo().subscribe((response: SenderProfile[]) => {
            this.allSenderDetails = response;
            this.selectedProfile = this.allSenderDetails[0].id;
            this.senderEmail = this.allSenderDetails[0].email;
        });
    }
    onSelectProfile(profileId) {
        this.selectedProfile = profileId;
        this.fromChk = true;
        for (const profile of this.allSenderDetails) {
            if (profile.id === parseInt(profileId, 0)) {
                this.senderEmail = profile.email;
            }
        }
    }

    clearIndividualFileds() {
        this.campaingDetails.emailDetails.toName = null;
        this.campaingDetails.emailDetails.ccList = null;
        this.campaingDetails.emailDetails.toEmail = null;
        this.campaingDetails.emailDetails.bccList = null;
    }
    clearContactsAndContactList() {
        this.campaingDetails.emailDetails.contactList = null;
        this.campaingDetails.emailDetails.contacts = null;
    }
    IntializeIndividualFileds() {
        this.campaingDetails.emailDetails.toName = this.toName;
        this.campaingDetails.emailDetails.ccList = this.ccList;
        this.campaingDetails.emailDetails.toEmail = this.toEmail;
        this.campaingDetails.emailDetails.bccList = this.bccList;
    }
    editCampaignName(campaignId) {
        const options = this.commonUtil.getModalPopUpSettings();
        delete options.size;
        const modalRef = this.modalService.open(EditCampaignNameComponent, options);
        modalRef.componentInstance.campaignReponse = this.campaingDetails;
        modalRef.componentInstance.campaignName = this.campaingDetails.name;
        modalRef.componentInstance.editCampaignResponse.subscribe(editResponse => {
            this.campaingDetails = editResponse;
            this.campaignName = editResponse.name;
        });
    }
    updateCampaignDetails() {
        this.campaignService.updateCampaign(this.campaingDetails).subscribe((updateCampaignResponse: Campaign) => {
            this.campaingDetails = updateCampaignResponse;
        });
    }
}
