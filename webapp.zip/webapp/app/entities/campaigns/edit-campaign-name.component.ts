import { Component, OnInit, Input, EventEmitter, Output } from '@angular/core';
import { NgbModal, NgbActiveModal } from '@ng-bootstrap/ng-bootstrap';
import { CampaignService } from './campaigns.service';
import { Campaign } from '../../shared/model/email-campaign-regular.model';

@Component({
    selector: 'jhi-edit-campaign-name',
    templateUrl: './edit-campaign-name.component.html',
    styleUrls: ['./edit-campaign-name.component.css']
})
export class EditCampaignNameComponent implements OnInit {
    @Input() campaignReponse;
    @Input() campaignName: any;
    @Output() editCampaignResponse: EventEmitter<any> = new EventEmitter();
    errorMessage: any;
    constructor(public campaignService: CampaignService, public activeModal: NgbActiveModal) {}

    ngOnInit() {}

    editCampaignName() {
        if (this.campaignName.replace(/ /g, '').length === 0) {
            this.errorMessage = 'Please enter series name';
            return;
        } else {
            this.errorMessage = '';
        }
        const oldName = this.campaignReponse.name;
        this.campaignReponse.name = this.campaignName;
        this.campaignService.updateCampaign(this.campaignReponse).subscribe(
            (response: Campaign) => {
                console.log(' edit series name response..', response);
                this.editCampaignResponse.emit(response);
                this.activeModal.dismiss('Cross click');
            },
            err => {
                this.campaignReponse.name = oldName;
                console.error('edit series  is failed ...........');
            }
        );
    }
}
