import { Component, OnInit, OnDestroy, Input, Inject, EventEmitter, Output, ElementRef, ViewChild, OnChanges } from '@angular/core';
import { FileUploader, FileItem, FileLikeObject } from 'ng2-file-upload';
import { LocalStorageService, SessionStorageService } from 'ngx-webstorage';
@Component({
    selector: 'jhi-upload-field',
    templateUrl: './upload.component.html',
    styleUrls: ['./upload.component.css']
})
export class UploadFieldComponent implements OnInit {
    @Input() public url: string = null; // Url api process upload
    @Input() public accept: Array<string> = [];
    @Input() public maxFileSize: number = 10 * 1024 * 1024; // 10MB
    @Input() public maxFile: any; // Default 0 is unlimited
    @Input() public multiple: any; // Default false is single file, true is multiple file
    @Input() public errorMessageMaxSize: any;
    @Input() public errorMessageWrongType: any;
    @Input() public errorMessageLimit: any;
    @ViewChild('fileInput') fileInput;
    public token: string;
    public errorMessage: any = '';
    public uploader: FileUploader = new FileUploader({});

    constructor(private localStorage: LocalStorageService, private sessionStorage: SessionStorageService) {}

    public ngOnInit() {
        this.token = this.token = this.localStorage.retrieve('authenticationToken') || this.sessionStorage.retrieve('authenticationToken');
        this.uploader.setOptions({
            url: this.url,
            headers: [{ name: 'Accept', value: 'application/json' }],
            autoUpload: false,
            maxFileSize: this.maxFileSize,
            method: 'put',
            itemAlias: 'multipartFile',
            queueLimit: this.maxFile,
            authToken: 'Bearer ' + this.token
        });
        this.uploader.onWhenAddingFileFailed = (item, filter, options) => this.onWhenAddingFileFailed(item, filter, options);
        this.uploader.onAfterAddingAll = items => this.onAfterAddingAll(items);
        this.uploader.onAfterAddingFile = item => this.onAfterAddingFile(item);
        this.uploader.onProgressItem = (progress: any) => {
            console.log('qqqqqqqqqqqqqqqqq ', progress['progress']);
        };
    }
    /**
     * Check file is image
     *
     * @param {*} fileType
     * @returns {boolean}
     */
    public isImage(fileType: any): boolean {
        return /^image\/(.*)$/.test(fileType);
    }

    /**
     * Check max file
     *
     * @returns {boolean}
     */
    public isMaxFile(): boolean {
        if (this.maxFile === 0) {
            return false;
        }
        return this.uploader.queue.length >= this.maxFile;
    }

    /**
     * Remove file item
     *
     * @param {FileItem} item
     */
    public removeItem(item: FileItem): void {
        item.remove();
        this.fileInput.nativeElement.value = '';
        // this.onItemChanged.emit(this.getQueueFiles());
    }

    /**
     * Get queue files
     *
     * @returns {*}
     */
    public getQueueFiles(): Array<any> {
        return this.uploader.queue;
    }

    /**
     * Set queue files
     *
     * @returns {*}
     */
    public setQueueFiles(queue: Array<any>): void {
        this.uploader.queue = queue;
    }

    /**
     * Get all files in queue
     *
     * @returns {*}
     */
    public getFiles(): Array<any> {
        return this.uploader.queue.map(item => item.file);
    }

    /**
     * Add file failed hanlde
     *
     * @private
     * @param {FileLikeObject} item
     * @param {*} filter
     * @param {*} options
     */
    private onWhenAddingFileFailed(item: FileLikeObject, filter: any, options: any) {
        switch (filter.name) {
            case 'fileSize': {
                this.errorMessage = this.errorMessageMaxSize;
                break;
            }
            case 'mimeType': {
                this.errorMessage = this.errorMessageWrongType;
                break;
            }
            default: {
                this.errorMessage = '';
            }
        }
    }

    /**
     * Handle choice files
     *
     * @private
     * @param {*} items
     */
    private onAfterAddingAll(items: any) {
        console.log('onAfterAddingAll ', items);
        if (items.length > this.maxFile) {
            this.uploader.clearQueue();
            this.fileInput.nativeElement.value = '';
            this.errorMessage = this.errorMessageLimit;
            //  this.onItemChanged.emit(this.getQueueFiles());
            return;
        } else {
            this.errorMessage = '';
        }
    }

    /**
     * Handle add file
     *
     * @private
     * @param {*} item
     */
    private onAfterAddingFile(item: any) {
        if (this.checkDuplicateFiles(item)) {
            item.remove();
            //  this.onItemChanged.emit(this.getQueueFiles());
        }
        if (item.file.type === 'application/x-msdownload') {
            item.remove();
            this.fileInput.nativeElement.value = '';
            this.errorMessage = 'exe files will not allow';
        }
    }

    /**
     * Check duplicate file
     *
     * @private
     * @param {*} item
     * @returns {boolean}
     */
    private checkDuplicateFiles(item: any): boolean {
        let checkItem: any = 0;
        this.uploader.queue.map(itemQueue => {
            checkItem += itemQueue.file.name === item.file.name && itemQueue.file.size === item.file.size ? 1 : 0;
        });

        return checkItem > 1;
    }

    public getMaxFileCount() {
        if (this.maxFile === 0) {
            return false;
        }
        return this.uploader.queue.length > this.maxFile;
    }
}
