import { Component, Inject } from '@angular/core';
import { Campaign } from './../../shared/model/email-campaign-regular.model';
import { MAT_DIALOG_DATA, MatDialogRef } from '@angular/material';
@Component({
    selector: 'jhi-campaign-delete',
    templateUrl: 'campaign-delete.component.html',
    styleUrls: []
})
export class CampaignDeleteComponent {
    constructor(public dialogRef: MatDialogRef<CampaignDeleteComponent>, @Inject(MAT_DIALOG_DATA) public campaign: Campaign) {}

    onNoClick(): void {
        this.dialogRef.close();
    }
}
