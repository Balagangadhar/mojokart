import { Injectable } from '@angular/core';
import { CampaignSchedule } from './../../shared/model/email-campaign-regular.model';
import { TextCampaign } from './../../shared/model/text-campaign.model';
import { Observable, of, throwError } from 'rxjs';
import { HttpClient, HttpResponse, HttpHeaders, HttpHandler, HttpErrorResponse } from '@angular/common/http';
import { SERVER_API_URL } from 'app/app.constants';
import { IAccount } from '../../shared/model/account.model';
import { IBlob, Blob } from '../../shared/model/blob.model';
import { IEmailusage } from '../../shared/model/email-usage.model';
import { IRegularCampaign, Campaign, ICampaign } from '../../shared/model/email-campaign-regular.model';

@Injectable({
    providedIn: 'root'
})
export class CampaignService {
    private accountUrl = SERVER_API_URL + 'api/account';
    private uploadUrl = SERVER_API_URL + 'api/blobs?type=ATTACHMENT';
    private regularCampaignUrl = SERVER_API_URL + 'api/campaigns/';
    private publishedCampaigns = SERVER_API_URL + 'api/campaigns/published';
    private newCampaignFromExisting = SERVER_API_URL + 'api/campaigns/exisiting/';
    //  private attachmentUrl = SERVER_API_URL + 'api/blobs?type=ATTACHMENT';
    private isDuplicateCampaignUrl = SERVER_API_URL + 'api/campaigns/isduplicate/';
    private deleteBlobUrl = SERVER_API_URL + 'api/blobs/';
    private emailUsageStatsUrl = SERVER_API_URL + 'api/account/usage/';
    constructor(private http: HttpClient) {}

    getLoggedInUserDetails() {
        return this.http.get<IAccount>(this.accountUrl);
    }

    getEmailUsageStats() {
        return this.http.get<IEmailusage>(this.emailUsageStatsUrl);
    }

    uploadAttachment(formData): Observable<IBlob> {
        return this.http.put<IBlob>(this.uploadUrl, formData);
    }

    createRegularCampaign(requestData: IRegularCampaign): Observable<IRegularCampaign> {
        return this.http.post<IRegularCampaign>(this.regularCampaignUrl, requestData);
    }

    updateCampaign(requestData: IRegularCampaign): Observable<IRegularCampaign> {
        return this.http.put<IRegularCampaign>(this.regularCampaignUrl, requestData);
    }
    sendRegularCampaign(requestData: IRegularCampaign): Observable<IRegularCampaign> {
        return this.http.post<IRegularCampaign>(this.regularCampaignUrl + requestData.id + '/send', requestData);
    }

    getCampaignDetailsById(id) {
        return this.http.get<Campaign>(this.regularCampaignUrl + id);
    }
    createSchedule(id, scheduleRequest) {
        return this.http.post<IRegularCampaign>(this.regularCampaignUrl + id + '/schedule', scheduleRequest);
    }
    createTextCampaign(textCampaign: TextCampaign): Observable<TextCampaign> {
        return this.http.post<TextCampaign>(this.regularCampaignUrl, textCampaign);
    }
    getTextCampaign(id: number): Observable<TextCampaign> {
        return this.http.get<TextCampaign>(this.regularCampaignUrl + id);
    }
    updateTextCampaign(textCampaign: TextCampaign): Observable<TextCampaign> {
        console.log('update campaign ', textCampaign);
        return this.http.put<TextCampaign>(this.regularCampaignUrl, textCampaign);
    }
    sendTextCampaign(id: number): Observable<TextCampaign> {
        console.log('text campaign sending', id);
        return this.http.post<TextCampaign>(this.regularCampaignUrl + id + '/send', null);
    }
    scheduleTextCampaign(id: number, campaignSchedule: CampaignSchedule) {
        return this.http.post<TextCampaign>(this.regularCampaignUrl + id + '/schedule', campaignSchedule);
    }
    deleteAttachment(id): Observable<any> {
        return this.http.get<Blob>(this.deleteBlobUrl + id);
    }
    getCampaignDetails() {
        return this.http.get<Campaign>(this.publishedCampaigns);
    }
    createNewRegularCampaignId(id): Observable<any> {
        return this.http.get<Campaign>(this.newCampaignFromExisting + id);
    }
    isDuplicateCampaign(campaignName): Observable<any> {
        return this.http.get<any>(this.isDuplicateCampaignUrl + campaignName);
    }
}
