import { Injectable } from '@angular/core';
import { HttpClient, HttpResponse, HttpParams } from '@angular/common/http';
import { SERVER_API_URL } from 'app/app.constants';
import { Observable } from 'rxjs';
import { Campaign } from 'app/shared/model/email-campaign-regular.model';
import { createRequestOption } from 'app/shared';
type EntityResponseType = HttpResponse<Campaign>;
type EntityArrayResponseType = HttpResponse<Campaign[]>;
@Injectable({
    providedIn: 'root'
})
export class CampaignListService {
    private requestUrl = SERVER_API_URL + 'api/campaigns';
    constructor(private http: HttpClient) {}

    getCampaignById(id: number): Observable<any> {
        return this.http.get<Campaign>(this.requestUrl + '/' + id);
    }

    getCampaigns(req: any): Observable<any> {
        const options = createRequestOption(req);
        return this.http.get<EntityArrayResponseType>(this.requestUrl, { params: options, observe: 'response' });
    }

    delete(id: number): Observable<any> {
        console.log(this.requestUrl + '/' + id);
        return this.http.delete<any>(this.requestUrl + '/' + id);
    }
}
