import { Component, ViewChild, AfterViewInit, ViewEncapsulation } from '@angular/core';
import { MatDialog, MatPaginator, MatSort } from '@angular/material';
import { HttpClient } from '@angular/common/http';
import { merge, of as observableOf } from 'rxjs';
import { startWith, switchMap, map, catchError } from 'rxjs/operators';
import { Router, ActivatedRoute } from '@angular/router';
import { CampaignListService } from './campaign-list.service';
import { CampaignService } from '../campaigns.service';
import { Campaign } from 'app/shared/model/email-campaign-regular.model';
import { CampaignDeleteComponent } from '../campaign-delete.component';
import { CampaignPreviewComponent } from '../campaign-preview.component';
@Component({
    selector: 'jhi-campaign-list',
    templateUrl: './campaign-list.component.html',
    styleUrls: ['./campaign-list.component.css'],
    encapsulation: ViewEncapsulation.None
})
export class CampaignListComponent implements AfterViewInit {
    displayedColumns: string[] = ['name', 'type', 'status', 'createdDate', 'lastModifiedDate', 'actions'];
    apiService: CampaignListService | null;
    campService: CampaignService | null;
    dataSource: Campaign[] = [];
    resultsLength = 0;
    campaignTypes = ['EMAIL', 'SERIES'];
    isLoadingResults = true;
    isRateLimitReached = false;
    @ViewChild(MatPaginator) paginator: MatPaginator;

    @ViewChild(MatSort) sort: MatSort;
    searchText = '';
    tabIndex = 0;
    publishedCampaigns: any;
    isPublishedCampaignsAavailable = false;
    campaignList: any;
    constructor(private http: HttpClient, public dialog: MatDialog, private router: Router, private route: ActivatedRoute) {}
    ngAfterViewInit() {
        this.apiService = new CampaignListService(this.http);
        this.sort.sortChange.subscribe(() => (this.paginator.pageIndex = 0));
        merge(this.sort.sortChange, this.paginator.page)
            .pipe(
                startWith({}),
                switchMap(() => {
                    this.isLoadingResults = true;
                    return this.apiService!.getCampaigns({
                        types: this.campaignTypes,
                        page: this.paginator.pageIndex,
                        size: this.paginator.pageSize,
                        sort: [this.sort.active + ',' + this.sort.direction],
                        searchText: this.searchText
                    });
                }),
                map(data => {
                    this.isLoadingResults = false;
                    this.isRateLimitReached = false;
                    this.resultsLength = data.headers.get('x-total-count');
                    console.log('in map' + JSON.stringify(data));
                    return data;
                }),
                catchError(() => {
                    this.isLoadingResults = false;
                    this.isRateLimitReached = true;
                    return observableOf([]);
                })
            )
            .subscribe(data => {
                this.dataSource = data.body;
                console.log('in component' + JSON.stringify(this.dataSource));
            });
    }
    applyFilter(searchText: string) {
        this.searchText = searchText;
        this.ngAfterViewInit();
    }
    onEdit(campaign: Campaign) {
        console.log('campaign', campaign);
        if (campaign.type === 'EMAIL' || campaign.type === 'SERIES') {
            this.emailCampaignEdit(campaign);
        } else if (campaign.type === 'TEXT') {
            this.textCampaignEdit(campaign);
        }
    }
    onDelete(campaign: Campaign) {
        console.log(campaign);
    }
    emailCampaignEdit(campaign: Campaign) {
        // this.apiService.getCampaignById(campaign.id).subscribe((data: Campaign) => this.previewDialog(data));
        console.log(campaign);
        this.router.navigate(['/regularEmailCampaign'], { queryParams: { pageName: 'campaignList', campaingId: campaign.id } });
    }
    onPreview(campaign: Campaign) {
        this.apiService.getCampaignById(campaign.id).subscribe((data: Campaign) => this.previewDialog(data));
    }
    deleteDialog(campaign: Campaign): void {
        const dialogRef = this.dialog.open(CampaignDeleteComponent, {
            width: 'auto',
            data: campaign
        });
        dialogRef.afterClosed().subscribe(result => {
            console.log('The dialog was closed......' + JSON.stringify(result));
            if (result) {
                this.apiService.delete(result.id).subscribe(() => this.ngAfterViewInit());
            }
        });
    }
    deleteDialogExisting(campaign: Campaign): void {
        const dialogRef = this.dialog.open(CampaignDeleteComponent, {
            width: 'auto',
            data: campaign
        });
        dialogRef.afterClosed().subscribe(result => {
            console.log('The dialog was closed......' + JSON.stringify(result));
            if (result) {
                this.apiService.delete(result.id).subscribe(() => this.getExistingCampaigns());
            }
        });
    }
    previewDialog(campaign: Campaign): void {
        const dialogRef = this.dialog.open(CampaignPreviewComponent, {
            width: 'auto',
            data: campaign
        });
        dialogRef.afterClosed().subscribe(result => {
            console.log('The dialog was closed......' + JSON.stringify(result));
        });
    }
    textCampaignEdit(campaign: Campaign) {
        console.log(campaign);
        this.router.navigate(['/text-campaigns'], {
            queryParams: {
                id: campaign.id,
                update: true
            }
        });
    }

    getExistingCampaigns() {
        this.campService = new CampaignService(this.http);
        this.campService!.getCampaignDetails().subscribe(response => {
            console.log('campaign list response');
            this.isPublishedCampaignsAavailable = true;
            this.publishedCampaigns = response;
            console.log('in component' + JSON.stringify(response));
        });
    }
    // tab events
    tabChanged($event) {
        this.searchText = '';
        this.tabIndex = $event.index;
        console.log($event.index, 'search index');
        if ($event.index === 0) {
            this.campaignTypes = ['EMAIL', 'SERIES'];
            this.ngAfterViewInit();
        } else if ($event.index === 1) {
            this.campaignTypes = ['TEXT'];
            this.ngAfterViewInit();
        } else if ($event.index === 2) {
            // this.campaignTypes = [''];
            // this.ngAfterViewInit();
            this.getExistingCampaigns();
        }
    }
}
