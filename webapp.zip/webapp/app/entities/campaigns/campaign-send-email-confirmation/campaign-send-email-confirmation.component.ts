import { Component, OnInit, Input } from '@angular/core';
import { CampaignService } from '../campaigns.service';
import { NgbActiveModal } from '@ng-bootstrap/ng-bootstrap';
import { ICampaign } from '../../../shared/model/email-campaign-regular.model';
import { ActivatedRoute, Router } from '@angular/router';

@Component({
    selector: 'jhi-campaign-send-email-confirmation',
    templateUrl: './campaign-send-email-confirmation.component.html',
    styles: []
})
export class CampaignSendEmailConfirmationComponent implements OnInit {
    @Input() campaingDetails;
    @Input() isSeries;
    @Input() pageName;
    constructor(public router: Router, public campaignService: CampaignService, public activeModal: NgbActiveModal) {}

    ngOnInit() {}
    sendEmail() {
        this.campaignService.sendRegularCampaign(this.campaingDetails).subscribe((sendEmailResponse: ICampaign) => {
            console.log('send email final response ', sendEmailResponse);
            this.activeModal.dismiss('Cross click');
            this.router.navigate(['/sendEmailSuccess'], {
                queryParams: { campaignName: this.campaingDetails.name, isSeries: false }
            });
        });
    }
    /*
    sendEmail() {
         FIXME Remove nested subscribe calls
            isSeries will be false when create campaign with out series.
            create campaign with series -- isSeries will be true and pageName will be undefined
            edit campaign series from campaign lis page -- isSeries will be true and page name will be campaignList
        console.log('this.isSeries ', this.isSeries);
        console.log('this.pageName ', this.pageName);
        console.log('condition ', this.isSeries === 'true' && this.pageName !== 'campaignList');
        if (this.isSeries === 'true' && this.pageName !== 'campaignList') {
            this.campaignService.createRegularCampaign(this.campaingDetails).subscribe((response: ICampaign) => {
                this.campaignService.sendRegularCampaign(response).subscribe((sendEmailResponse: ICampaign) => {
                    console.log('send email final response ', sendEmailResponse);
                    this.activeModal.dismiss('Cross click');
                    this.router.navigate(['/sendEmailSuccess'], {
                        queryParams: { campaignName: this.campaingDetails.name, isSeries: true }
                    });
                });
            });
        } else {
            this.campaignService.updateCampaign(this.campaingDetails).subscribe((response: ICampaign) => {
                this.campaignService.sendRegularCampaign(response).subscribe((sendEmailResponse: ICampaign) => {
                    console.log('send email final response ', sendEmailResponse);
                    this.activeModal.dismiss('Cross click');
                    this.router.navigate(['/sendEmailSuccess'], {
                        queryParams: { campaignName: this.campaingDetails.name, isSeries: false }
                    });
                });
            });
        }
} */
}
