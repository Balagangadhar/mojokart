import { Injectable } from '@angular/core';

import { Campaign } from '../shared/model/email-campaign-regular.model';
import { RegularCampaign } from '../shared/model/email-campaign-regular.model';

export class PersistData {
    constructor(
        public uploadFiles: any,
        public toChk: boolean,
        public subjectChk: boolean,
        public fromChk: boolean,
        public isIndividual: boolean,
        public isSeries: boolean
    ) {}
}
@Injectable({
    providedIn: 'root'
})
export class GlobalSendEmailDataService {
    public regularCampaignData: Campaign;
    public persistData: PersistData;
    public filesUpload: any;

    constructor() {}
    setEmailData(emailData) {
        this.regularCampaignData = emailData;
    }
    getEmailData() {
        return this.regularCampaignData;
    }
    clearEmailData() {
        this.regularCampaignData = new Campaign(0, '', 'DRAFT', 'EMAIL', new RegularCampaign(), 0);
        return this.regularCampaignData;
    }

    setPersistData(persistData) {
        this.persistData = persistData;
    }

    getPersistData() {
        return this.persistData;
    }
    clearPersistData() {
        this.persistData = new PersistData(null, false, false, false, false, false);
        return this.persistData;
    }

    setFilesUpload(filesUpload) {
        this.filesUpload = filesUpload;
    }

    getFilesUpload() {
        return this.filesUpload;
    }
    clearFilesUpload() {
        this.filesUpload = [];
        return this.filesUpload;
    }
}
