import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { RouterModule } from '@angular/router';
import { TemplateComponent, templateRoutes } from './';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { CKEditorModule } from 'ng2-ckeditor';
import { NgbModule } from '@ng-bootstrap/ng-bootstrap';
import { TemplateBodyComponent } from './template-body.component';
import { TemplateNameFilterPipe } from './template-name-filter.pipe';
import { SpamScoreRequestComponent } from './spam-score-request.component';
import { NgxGaugeModule } from 'ngx-gauge';
import { SharedCommonModule } from '../../shared/shared-common.module';
import { FileUploadModule } from 'ng2-file-upload';
import { TemplateActionComponent } from './template-action.component';
import { TemplateFileUploadComponent } from './template-file-upload.component';
import { DeleteTemplateComponent } from './delete-template.component';
const ENTITY_STATES = [...templateRoutes];

@NgModule({
    declarations: [
        TemplateComponent,
        TemplateBodyComponent,
        TemplateNameFilterPipe,
        SpamScoreRequestComponent,
        TemplateActionComponent,
        TemplateFileUploadComponent,
        DeleteTemplateComponent
    ],
    imports: [
        BrowserAnimationsModule,
        CommonModule,
        FormsModule,
        ReactiveFormsModule,
        CKEditorModule,
        NgbModule,
        NgxGaugeModule,
        SharedCommonModule,
        FileUploadModule,
        RouterModule.forChild(ENTITY_STATES)
    ],
    exports: [SharedCommonModule],
    entryComponents: [DeleteTemplateComponent, SpamScoreRequestComponent, TemplateActionComponent, TemplateFileUploadComponent]
})
export class TemplateModule {}
