import { SpamScoreRequestService } from './spam-score-request.service';
import { Component, Input, AfterContentInit } from '@angular/core';
import { ISpamScoreRequest, SpamScoreRequestStatus } from '../../shared/model/spam-score-request.model';
import { NgbActiveModal } from '@ng-bootstrap/ng-bootstrap';
import { MAX_SPAM_SCORE_REQUEST_POLL_COUNT } from 'app/app.constants';

@Component({
    selector: 'jhi-spamchecker',
    templateUrl: './spam-score-request.component.html',
    styles: ['./template.component.css']
})
export class SpamScoreRequestComponent implements AfterContentInit {
    @Input() loading = true;
    spamScoreRequest: ISpamScoreRequest = {};
    spamResponse: any;
    errorGaugeLabel;
    errorMessage;
    pollCount = 0;
    spamScoreThresholdConfig = {
        '0': { color: 'green' },
        '4': { color: 'orange' },
        '5': { color: 'red' }
    };
    progress = 0;

    constructor(public activeModal: NgbActiveModal, private spamScoreRequestService: SpamScoreRequestService) {}

    ngAfterContentInit(): void {
        this.getSpamScoreRequestStatus();
    }

    private getSpamScoreRequestStatus() {
        this.spamScoreRequestService.get(this.spamScoreRequest.id).subscribe(
            res => {
                this.spamScoreRequest = res;
                this.progress = res.status === SpamScoreRequestStatus.COMPLETED ? 100 : this.progress;
                if (
                    res.status === SpamScoreRequestStatus.QUEUED ||
                    res.status === SpamScoreRequestStatus.SENT ||
                    res.status === SpamScoreRequestStatus.DELIVERED
                ) {
                    this.pollSpamScoreRequestStatus();
                }
                if (res.status === SpamScoreRequestStatus.FAILED) {
                    this.setErrorStatus();
                }
            },
            () => {
                this.pollSpamScoreRequestStatus();
            }
        );
    }

    private setErrorStatus() {
        this.progress = 100;
        this.errorGaugeLabel = 'Error!';
        this.errorMessage = 'Failed to check spam score, please try again';
    }

    private pollSpamScoreRequestStatus() {
        if (this.pollCount < MAX_SPAM_SCORE_REQUEST_POLL_COUNT) {
            setTimeout(this.getSpamScoreRequestStatus.bind(this), 5000);
            this.pollCount++;
            this.progress += 20;
        } else {
            this.setErrorStatus();
        }
    }

    getMessage(): string {
        if (this.errorMessage) {
            return this.errorMessage;
        }
        if (this.spamScoreRequest.score === null) {
            return 'Please note that spam score requests count towards your usage';
        }
        if (this.spamScoreRequest.score <= 1) {
            return 'Wow! Your content is absolutely fine to go.';
        }
        if (this.spamScoreRequest.score <= 2) {
            return 'You are really good to go.';
        }
        if (this.spamScoreRequest.score <= 3) {
            return 'You are good to go.';
        }
        if (this.spamScoreRequest.score <= 5) {
            return 'You can go ahead but your content can be improved.';
        }
        if (this.spamScoreRequest.score >= 5) {
            return 'Sorry, you need to improve your content quality.';
        }
        return null;
    }

    getGaugeLabel(): string {
        if (this.errorGaugeLabel) {
            return this.errorGaugeLabel;
        }
        if (this.spamScoreRequest.score === null) {
            return 'Processing...';
        }
        if (this.spamScoreRequest.score <= 1) {
            return 'Excellent';
        }
        if (this.spamScoreRequest.score <= 2) {
            return 'Very Good';
        }
        if (this.spamScoreRequest.score <= 3) {
            return 'Good';
        }
        if (this.spamScoreRequest.score <= 5) {
            return 'Just Okay';
        }
        if (this.spamScoreRequest.score >= 5) {
            return 'Spam';
        }
        return null;
    }
}
