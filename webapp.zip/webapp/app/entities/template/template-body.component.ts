import { Component, OnInit, ViewChild, ViewEncapsulation, Input, Output, EventEmitter } from '@angular/core';
import { ITemplate, Template } from '../../shared/model/template.model';
import { Campaign, IRegularCampaign } from '../../shared/model/email-campaign-regular.model';
import { TemplateService } from './template.service';
import { NgbModal } from '@ng-bootstrap/ng-bootstrap';
import { ActivatedRoute, Router } from '@angular/router';
import { GlobalSendEmailDataService } from '../global-send-email-data.service';
import { Account } from 'app/shared/model/account.model';
import { AccountService } from '../../core/auth/account.service';
import { CampaignService } from '../campaigns/campaigns.service';
import { LocalStorageService, SessionStorageService } from 'ngx-webstorage';
import { CommonUtil } from '../../shared/util/common-util';
import { TemplateFileUploadComponent } from './template-file-upload.component';
import { USER_TYPE, CONTENT_TYPE } from '../../shared/model/subgroup.model';
import { forkJoin } from 'rxjs';
@Component({
    selector: 'jhi-template-body',
    templateUrl: 'template-body.component.html',
    encapsulation: ViewEncapsulation.None,
    styleUrls: ['./template.component.css']
})
export class TemplateBodyComponent implements OnInit {
    showButtons: boolean;
    isStandard: boolean;
    isAdmin: boolean;
    readOnlyEditor = true;
    templateType: string;
    dropDownDisabled = false;
    attachmentArray = [];
    attachmentUrl: string;
    queryParamTempId: number;
    banner: any;
    bannerUrl: any;
    name = 'ng2-ckeditor';
    ckeConfig: any;
    templateContent: any;
    log: string;
    templatedata: ITemplate[];
    templates = [];
    templateResponse: any;
    selectedTemplateId: number;
    selected: any;
    templateData: any;
    templateId: number;
    @Input() tabName: any;
    @Input() newTemplateName: string;
    @Input() templateName: string;
    @Input() templateSubject: string;
    pageName: string = null;
    currentAccount: Account;
    campaignId: any;
    imageContent: any = [];
    // @ViewChild('libraryTab') tab;
    @Output() isTemplateSelected = new EventEmitter();
    @Output() selectedTemplateName = new EventEmitter();
    @Output() refeshParentPropertiesWhenChildRefresh = new EventEmitter();
    @Output() selectedTemplateSubject = new EventEmitter();
    @Output() parentActionEventEmitter = new EventEmitter();
    action: any = '';
    isTemplateSelectedQueryParameter = false;
    templateAttachments: any = [];
    seriesId: any;
    selectedGroup: any;
    templateGroupResponse: any;
    isCompanyAdmin: boolean;
    isCompanyTab: boolean;
    isMytemplatesTab: boolean;
    constructor(
        public templateService: TemplateService,
        private modalService: NgbModal,
        private route: ActivatedRoute,
        public router: Router,
        public emailDataService: GlobalSendEmailDataService,
        private accountService: AccountService,
        public campaignService: CampaignService,
        private localStorage: LocalStorageService,
        private sessionStorage: SessionStorageService,
        private commonUtil: CommonUtil
    ) {
        this.accountService.identity().then(account => {
            this.currentAccount = account;
        });
        this.selectedTemplateId = -1;
        this.selectedGroup = -1;
        this.ckeConfig = {
            uiColor: '#cccccc',
            filebrowserBrowseUrl: '#/library',
            filebrowserWindowWidth: '640',
            filebrowserWindowHeight: '480',
            allowedContent: true,
            extraPlugins: ['field', 'lineheight'],
            removePlugins:
                'save, newpage, preview, wsc, scayt, about, pagebreak, flash, blockquote, dialogadvtab, div, iframe, forms, language, elementspath'
        };
        // this.getTemplateGroupList();
    }
    getTemplateGroupList() {
        let usertype;
        //   console.log(this.tabName.activeId);
        if (this.isStandard) {
            usertype = USER_TYPE.ROLE_ADMIN;
        } else if (this.isCompanyTab) {
            usertype = USER_TYPE.ROLE_COMPANY_ADMIN;
        }
        if (usertype) {
            this.templateService.getTemplateGroups(usertype, CONTENT_TYPE.ALL).subscribe((response: any) => {
                console.log('groupList........', response);
                this.templateGroupResponse = response;
            });
        }
    }
    onSelectTemplateGroup(selectedGroup) {
        console.log('selected group ', selectedGroup);
        this.templateContent = '';
        this.isTemplateSelected.emit(false);
        this.selectedTemplateId = -1;
        this.bannerUrl = null;
        this.templateAttachments = [];
        if (selectedGroup > 0) {
            this.templateService.getGroupTemplatesBySubGroupId(selectedGroup).subscribe((response: any) => {
                console.log(response);
                this.templateResponse = response;
            });
        }
    }

    OnDestroy() {
        if (this.templateContent) {
            this.templateContent.removeAllListeners();
            this.templateContent.destroy();
            this.templateContent = null;
        }
    }
    onSelectTemplate(template) {
        this.isTemplateSelected.emit(true);
        this.parentActionEventEmitter.emit('');
        this.action = '';
        this.isTemplateSelectedQueryParameter = true;
        this.readOnlyEditor = true;
        this.templateData = this.templateResponse.find(templates => templates.id === Number(template));
        this.selectedTemplateId = this.templateData.id;
        this.selectedTemplateName.emit(this.templateData.name);
        this.selectedTemplateSubject.emit(this.templateData.subject);
        this.templateContent = '';
        this.templateService.getTemplateDetailsById(this.selectedTemplateId).subscribe((newResponse: any) => {
            const textContent = newResponse.content;
            this.templateContent = textContent;
            this.templateAttachments = newResponse.attachments;
            this.banner = newResponse.banner;
            this.bannerUrl = newResponse.banner ? newResponse.banner.url : null;
        });
    }
    deleteAttachment(attachmentId) {
        this.campaignService.deleteAttachment(attachmentId).subscribe((response: any) => {});
        this.templateAttachments = this.templateAttachments.filter(att => att.id !== attachmentId);
    }

    getTemplateData() {
        if (this.tabName.activeId === 'tab-2') {
            this.templateService.getTemplates().subscribe((response: Template[]) => {
                this.templateResponse = response;
            });
        } else {
            this.getTemplateGroupList();
        }
    }

    getTemplateDataById() {
        this.templateService.getTemplateDetailsById(this.selectedTemplateId).subscribe((newResponse: any) => {
            const textContent = newResponse.content;
            this.templateContent = textContent;
            this.templateAttachments = newResponse.attachments;
            this.banner = newResponse.banner;
            this.bannerUrl = newResponse.banner ? newResponse.banner.url : null;
        });
    }

    loadTemplateFromLibrary() {
        if (this.pageName === 'libraryPage') {
            this.action = this.route.snapshot.queryParams['templateAction'];
            this.tabName.activeId = this.route.snapshot.queryParams['tabNameFromLibrary'];
            this.isTemplateSelected.emit(this.route.snapshot.queryParams['isTemplateSelected']);
            this.readOnlyEditor = false;
            if (this.route.snapshot.queryParams && this.route.snapshot.queryParams['subGroup']) {
                this.selectedGroup = this.route.snapshot.queryParams['subGroup'];
                if (this.selectedGroup > 0) {
                    this.onSelectTemplateGroup(this.selectedGroup);
                }
            }
            this.selectedTemplateId = this.route.snapshot.queryParams['tempId'];
            this.setGroupTemplate(this.selectedTemplateId);
            if (this.accountService.hasAuthority('ROLE_COMPANY_ADMIN')) {
                this.localStorage.store('selectedGroup', { grpid: this.selectedGroup, tempid: this.selectedTemplateId });
            }
            this.router.navigate(['/template']);
        }
    }

    setGroupTemplate(templateid) {
        this.templateService.find(templateid).subscribe((libraryTemplateResponse: any) => {
            this.selectedTemplateName.emit(libraryTemplateResponse.body.name);
            this.selectedTemplateSubject.emit(libraryTemplateResponse.body.subject);
            this.templateContent = libraryTemplateResponse.body.content;
            this.selectedTemplateName.emit(libraryTemplateResponse.body.name);
            this.selectedTemplateSubject.emit(libraryTemplateResponse.body.subject);
            this.templateAttachments = libraryTemplateResponse.body.attachments;
            this.banner = libraryTemplateResponse.body.banner;
            this.bannerUrl = libraryTemplateResponse.body.banner ? libraryTemplateResponse.body.banner.url : null;
            this.selectedTemplateId = libraryTemplateResponse.body.id;
        });
    }

    loadTemplateFromSeries() {
        if (this.pageName === 'seriesPage') {
            this.parentActionEventEmitter.emit('editTemplate');
            this.action = 'editTemplate';
            this.isTemplateSelected.emit(true);
            this.readOnlyEditor = false;
            if (this.route.snapshot.queryParams && this.route.snapshot.queryParams['subGroupId']) {
                this.selectedGroup = this.route.snapshot.queryParams['subGroupId'];
                if (this.selectedGroup > 0) {
                    this.onSelectTemplateGroup(this.selectedGroup);
                }
            }
            this.selectedTemplateId = this.route.snapshot.queryParams['templateId'];
            this.seriesId = this.route.snapshot.queryParams['seriesId'];
            this.templateService.find(this.selectedTemplateId).subscribe((newResponse: any) => {
                this.selectedTemplateName.emit(newResponse.body.name);
                this.selectedTemplateSubject.emit(newResponse.body.subject);
                this.templateContent = '';
                this.dropDownDisabled = true;
                const ownerType = newResponse.body.ownerType;
                if (ownerType === 'USER') {
                    this.tabName.activeId = 'tab-2';
                } else if (ownerType === 'COMPANY') {
                    this.tabName.activeId = 'tab-3';
                } else {
                    this.tabName.activeId = 'tab-1';
                }
                this.selectedTemplateId = newResponse.body.id;
                this.templateContent = newResponse.body.content;
                this.templateAttachments = newResponse.body.attachments;
                this.banner = newResponse.body.banner;
                this.bannerUrl = newResponse.body.banner ? newResponse.body.banner.url : null;
            });
        }
    }
    addTemplateToCampaign(templateResponse) {
        this.campaignService.getCampaignDetailsById(this.campaignId).subscribe((response: Campaign) => {
            response.emailDetails.template = templateResponse;
            response.emailDetails.message = templateResponse.content;
            this.campaignService.updateCampaign(response).subscribe((campaignResponse: IRegularCampaign) => {
                this.router.navigate(['/regularEmailCampaign'], { queryParams: { pageName: 'template', campaingId: campaignResponse.id } });
            });
        });
    }

    saveTemplateContent() {
        this.templateService.find(this.selectedTemplateId).subscribe((response: any) => {
            response.body.content = this.templateContent;
            response.body.attachments = this.templateAttachments;
            if (this.selectedGroup && response.body.ownerType !== 'USER') {
                this.templateService.update(response.body, this.selectedGroup).subscribe((updatedResponse: Template) => {});
            } else {
                this.templateService.update(response.body).subscribe((updatedResponse: Template) => {});
            }
        });
    }
    saveTemplate() {
        if (this.localStorage.retrieve('selectedGroup')) {
            this.localStorage.clear('selectedGroup');
        }
        this.templateService.getTemplateDetailsById(this.selectedTemplateId).subscribe((response: any) => {
            response.content = this.templateContent;
            response.attachments = this.templateAttachments;
            let subGrp: any;
            subGrp = response.subGroup ? response.subGroup : -1;
            this.templateService.update(response, subGrp ? subGrp.id : -1).subscribe((updatedResponse: Template) => {
                this.selectedTemplateName.emit('');
                this.selectedTemplateSubject.emit('');
                this.isTemplateSelected.emit(false);
                this.templateContent = '';
                this.templateAttachments = [];
                this.selectedTemplateId = -1;
                this.selectedGroup = -1;
                this.action = '';
                this.bannerUrl = null;
                if ((this.pageName != null || this.pageName !== undefined) && this.pageName === 'campaignPage') {
                    this.addTemplateToCampaign(updatedResponse);
                }
                if (this.pageName != null && this.pageName !== undefined && this.pageName === 'seriesPage') {
                    this.router.navigate(['/series'], { queryParams: { pageName: 'template', seriesId: this.seriesId } });
                }
            });
        });
        this.getTemplateData();
    }

    selectTemplateFromCampaignPage() {
        this.campaignService.getCampaignDetailsById(this.campaignId).subscribe((response: Campaign) => {
            const selectedTemplate = new Template();
            selectedTemplate.id = this.selectedTemplateId;
            response.emailDetails.template = selectedTemplate;
            this.campaignService.updateCampaign(response).subscribe((campaignResponse: IRegularCampaign) => {
                this.router.navigate(['/regularEmailCampaign'], { queryParams: { pageName: 'template', campaingId: campaignResponse.id } });
            });
        });
    }
    openVerticallyCentered(content) {
        const options = this.commonUtil.getModalPopUpSettings();
        delete options.size;
        this.modalService.open(content, options);
    }

    addBanner() {
        this.saveTemplateContent();
        this.router.navigate(['/library'], {
            queryParams: {
                pageName: 'templatePage',
                tempId: this.selectedTemplateId,
                isBanner: true,
                isStock: false,
                isMyImages: false,
                action: this.action,
                isTemplateSelected: this.isTemplateSelectedQueryParameter,
                tabNameFromTemplate: this.tabName.activeId,
                subGroupId: this.selectedGroup ? this.selectedGroup : 0
            }
        });
    }

    addAttachment() {
        this.saveTemplateContent();
        this.router.navigate(['/library'], {
            queryParams: {
                pageName: 'templatePage',
                tempId: this.selectedTemplateId,
                isBanner: false,
                isStock: true,
                action: this.action,
                isTemplateSelected: this.isTemplateSelectedQueryParameter,
                tabNameFromTemplate: this.tabName.activeId
            }
        });
    }

    ngOnInit() {
        this.getTemplateData();
        this.selectedTemplateId = -1;
        this.bannerUrl = null;
        this.templateAttachments = [];
        this.action = '';
        this.isTemplateSelected.emit(false);
        this.selectedTemplateName.emit('');
        this.selectedTemplateSubject.emit('');
        this.templateContent = '';
        this.pageName = this.route.snapshot.queryParams['pageName'];
        this.campaignId = this.route.snapshot.queryParams['campaignId'];
        this.templateId = this.route.snapshot.queryParams['templateId'];
        this.loadTemplateFromSeries();
        this.loadTemplateFromLibrary();
        this.isStandard = this.tabName.activeId === 'tab-1' ? true : false;
        this.isCompanyTab = this.tabName.activeId === 'tab-3' ? true : false;
        this.isMytemplatesTab = this.tabName.activeId === 'tab-2' ? true : false;
        const templateAction = this.route.snapshot.queryParams['templateAction'];
        let obj = {};
        const combineTwoObservables = forkJoin([
            this.accountService.hasAuthority('ROLE_ADMIN'),
            this.accountService.hasAuthority('ROLE_COMPANY_ADMIN')
        ]);
        combineTwoObservables.subscribe(result => {
            this.isAdmin = result[0];
            this.isCompanyAdmin = result[1];
            if (templateAction === '' || templateAction === undefined) {
                obj = {
                    parentAction: '',
                    isAdmin: this.isAdmin,
                    isStandard: this.isStandard,
                    isCompanyAdmin: this.isCompanyAdmin,
                    isCompanyTab: this.isCompanyTab,
                    isMytemplatesTab: this.isMytemplatesTab
                };
            } else {
                obj = {
                    isAdmin: this.isAdmin,
                    isStandard: this.isStandard,
                    isCompanyAdmin: this.isCompanyAdmin,
                    isCompanyTab: this.isCompanyTab,
                    isMytemplatesTab: this.isMytemplatesTab
                };
            }
            this.refeshParentPropertiesWhenChildRefresh.emit(obj);
        });
        if (this.pageName === 'campaignPage') {
            this.action = '';
            this.readOnlyEditor = true;
        }
        this.getTemplateGroupList();
        if (this.localStorage.retrieve('selectedGroup')) {
            this.setEditableTemplate();
        }
    }
    openUploadPopup() {
        const options = this.commonUtil.getModalPopUpSettings();
        delete options.size;
        const attachUploadRef = this.modalService.open(TemplateFileUploadComponent, options);
        attachUploadRef.componentInstance.uploadedAttachmentsResponse.subscribe(uploadedAttachments => {
            if (this.templateAttachments !== null && this.templateAttachments.length > 0) {
                this.templateAttachments = [...this.templateAttachments, ...uploadedAttachments];
            } else {
                this.templateAttachments = uploadedAttachments;
            }
        });
    }
    resetTemplateData() {
        this.selectedTemplateId = -1;
        this.bannerUrl = null;
        this.templateAttachments = [];
        this.action = '';
        this.isTemplateSelected.emit(false);
        this.selectedTemplateName.emit('');
        this.selectedTemplateSubject.emit('');
        this.templateContent = '';
        if (this.localStorage.retrieve('selectedGroup')) {
            this.localStorage.clear('selectedGroup');
        }
    }
    setEditableTemplate() {
        if (this.localStorage.retrieve('selectedGroup').grpid) {
            this.isTemplateSelected.emit(false);
            this.readOnlyEditor = false;
            this.selectedGroup = this.localStorage.retrieve('selectedGroup').grpid;
            this.onSelectTemplateGroup(this.localStorage.retrieve('selectedGroup').grpid);
            // this.selectedTemplateId = this.localStorage.retrieve('selectedGroup').grpid;
        }
        if (this.localStorage.retrieve('selectedGroup').tempid) {
            this.setGroupTemplate(this.localStorage.retrieve('selectedGroup').tempid);
            this.localStorage.clear(this.localStorage.retrieve('selectedGroup'));
        }
    }
}
