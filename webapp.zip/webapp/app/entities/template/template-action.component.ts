import { Subject } from 'rxjs';
import { TemplateService } from './template.service';
import { Component, OnInit, Input, Output, EventEmitter } from '@angular/core';
import { ITemplate, Template } from '../../shared/model/template.model';
import { AccountService } from '../../core/auth/account.service';
import { NgbModal, NgbActiveModal } from '@ng-bootstrap/ng-bootstrap';

@Component({
    selector: 'jhi-template-action',
    templateUrl: './template-action.component.html',
    styleUrls: ['./template-action.component.css']
})
export class TemplateActionComponent implements OnInit {
    newTemplateName: any;
    newTemplateSubject: any;
    ownerType: any;
    currentAccount: any;
    errorMessage: any;
    @Input() templateResponse;
    @Input() subject;
    @Input() templateName;
    @Input() action;
    @Input() tab;
    @Input() selectedTemplateId;
    @Output() newTemplateResponse: EventEmitter<any> = new EventEmitter();
    @Input() templateGroupResponse;
    @Input() selectedGroupId;
    selectedGroup = -1;

    constructor(public modal: NgbActiveModal, private accountService: AccountService, private templateService: TemplateService) {
        this.accountService.identity().then(account => {
            this.currentAccount = account;
        });
    }

    ngOnInit() {
        if (this.action === 'edit') {
            this.newTemplateName = this.templateName;
            this.newTemplateSubject = this.subject;
            this.selectedGroup = this.selectedGroupId;
        }
    }

    createTemplate() {
        if (this.tab.activeId === 'tab-1') {
            this.ownerType = 'STANDARD';
        } else if (this.tab.activeId === 'tab-3') {
            this.ownerType = 'COMPANY';
        } else {
            this.ownerType = 'USER';
        }
        console.log('ownerType ', this.ownerType);
        return {
            companyId: this.currentAccount.companyId,
            content: '',
            name: this.newTemplateName,
            subject: this.newTemplateSubject,
            ownerType: this.ownerType
        };
    }

    createNewTemplate() {
        if (this.newTemplateName.replace(/ /g, '').length === 0 || this.newTemplateSubject.replace(/ /g, '').length === 0) {
            this.errorMessage = 'Please enter valid name';
            return;
        } else {
            this.errorMessage = '';
        }
        if (this.selectedGroup > 0) {
            this.templateService.createSubGroup(this.createTemplate(), this.selectedGroup).subscribe((response: Template) => {
                console.log('save new temp response....', response);
                this.newTemplateResponse.emit(response);
                this.modal.close('create');
            });
        } else {
            this.templateService.create(this.createTemplate()).subscribe((response: Template) => {
                console.log('save new temp response....', response);
                this.newTemplateResponse.emit(response);
                this.modal.close('create');
            });
        }
    }

    editTemplate() {
        if (this.newTemplateName.replace(/ /g, '').length === 0 || this.newTemplateSubject.replace(/ /g, '').length === 0) {
            this.errorMessage = 'Please enter valid name';
            return;
        } else {
            this.errorMessage = '';
        }
        this.templateService.find(this.selectedTemplateId).subscribe((response: any) => {
            console.log('inside save...', response);
            response.body.name = this.newTemplateName;
            response.body.subject = this.newTemplateSubject;
            this.templateService.update(response.body, this.selectedGroup).subscribe((updatedResponse: Template) => {
                console.log('updated name and subject response ..', updatedResponse);
                this.newTemplateResponse.emit(updatedResponse);
                this.modal.close('edit');
            });
        });
    }

    onSelectTemplateGroup(selectedGroup: any) {}
}
