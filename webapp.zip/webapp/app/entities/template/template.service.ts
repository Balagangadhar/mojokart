import { Template } from 'app/shared/model/template.model';
import { Injectable } from '@angular/core';
import { Observable, of, throwError } from 'rxjs';
import { HttpClient, HttpResponse, HttpHeaders, HttpHandler, HttpErrorResponse } from '@angular/common/http';
import { SERVER_API_URL } from 'app/app.constants';
import { ISubgroup, Subgroup, IUser } from '../../shared/model/subgroup.model';
type EntityResponseType = HttpResponse<Template>;
type EntityArrayResponseType = HttpResponse<Template[]>;
@Injectable({
    providedIn: 'root'
})
export class TemplateService {
    private resourceUrl = SERVER_API_URL + 'api/templates';
    private subgroupUrl = SERVER_API_URL + 'api/sub-groups';

    constructor(private http: HttpClient) {}

    find(id: number): Observable<EntityResponseType> {
        return this.http.get<Template>(`${this.resourceUrl}/${id}`, { observe: 'response' });
    }

    getTemplateDetailsById(id) {
        return this.http.get<Template>(this.resourceUrl + '/' + id);
    }

    getTemplates(): Observable<Template[]> {
        return this.http.get<Template[]>(this.resourceUrl);
    }

    update(template: Template, subGroup?): Observable<any> {
        if (subGroup && subGroup > 0) {
            return this.http.put<Template>(this.resourceUrl + '?subGroupId=' + subGroup, template);
        } else {
            return this.http.put<Template>(this.resourceUrl, template);
        }
        // this.http.put<Template>(this.resourceUrl, template).subscribe(data => console.log(JSON.stringify(data)));
    }

    create(template: Template): Observable<any> {
        // this.http.post<Template>(this.resourceUrl, template).subscribe(data => console.log(JSON.stringify(data)));
        return this.http.post<Template>(this.resourceUrl, template);
    }

    createSubGroup(template: Template, subGroup): Observable<any> {
        // this.http.post<Template>(this.resourceUrl, template).subscribe(data => console.log(JSON.stringify(data)));
        return this.http.post<Template>(this.resourceUrl + '?subGroupId=' + subGroup, template);
    }

    delete(id: number): Observable<any> {
        return this.http.delete<any>(this.resourceUrl + '/' + id);
    }

    getTemplateGroups(type: string, contentType: string): Observable<ISubgroup> {
        return this.http.get<ISubgroup>(this.subgroupUrl + '/?type=' + type + '&contentType=' + contentType);
    }

    // getTemplateGroups(): any {
    //     const groups = [];
    //     groups.push(
    //         { id: 1, name: 'Adminstrators' },
    //         { id: 2, name: 'Agents' },
    //         { id: 3, name: 'Managers' },
    //         { id: 4, name: 'Templates' },
    //         { id: 5, name: 'Test' }
    //     );
    //     this.subGroupService.getTemplateGroups(usertype, CONTENT_TYPE.ALL).subscribe((response: any) => {
    //         console.log('groupList........', response);
    //         this.groupsList = response;
    //     });
    //     return groups;
    // }

    getGroupTemplatesBySubGroupId(sgid) {
        return this.http.get<ISubgroup>(this.resourceUrl + '/?subGroupId=' + sgid);
    }
}
