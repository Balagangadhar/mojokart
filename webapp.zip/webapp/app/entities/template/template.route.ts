import { Injectable } from '@angular/core';
import { Resolve, ActivatedRouteSnapshot, RouterStateSnapshot, Routes, RouterModule } from '@angular/router';
import { HttpResponse } from '@angular/common/http';
import { Observable } from 'rxjs';
import { filter, map } from 'rxjs/operators';
import { TemplateComponent } from './template.component';
import { TemplateService } from './template.service';
import { ITemplate, Template } from 'app/shared/model/template.model';
import { UserRouteAccessService } from 'app/core';
import { JhiResolvePagingParams } from 'ng-jhipster';

export const templateRoutes: Routes = [
    {
        path: 'template',
        component: TemplateComponent,
        resolve: {
            pagingParams: JhiResolvePagingParams
        },
        data: {
            authorities: ['ROLE_USER'],
            defaultSort: 'id,asc',
            pageTitle: 'Templates'
        },
        canActivate: [UserRouteAccessService]
    }
];

@Injectable({ providedIn: 'root' })
export class TemplateResolve implements Resolve<ITemplate> {
    constructor(private service: TemplateService) {}

    resolve(route: ActivatedRouteSnapshot, state: RouterStateSnapshot): Observable<Template> {
        const id = route.params['id'] ? route.params['id'] : null;
        if (id) {
            return this.service.find(id).pipe(
                filter((response: HttpResponse<Template>) => response.ok),
                map((templateList: HttpResponse<Template>) => templateList.body)
            );
        }
        // return of(new Template());
    }
}
