import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
    name: 'templateNameFilter'
})
export class TemplateNameFilterPipe implements PipeTransform {
    transform(templateNameResponse: any, tab: any): any {
        if (templateNameResponse !== null || templateNameResponse !== undefined) {
            if (tab.activeId === 'tab-1') {
                return (templateNameResponse || []).filter(temp => temp.ownerType === 'STANDARD');
            } else if (tab.activeId === 'tab-3') {
                return (templateNameResponse || []).filter(temp => temp.ownerType === 'COMPANY');
            } else {
                return (templateNameResponse || []).filter(temp => temp.ownerType === 'USER');
            }
        } else {
            return [];
        }
    }
}
