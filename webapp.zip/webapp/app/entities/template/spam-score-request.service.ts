import { Injectable } from '@angular/core';
import { SpamScoreRequest, ISpamScoreRequest } from 'app/shared/model/spam-score-request.model';
import { Observable } from 'rxjs';
import { HttpClient } from '@angular/common/http';
import { SERVER_API_URL } from 'app/app.constants';

@Injectable({
    providedIn: 'root'
})
export class SpamScoreRequestService {
    private resourceUrl = SERVER_API_URL + 'api/spam-score-requests';

    constructor(private http: HttpClient) {}

    get(id: number): Observable<ISpamScoreRequest> {
        return this.http.get<ISpamScoreRequest>(this.resourceUrl + `/${id}`);
    }

    create(spamScoreRequest: SpamScoreRequest): Observable<ISpamScoreRequest> {
        return this.http.post<ISpamScoreRequest>(this.resourceUrl, spamScoreRequest);
    }
}
