import { Component, OnInit, Input } from '@angular/core';
import { TemplateService } from './template.service';
import { NgbActiveModal } from '@ng-bootstrap/ng-bootstrap';
@Component({
    selector: 'jhi-delete-template',
    templateUrl: './delete-template.component.html',
    styles: []
})
export class DeleteTemplateComponent implements OnInit {
    @Input() selectedTemplateId;
    constructor(public templateService: TemplateService, public activeModal: NgbActiveModal) {}

    ngOnInit() {}

    deleteTemplateData() {
        this.templateService.delete(this.selectedTemplateId).subscribe((response: any) => {});
        this.activeModal.close('delete');
    }
}
