import { TemplateActionComponent } from './template-action.component';
import { Component, OnInit, ViewChild, ViewEncapsulation, Input, ContentChildren } from '@angular/core';
import { NgbModal, NgbModalRef, NgbModalOptions } from '@ng-bootstrap/ng-bootstrap';
import { TemplateBodyComponent } from './template-body.component';
import { SpamScoreRequestComponent } from './spam-score-request.component';
import { SpamScoreRequestService } from './spam-score-request.service';
import { SpamScoreRequest, ISpamScoreRequest } from 'app/shared/model/spam-score-request.model';
import { ActivatedRoute, Router } from '@angular/router';
import { AccountService } from '../../core/auth/account.service';
import { DeleteTemplateComponent } from './delete-template.component';
import { CommonUtil } from '../../shared/util/common-util';
import { TemplateService } from './template.service';

@Component({
    selector: 'jhi-template',
    templateUrl: './template.component.html',
    encapsulation: ViewEncapsulation.None,
    styleUrls: ['./template.component.css']
})
export class TemplateComponent implements OnInit {
    isAdmin: boolean;
    isCompanyAdmin: boolean;
    templateType: string;
    @Input() loading = true;
    imageUrl: any;
    showImage = false;
    spamResponse: any;
    score: number;
    pageName: string = null;
    campaignPage = true;
    url: string = null;
    @ViewChild(TemplateBodyComponent) child: TemplateBodyComponent;
    @ViewChild('tab') tab;
    templateNotSelected: boolean;
    isUserSelectedTemplateForEdit = false;
    isUserSelectedTemplate = false;
    spamModalRef: NgbModalRef;
    showSpinner = true;
    tempName: string;
    tempSubject: string;
    modalRef: any;
    isStandard: boolean;
    isCompanyTab: boolean;
    isMytemplatesTab: boolean;
    parentAction = '';
    isCreatePermission = false;
    isEditPermission = false;
    isDeletePermission = false;
    editAccessToBasic = false;

    constructor(
        private modalService: NgbModal,
        private spamScoreRequestService: SpamScoreRequestService,
        private route: ActivatedRoute,
        private _router: Router,
        private accountService: AccountService,
        private commonUtil: CommonUtil,
        private templateService: TemplateService
    ) {}

    cloneParentTemplate() {
        const data: any = {};
        data.content = this.child.templateContent;
        data.companyId = this.child.currentAccount.companyId;
        data.attachments = this.child.templateAttachments;
        data.name = this.child.templateData.name;
        data.ownerType = 'USER';
        data.createCopy = true;
        data.subGroup = null;
        data.id = null;
        data.subject = this.child.templateData.subject;
        this.templateService.create(data).subscribe((response: any) => {
            console.log('save new temp response....', response);
        });
    }

    createTemplate() {
        this.parentAction = 'createTemplate';
        this.child.action = this.parentAction;
        this.child.dropDownDisabled = false;
        this.child.readOnlyEditor = false;
        const options = this.commonUtil.getModalPopUpSettings();
        delete options.size;
        const createTemplateRef = this.modalService.open(TemplateActionComponent, options);
        createTemplateRef.componentInstance.templateGroupResponse = this.child.templateGroupResponse;
        // createTemplateRef.componentInstance.isMytemplatesTab = this.isMytemplatesTab;
        createTemplateRef.result.then(
            result => {
                if (result === 'close') {
                    this.parentAction = '';
                    this.child.action = this.parentAction;
                }
            },
            reason => {
                this.parentAction = '';
                this.child.action = this.parentAction;
            }
        );
        createTemplateRef.componentInstance.action = 'create';
        createTemplateRef.componentInstance.tab = this.tab;
        createTemplateRef.componentInstance.newTemplateResponse.subscribe(createdResponse => {
            if (createdResponse && createdResponse.ownerType === 'USER') {
                this.child.getTemplateData();
            } else {
                this.child.onSelectTemplateGroup(createdResponse.subGroup.id);
                this.child.selectedGroup = createdResponse.subGroup.id;
            }
            this.child.selectedTemplateId = createdResponse.id;
            this.tempName = createdResponse.name;
            this.tempSubject = createdResponse.subject;
        });
    }

    clearPageFieldsAfterDelete() {
        this.child.selectedTemplateId = -1;
        this.tempName = '';
        this.tempSubject = '';
        this.child.bannerUrl = null;
        this.child.templateContent = '';
        this.child.templateAttachments = [];
        this.parentAction = '';
        this.child.action = '';
        this.child.isTemplateSelected.emit(false);
        this.child.getTemplateData();
    }

    deleteTemplatePopUp() {
        const options = this.commonUtil.getModalPopUpSettings();
        delete options.size;
        const deleteTempRef = this.modalService.open(DeleteTemplateComponent, options);
        deleteTempRef.componentInstance.selectedTemplateId = this.child.selectedTemplateId;
        deleteTempRef.result.then(
            result => {
                if (result === 'delete') {
                    this.clearPageFieldsAfterDelete();
                }
            },
            reason => {}
        );
    }
    updateTemplate() {
        this.parentAction = 'editTemplate';
        this.child.action = this.parentAction;
        this.child.readOnlyEditor = false;
        this.isTemplateSelected(false);
    }
    saveTemplate() {
        this.parentAction = '';
        this.pageName = '';
        this.child.saveTemplate();
    }
    selectTemplate() {
        this.child.selectTemplateFromCampaignPage();
    }

    checkSpamScore() {
        const options = this.commonUtil.getModalPopUpSettings();
        delete options.size;
        this.spamScoreRequestService
            .create(new SpamScoreRequest(this.tempSubject, this.child.templateContent, this.child.banner, this.child.attachmentArray))
            .subscribe((response: ISpamScoreRequest) => {
                this.showSpinner = false;
                this.spamModalRef = this.modalService.open(SpamScoreRequestComponent, options);
                this.spamModalRef.componentInstance.spamScoreRequest = response;
                this.spamModalRef.result.then(() => (this.showSpinner = true), () => (this.showSpinner = true));
            });
    }

    isTemplateSelected(isSelected) {
        this.isUserSelectedTemplateForEdit = isSelected;
        this.isUserSelectedTemplate = isSelected;
    }
    parentActionEventEmitter(action) {
        this.parentAction = action;
        this.checkCreatePermissions();
    }

    selectedTemplateSubject(templateHeading) {
        this.tempSubject = templateHeading;
    }

    selectedTemplateName(templateHeading) {
        this.tempName = templateHeading;
    }
    refeshParentPropertiesWhenChildRefresh(obj) {
        if (Object.keys(obj).length === 3) {
            this.parentAction = obj.parentAction;
            this.isAdmin = obj.isAdmin;
            this.isStandard = obj.isStandard;
            this.isCompanyAdmin = obj.isCompanyAdmin;
            this.isCompanyTab = obj.isCompanyTab;
            this.isMytemplatesTab = obj.isMytemplatesTab;
        } else {
            this.isAdmin = obj.isAdmin;
            this.isStandard = obj.isStandard;
            this.isCompanyAdmin = obj.isCompanyAdmin;
            this.isCompanyTab = obj.isCompanyTab;
            this.isMytemplatesTab = obj.isMytemplatesTab;
        }
    }

    editTemplatePopUp() {
        const options = this.commonUtil.getModalPopUpSettings();
        delete options.size;
        const editRef = this.modalService.open(TemplateActionComponent, options);
        editRef.componentInstance.action = 'edit';
        editRef.componentInstance.templateName = this.tempName;
        editRef.componentInstance.subject = this.tempSubject;
        editRef.componentInstance.selectedTemplateId = this.child.selectedTemplateId;
        editRef.componentInstance.selectedGroupId = this.child.selectedGroup;
        editRef.componentInstance.templateGroupResponse = this.child.templateGroupResponse;
        // editRef.componentInstance.isMytemplatesTab = this.isMytemplatesTab;
        editRef.componentInstance.newTemplateResponse.subscribe(createdResponse => {
            this.child.selectedTemplateId = createdResponse.id;
            this.tempName = createdResponse.name;
            this.tempSubject = createdResponse.subject;
        });
    }

    checkUserRole(currentRole) {
        // console.log (this._accountService.hasAuthority(currentRole) );
        return this.accountService['userIdentity'].authorities.includes(currentRole);
    }

    ngOnInit() {
        this.tab.activeId = 'tab-1';
        this.tempName = '';
        this.tempSubject = '';
        this.templateNotSelected = true;
        this.pageName = this.route.snapshot.queryParams['pageName'];
        this.templateType = this.route.snapshot.queryParams['type'];
        this.parentAction = '';
        this.isUserSelectedTemplateForEdit = false;
        this.isUserSelectedTemplate = false;
        this.accountService.hasAuthority('ROLE_ADMIN').then(isAdmin => {
            this.isAdmin = isAdmin;
        });
        this.accountService.hasAuthority('ROLE_COMPANY_ADMIN').then(isCompanyAdmin => {
            this.isCompanyAdmin = isCompanyAdmin;
        });
        this.isStandard = this.tab.activeId === 'tab-1' ? true : false;
        this.isCompanyTab = this.tab.activeId === 'tab-3' ? true : false;
        this.isMytemplatesTab = this.tab.activeId === 'tab-2' ? true : false;
        if (this.pageName === 'libraryPage') {
            this.parentAction = this.route.snapshot.queryParams['templateAction'];
            const tabSelection = this.route.snapshot.queryParams['tabNameFromLibrary'];
            if (tabSelection === 'tab-1') {
                this.tab.activeId = 'tab-1';
            } else {
                this.tab.activeId = 'tab-2';
            }
        }
        if (this.pageName === 'campaignPage') {
            this.parentAction = '';
            //  this.isUserSelectedTemplate = true;
        }
        if (this.pageName === 'seriesPage') {
            this.parentAction = 'editTemplate';
        }
        if (!this.pageName) {
            this.checkCreatePermissions();
        }
    }
    changeTab(event) {
        console.log(event);
        this.child.resetTemplateData();
        this.tempName = '';
        this.tempSubject = '';
        this.parentAction = '';
        this.child.action = '';
        //   this._router.navigate(['/template']);
        this.checkCreatePermissions(event);
    }

    checkCreatePermissions(e?) {
        this.isCreatePermission = false;
        this.isEditPermission = false;
        this.isDeletePermission = false;
        this.editAccessToBasic = false;

        if (this.checkUserRole('ROLE_ADMIN')) {
            this.isAdmin = true;
        } else if (this.checkUserRole('ROLE_COMPANY_ADMIN')) {
            this.isCompanyAdmin = true;
        }
        if (e) {
            this.isStandard = false;
            this.isCompanyTab = false;
            this.isMytemplatesTab = false;
            if (e.nextId === 'tab-1') {
                this.isStandard = true;
            } else if (e.nextId === 'tab-3') {
                this.isCompanyTab = true;
            } else if (e.nextId === 'tab-2') {
                this.isMytemplatesTab = true;
            }
        }
        if ((this.isAdmin && this.isStandard) || (this.isAdmin && this.isCompanyTab) || (this.isAdmin && this.isMytemplatesTab)) {
            if (this.isCompanyTab) {
                this.isEditPermission = true;
                this.isDeletePermission = true;
            } else {
                this.isCreatePermission = true;
            }
        } else if ((this.isCompanyAdmin && this.isCompanyTab) || (this.isCompanyAdmin && this.isMytemplatesTab)) {
            this.isCreatePermission = true;
        } else if (!this.isAdmin && !this.isCompanyAdmin && this.isMytemplatesTab) {
            this.isCreatePermission = true;
        } else if (
            (!this.isAdmin && this.isStandard && !this.isCompanyAdmin) ||
            (this.isCompanyTab && !this.isCompanyAdmin && !this.isAdmin)
        ) {
            this.editAccessToBasic = true;
        }
    }
}
