import { NgModule, CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { RouterModule } from '@angular/router';
import { SharedModule } from 'app/shared';
import { BackOffice_ROUTE, BackOfficeComponent } from './';

@NgModule({
    imports: [SharedModule, RouterModule.forChild([BackOffice_ROUTE])],
    declarations: [BackOfficeComponent],
    schemas: [CUSTOM_ELEMENTS_SCHEMA]
})
export class BackOfficeModule {}
