import { Route } from '@angular/router';

import { BackOfficeComponent } from './';

export const BackOffice_ROUTE: Route = {
    path: 'backoffice/:iboomerangid',
    component: BackOfficeComponent,
    data: {
        authorities: [],
        pageTitle: 'iBoomerang E-mail Marketing +'
    }
};
