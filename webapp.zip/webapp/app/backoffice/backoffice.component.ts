import { Component, OnInit, AfterViewInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { NgbModalRef } from '@ng-bootstrap/ng-bootstrap';
import { JhiEventManager } from 'ng-jhipster';
import { LoginModalService, AccountService, LoginService, StateStorageService } from 'app/core';
import { Account } from 'app/shared/model/account.model';
import { stringify } from 'querystring';

@Component({
    selector: 'jhi-backoffice',
    templateUrl: './backoffice.component.html',
    styleUrls: ['backoffice.css']
})
export class BackOfficeComponent implements OnInit {
    account: Account;
    modalRef: NgbModalRef;
    iboomerangid: string;
    constructor(
        private accountService: AccountService,
        private loginModalService: LoginModalService,
        private loginService: LoginService,
        private stateStorageService: StateStorageService,
        private eventManager: JhiEventManager,
        private route: ActivatedRoute,
        private router: Router
    ) {}

    ngOnInit() {
        this.route.params.subscribe(obj => {
            this.iboomerangid = obj.iboomerangid;
            console.log('url id in nginit', this.iboomerangid);
        });
        if (this.iboomerangid) {
            console.log('calling func', this.iboomerangid);
            this.loginFromBackOffice(this.iboomerangid);
            console.log(this.iboomerangid, 'token');
        } else {
            window.location.href = 'https://iboom-backoffice.com/back-office/index.php#/tools';
        }
    }

    loginFromBackOffice(iboomerangid) {
        console.log('hit url to server', iboomerangid);
        this.loginService
            .loginFromBackOffice(iboomerangid)
            .then(
                () => {
                    this.eventManager.broadcast({
                        name: 'authenticationSuccess',
                        content: 'Sending Authentication Success'
                    });
                    this.router.navigate(['/dashboard']);
                },
                error => {
                    console.log('error occured', error);
                }
            )
            .catch(() => {
                console.log('catch block');
                window.location.href = 'https://iboom-backoffice.com/back-office/index.php#/tools';
            });
    }
}
