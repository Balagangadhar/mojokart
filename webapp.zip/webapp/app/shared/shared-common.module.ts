import { NgModule } from '@angular/core';
import { SharedLibsModule, JhiAlertComponent, JhiAlertErrorComponent, JhiSpinnerComponent, JhiScheduleDescComponent } from './';
import { SafeHtmlPipePipe } from './util/safe-html-pipe.pipe';
@NgModule({
    imports: [SharedLibsModule],
    declarations: [JhiAlertComponent, JhiAlertErrorComponent, JhiSpinnerComponent, JhiScheduleDescComponent, SafeHtmlPipePipe],
    exports: [SharedLibsModule, JhiAlertComponent, JhiAlertErrorComponent, JhiSpinnerComponent, JhiScheduleDescComponent, SafeHtmlPipePipe]
})
export class SharedCommonModule {}
