import { Component, Input, ChangeDetectionStrategy, ChangeDetectorRef, ViewRef } from '@angular/core';
import { JhiEventManager } from 'ng-jhipster';
import { Subject } from 'rxjs';
import { debounceTime } from 'rxjs/operators';

@Component({
    changeDetection: ChangeDetectionStrategy.OnPush,
    selector: 'jhi-spinner',
    template: `
        <div *ngIf="show" class="spinner">
            <div class="spinner-ripple">
                <div></div>
                <div></div>
            </div>
        </div>
    `,
    styleUrls: ['spinner.css']
})
export class JhiSpinnerComponent {
    @Input() enable = true;
    show = false;
    @Input() autoCloseDelay = 10000;
    @Input() showEvent = 'httpRequestStarted';
    @Input() hideEvent = 'httpRequestCompleted';
    private status = new Subject<boolean>();

    constructor(private eventManager: JhiEventManager, private changeDetectorRef: ChangeDetectorRef) {
        changeDetectorRef.detach();
        this.eventManager.subscribe(this.showEvent, () => {
            if (this.enable) {
                this.status.next(true);
            }
            if (this.changeDetectorRef && !(this.changeDetectorRef as ViewRef).destroyed) {
                this.changeDetectorRef.detectChanges();
            }
        });
        this.eventManager.subscribe(this.hideEvent, () => {
            this.status.next(false);
            if (this.changeDetectorRef !== null && this.changeDetectorRef !== undefined && !(this.changeDetectorRef as ViewRef).destroyed) {
                this.changeDetectorRef.detectChanges();
            }
        });
        this.status.subscribe(show => (this.show = show));
        this.status.pipe(debounceTime(this.autoCloseDelay)).subscribe(() => (this.show = false));
    }
}
