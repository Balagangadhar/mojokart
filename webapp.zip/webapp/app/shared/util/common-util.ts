import { NgbModalOptions } from '@ng-bootstrap/ng-bootstrap';
import { Injectable } from '@angular/core';

@Injectable({
    providedIn: 'root'
})
export class CommonUtil {
    modalOption: NgbModalOptions = {};
    getModalPopUpSettings() {
        this.modalOption.backdrop = 'static';
        this.modalOption.keyboard = false;
        this.modalOption.centered = true;
        // this.modalOption.size = 'sm';
        return this.modalOption;
    }
}
