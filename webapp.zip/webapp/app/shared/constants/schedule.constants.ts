export enum DAYS_OF_WEEKS {
    SUN = 'Sunday',
    MON = 'Monday',
    TUE = 'Tuesday',
    WED = 'Wednesday',
    THU = 'Thursday',
    FRI = 'Friday',
    SAT = 'Saturday'
}

export enum MONTHS {
    January = 1,
    February,
    March,
    April,
    May,
    June,
    July,
    August,
    September,
    October,
    November,
    December
}

export enum YEARS {
    Current_Year = 0,
    First_Year,
    Second_Year,
    Third_Year,
    Fourth_Year,
    Fifth_Year,
    Sixth_Year,
    Seventh_Year,
    Eighth_Year,
    Ninth_Year
}
