export const PROBLEM_BASE_URL = 'https://ett-iboomerang.com/problem';
