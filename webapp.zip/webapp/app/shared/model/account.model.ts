export interface IAccount {
    id?: number;
    login?: string;
    companyId?: number;
    firstName?: string;
    lastName?: string;
    email?: string;
    personalWebsite?: string;
    companyWebsite?: string;
    phone?: string;
    cell?: string;
    tollFree?: string;
    fax?: string;
    address1?: string;
    address2?: string;
    cityStateZip?: string;
    authorities?: [string];
    accessLevel?: string;
}

export class Account implements IAccount {
    constructor(
        public id?: number,
        public login?: string,
        public companyId?: number,
        public firstName?: string,
        public lastName?: string,
        public email?: string,
        public personalWebsite?: string,
        public companyWebsite?: string,
        public phone?: string,
        public cell?: string,
        public tollFree?: string,
        public fax?: string,
        public address1?: string,
        public address2?: string,
        public cityStateZip?: string,
        public authorities?: [string],
        public accessLevel?: string
    ) {
        this.id = id ? id : null;
        this.login = login ? login : null;
        this.companyId = companyId ? companyId : null;
        this.firstName = firstName ? firstName : null;
        this.lastName = lastName ? lastName : null;
        this.email = email ? email : null;
        this.personalWebsite = personalWebsite ? personalWebsite : null;
        this.companyWebsite = companyWebsite ? companyWebsite : null;
        this.phone = phone ? phone : null;
        this.cell = cell ? cell : null;
        this.tollFree = tollFree ? tollFree : null;
        this.fax = fax ? fax : null;
        this.address1 = address1 ? address1 : null;
        this.address2 = address2 ? address2 : null;
        this.cityStateZip = cityStateZip ? cityStateZip : null;
        this.authorities = authorities ? authorities : null;
        this.accessLevel = accessLevel ? accessLevel : null;
    }
}
