import { IAccount, Account } from './account.model';
import { Subgroup, ISubgroup } from './subgroup.model';

export interface ISenderProfile {
    address1?: string;
    address2?: number;
    cell?: string;
    city?: string;
    company?: ICompany;
    country?: string;
    email?: number;
    fax?: string;
    id?: number;
    name?: string;
    phone?: string;
    signature?: string;
    socialMedia?: ISocialMedia;
    state?: string;
    title?: string;
    tollFree?: string;
    url?: string;
    url2?: string;
    user?: IAccount;
    zip?: string;
}

export class SenderProfile implements ISenderProfile {
    constructor(
        public address1?: string,
        public address2?: number,
        public cell?: string,
        public city?: string,
        public company?: Company,
        public country?: string,
        public email?: number,
        public fax?: string,
        public id?: number,
        public name?: string,
        public phone?: string,
        public signature?: string,
        public socialMedia?: SocialMedia,
        public state?: string,
        public title?: string,
        public tollFree?: string,
        public url?: string,
        public url2?: string,
        public user?: Account,
        public zip?: string,
        public subGroups?: ISubgroup
    ) {}
}

export interface ISocialMedia {
    facebook?: string;
    flickr?: string;
    google?: string;
    id?: number;
    linkedin?: string;
    rss?: string;
    skype?: string;
    twitter?: string;
}
export class SocialMedia implements ISocialMedia {
    constructor(
        public facebook?: string,
        public flickr?: string,
        public google?: string,
        public id?: number,
        public linkedin?: string,
        public rss?: string,
        public skype?: string,
        public twitter?: string
    ) {}
}

export interface ICompany {
    id?: number;
    name?: string;
    shortName?: string;
    url?: string;
}

export class Company implements ICompany {
    constructor(public id?: number, public name?: string, public shortName?: string, public url?: string) {}
}
