export interface IFileUpload {
    listName?: string;
    fileName?: string;
    file?: string;
}

export class FileUpload implements IFileUpload {
    constructor(public listName?: string, public fileName?: string, public file?: string) {}
}
