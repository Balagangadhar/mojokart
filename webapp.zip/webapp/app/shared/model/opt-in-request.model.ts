import { IContact, Contact } from './contact.model';

export interface IOptIn {
    contact?: IContact;
    id?: number;
    req1Date?: IRequestData;
    req2Date?: IRequestData;
    req3Date?: IRequestData;
    status?: string;
}

export class OptIn {
    constructor(
        public contact: Contact,
        public id?: number,
        public req1Date?: RequestData,
        public req2Date?: RequestData,
        public req3Date?: RequestData,
        public status?: string
    ) {}
}

export interface IRequestData {
    date?: IRequestDate;
    time?: IRequestTime;
}
export class RequestData {
    constructor(public date?: RequestDate, public time?: RequestTime) {}
}

export interface IRequestDate {
    day?: number;
    month?: number;
    year?: number;
}
export class RequestDate {
    constructor(public day?: number, public month?: number, public year?: number) {}
}

export interface IRequestTime {
    hour?: number;
    minute?: number;
}
export class RequestTime {
    constructor(public hour?: number, public tminuteme?: number) {}
}
