import { Contact } from './contact.model';

export interface ITextCampaign {
    id?: number;
    name?: string;
    textDetails?: TextDetails;
    type?: string;
}
export class TextCampaign implements ITextCampaign {
    constructor(public id?: number, public name?: string, public type?: string, public textDetails?: TextDetails) {}
}
export interface ITextDetails {
    contacts?: Contact[];
    message?: string;
}
export class TextDetails implements ITextDetails {
    constructor(public contacts?: Contact[], public message?: string) {}
}
