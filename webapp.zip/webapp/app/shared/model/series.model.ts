export class Schedule {
    constructor(
        public id?: number,
        public daysOfWeek?: [],
        public daysOfMonth?: [],
        public months?: [],
        public yearOffsets?: [],
        public at?: ITime
    ) {}
}

export interface ISchedule {
    id?: number;
    daysOfWeek?: [];
    daysOfMonth?: [];
    months?: [];
    yearOffsets?: [];
    at?: ITime;
}

export class Series {
    constructor(public id?: number, public ownerType?: string, public name?: string, public templates?: {}) {}
}

export interface ISeries {
    id?: number;
    ownerType?: string;
    name?: string;
    templates?: {};
}

export interface ITime {
    hour?: number;
    minute?: number;
    second?: number;
}

export class Time {
    constructor(hour?: number, minute?: number, second?: number) {}
}
