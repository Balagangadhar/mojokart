export interface IContact {
    city?: string;
    companyId?: number;
    companyName?: string;
    email?: string;
    extension?: string;
    id?: number;
    mobileNumber?: string;
    name?: string;
    ownerId?: number;
    phone?: string;
    street?: string;
    webUrl?: string;
    zip?: string;
    allowOptInRequest?: boolean;
}

export class Contact implements IContact {
    constructor(
        public city?: string,
        public companyId?: number,
        public companyName?: string,
        public email?: string,
        public extension?: string,
        public id?: number,
        public mobileNumber?: string,
        public name?: string,
        public ownerId?: number,
        public phone?: string,
        public street?: string,
        public webUrl?: string,
        public zip?: string,
        public allowOptInRequest?: boolean
    ) {}
}
