import { IBlob, Blob } from './blob.model';

export interface ITemplate {
    content?: string;
    attachments?: IBlob[];
    banner?: IBlob;
    id?: number;
    name?: string;
    ownerType?: any;
    subject?: string;
}

export class Template {
    constructor(
        public content?: string,
        public attachments?: Blob[],
        public banner?: Blob,
        public name?: string,
        public ownerType?: any,
        public subject?: string,
        public id?: number
    ) {}
}
