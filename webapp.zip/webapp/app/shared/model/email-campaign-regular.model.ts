import { Blob, IBlob } from './blob.model';
import { Contact } from './contact.model';
import { Template } from './template.model';
import { Series, ISeries } from './series.model';
import { Time, ITime } from './series.model';
import { TextDetails } from './text-campaign.model';

export interface IRegularCampaign {
    attachments?: IBlob[];
    banner?: Blob;
    bccList?: string;
    ccList?: string;
    clicks?: number;
    companyId?: number;
    contactList?: EmaiilContactList;
    contacts?: Contact[];
    senderId?: number;
    senderName?: string;
    senderEmail?: string;
    id?: number;
    message?: string;
    reportedSpam?: number;
    sentDate?: string;
    seriesId?: number;
    status?: string;
    subject?: string;
    template?: Template;
    toEmail?: string;
    toName?: string;
    views?: number;
    campaignName?: string;
}

export interface ICampaign {
    companyId: number;
    emailDetails: RegularCampaign;
    id?: number;
    name?: string;
    ownerId?: number;
    status: any;
    type: any;
    series?: ISeries;
    createdDate?: string;
    lastModifiedDate?: string;
    textDetails?: TextDetails;
    date?: ICampaignSchedule;
}

export class Campaign {
    constructor(
        public companyId: number,
        public name: string,
        public status: any = 'DRAFT',
        public type: any = 'EMAIL',
        public emailDetails: RegularCampaign,
        public ownerId?: number,
        public id?: number,
        public series?: Series,
        public createdDate?: string,
        public lastModifiedDate?: string,
        public textDetails?: TextDetails,
        public date?: CampaignSchedule
    ) {}
}

export class RegularCampaign {
    constructor(
        public attachments: Blob[] = [],
        public toName: any = '',
        public bccList: any = '',
        public ccList: any = '',
        public banner?: Blob,
        public clicks?: number,
        public companyId: any = 0,
        public contactList?: IEmaiilContactList,
        public contacts?: Contact[],
        public senderId?: number,
        public senderName?: string,
        public id?: number,
        public message?: string,
        public reportedSpam?: number,
        public sentDate?: string,
        public seriesId?: number,
        public status?: string,
        public subject: any = '',
        public template?: Template,
        public toEmail: any = '',
        public views?: number
    ) {}
}

export interface IEmaiilContactList {
    contacts?: Contact[];
    companyId?: number;
    id?: number;
    lastModifiedDate?: string;
    name?: string;
    ownerId?: number;
}

export class EmaiilContactList {
    constructor(
        public contacts?: Contact[],
        public companyId?: number,
        public id?: number,
        public lastModifiedDate?: string,
        public name?: string,
        public ownerId?: number
    ) {}
}

export class CampaignSchedule {
    constructor(public date?: ScheduleDate, public time?: Time) {}
}

export interface ICampaignSchedule {
    date: IScheduleDate;
    time: ITime;
}

export class ScheduleDate {
    constructor(public day?: number, public month?: number, public year?: number) {}
}

export interface IScheduleDate {
    day?: number;
    month?: number;
    year?: number;
}
