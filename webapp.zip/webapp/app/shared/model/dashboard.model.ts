export class EmailDeliverySummary {
    constructor(
        recipients?: number,
        queued?: number,
        sent?: number,
        failedTemporarily?: number,
        failedPermanently?: number,
        delivered?: number,
        unsubscribed?: number,
        views?: number,
        clicks?: number,
        reportedSpam?: number,
        sentDate?: string
    ) {}
}

export interface IEmailDeliverySummary {
    sentDate?: string;
    recipients: number;
    queued: number;
    sent: number;
    failedTemporarily: number;
    failedPermanently: number;
    delivered: number;
    unsubscribed: number;
    views: number;
    clicks: number;
    reportedSpam: number;
}
export class TextDeliverySummary {
    constructor(recipients?: number, queued?: number, sent?: number, failedPermanently?: number, delivered?: number, sentDate?: string) {}
}

export interface ITextDeliverySummary {
    recipients: number;
    queued: number;
    sent: number;
    failedPermanently: number;
    delivered: number;
    sentDate: string;
}

export class AccountCompleteness {
    constructor(
        completeness: number,
        hasContactList?: boolean,
        hasContacts?: boolean,
        hasEmailSignature?: boolean,
        hasSentSeries?: boolean,
        hasSentTemplate?: boolean,
        hasSentText?: boolean,
        hasSeries?: boolean,
        hasSocialMedia?: boolean,
        hasTemplate?: boolean
    ) {}
}

export interface IAccountCompleteness {
    completeness: number;
    hasContactList?: boolean;
    hasContacts?: boolean;
    hasEmailSignature?: boolean;
    hasSentSeries?: boolean;
    hasSentTemplate?: boolean;
    hasSentText?: boolean;
    hasSeries?: boolean;
    hasSocialMedia?: boolean;
    hasTemplate?: boolean;
}

export class AccountUsage {
    constructor(emailUsage: Usage, textUsage: Usage) {}
}

export interface IAccountUsage {
    emailUsage?: IUsage;
    textUsage?: IUsage;
}

export class Usage {
    constructor(limit: number, used: number) {}
}

export interface IUsage {
    limit: number;
    used: number;
}
