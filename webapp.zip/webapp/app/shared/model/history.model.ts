import { Campaign } from './email-campaign-regular.model';

export interface IHistory {
    campaign: Campaign;
    sentDate: string;
    recipients: number;
    queued: number;
    sent: number;
    failedTemporarily: number;
    failedPermanently: number;
    delivered: number;
    unsubscribed: number;
    views: number;
    clicks: number;
    reportedSpam: number;
}
export class History implements IHistory {
    campaign: Campaign;
    sentDate: string;
    recipients: number;
    queued: number;
    sent: number;
    failedTemporarily: number;
    failedPermanently: number;
    delivered: number;
    unsubscribed: number;
    views: number;
    clicks: number;
    reportedSpam: number;
}
