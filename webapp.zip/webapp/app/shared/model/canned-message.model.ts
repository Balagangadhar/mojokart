export interface ICannedMessage {
    id?: number;
    message?: string;
}
export class CannedMessage implements ICannedMessage {
    constructor(public id?: number, public message?: string) {}
}
