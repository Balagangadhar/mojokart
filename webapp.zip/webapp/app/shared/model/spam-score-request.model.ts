import { IBlob } from './blob.model';

export interface ISpamScoreRequest {
    id?: number;
    subject?: string;
    message?: string;
    banner?: IBlob;
    attachments?: IBlob[];
    score?: number;
    spam?: Boolean;
    tips?: string[];
    status?: SpamScoreRequestStatus;
}

export class SpamScoreRequest implements ISpamScoreRequest {
    constructor(public subject: string, public message: string, public banner: IBlob, public attachments: IBlob[]) {}
}

export enum SpamScoreRequestStatus {
    QUEUED = 'QUEUED',
    SENT = 'SENT',
    DELIVERED = 'DELIVERED',
    FAILED = 'FAILED',
    COMPLETED = 'COMPLETED'
}
