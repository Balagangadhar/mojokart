import { Contact } from './contact.model';

export interface IContactList {
    companyId?: number;
    contacts?: Contact[];
    id?: number;
    lastModifiedDate?: Date;
    name?: string;
    ownerId?: number;
}

export class ContactList implements IContactList {
    constructor(
        public contacts?: Contact[],
        public companyId?: number,
        public id?: number,
        public lastModifiedDate?: Date,
        public name?: string,
        public ownerId?: number
    ) {}
}
