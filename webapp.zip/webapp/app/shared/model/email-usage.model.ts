export interface IEmailusage {
    emailUsage?: any;
    textUsage?: any;
}

export class Emailusage implements IEmailusage {
    constructor(public emailUsage?: any, public textUsage?: any) {}
}
