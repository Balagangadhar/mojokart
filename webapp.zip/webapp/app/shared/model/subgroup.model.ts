import { GLOBAL_PUBLISH_EXPANDO_KEY } from '@angular/core/src/render3/global_utils';

export interface ISubgroup {
    contentType?: string;
    id?: number;
    name?: string;
    type?: string;
    users?: IUser[];
}

export interface IUser {
    accessLevel?: string;
    address1?: string;
    address2?: string;
    authorities?: [];
    cell?: string;
    cityStateZip?: string;
    companyId?: number;
    companyWebsite?: string;
    email?: string;
    fax?: string;
    firstName?: string;
    id?: number;
    lastName?: string;
    login?: string;
    personalWebsite?: string;
    phone?: string;
    tollFree?: string;
}

export class Subgroup {
    constructor(public contentType?: string, public id?: number, public name?: string, public type?: string, public users?: IUser[]) {}
}

export class User {
    constructor(
        public accessLevel?: string,
        public address1?: string,
        public address2?: string,
        public authorities?: [],
        public cell?: string,
        public cityStateZip?: string,
        public companyId?: number,
        public companyWebsite?: string,
        public email?: string,
        public fax?: string,
        public firstName?: string,
        public id?: number,
        public lastName?: string,
        public login?: string,
        public personalWebsite?: string,
        public phone?: string,
        public tollFree?: string
    ) {}
}

export enum USER_TYPE {
    ROLE_ADMIN = 'GLOBAL',
    ROLE_COMPANY_ADMIN = 'COMPANY',
    ROLE_USER = 'USER'
}

export enum CONTENT_TYPE {
    BANNER = 'BANNER',
    IMAGE = 'IMAGE',
    STOCK_IMAGE = 'STOCK_IMAGE',
    ALL = 'ALL',
    COMPANY = 'COMPANY',
    COMPANY_IMAGE = 'COMPANY_IMAGE',
    SIGN_IMAGE = 'SIGN_IMAGE'
}
