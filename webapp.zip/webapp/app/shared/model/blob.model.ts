export interface IBlob {
    id?: number;
    companyId?: number;
    ownerId?: number;
    type?: string;
    filename?: string;
    originalFilename?: string;
    mimeType?: string;
    filesize?: number;
    description?: string;
    url?: string;
    headers: any;
    body: any;
}

export class Blob {
    constructor(
        public id: number,
        public companyId: number,
        public ownerId: number,
        public type: any,
        public filename: string,
        public originalFilename: string,
        public mimeType: string,
        public filesize: number,
        public description: string,
        public url: string,
        public headers: any,
        public body: any
    ) {}
}
