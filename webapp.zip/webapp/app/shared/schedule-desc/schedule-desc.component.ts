import { Component, Input, OnInit, OnChanges, SimpleChanges, SimpleChange, OnDestroy } from '@angular/core';
import { ISchedule } from '../model/series.model';
import { YEARS, DAYS_OF_WEEKS, MONTHS } from '..';
import { JhiEventManager } from 'ng-jhipster';
import { Subscription } from 'rxjs';

@Component({
    selector: 'jhi-schedule-desc',
    styleUrls: ['./schedule-desc.component.css'],
    template: `
        <p class="m-0" *ngIf="(!!daysOfWeek && daysOfWeek.length > 0) || (!!daysOfMonth && daysOfMonth.length > 0)">
            <span>Send</span><span *ngIf="!!time"> at {{ time }}</span>
            <span class="m-0" *ngIf="!!daysOfWeek && daysOfWeek.length > 0">
                <span> on </span>
                <span *ngFor="let dayOfWeek of daysOfWeek; let i = index">
                    <span *ngIf="daysOfWeek.length !== 1 && i === daysOfWeek.length - 1"> and </span> {{ getDayOfWeek(dayOfWeek)
                    }}<span *ngIf="i !== daysOfWeek.length - 1 && i !== daysOfWeek.length - 2">, </span>
                </span>
            </span>
            <span class="m-0" *ngIf="!!daysOfMonth && daysOfMonth.length > 0">
                <span *ngIf="daysOfMonth.length === 1"> on day </span> <span *ngIf="daysOfMonth.length > 1"> on days </span>
                <span *ngFor="let dayOfMonth of daysOfMonth; let i = index">
                    <span *ngIf="daysOfMonth.length !== 1 && i === daysOfMonth.length - 1"> and </span> {{ dayOfMonth
                    }}<span *ngIf="i !== daysOfMonth.length - 1 && i !== daysOfMonth.length - 2">, </span>
                </span>
            </span>
        </p>
        <p class="m-0">
            <span *ngIf="!!months && months.length > 0">
                <span>Of </span>
                <span *ngFor="let month of months; let i = index">
                    <span *ngIf="months.length !== 1 && i === months.length - 1"> and </span> {{ getMonth(month)
                    }}<span *ngIf="i !== months.length - 1 && i !== months.length - 2">, </span>
                </span>
            </span>
            <span class="m-0" *ngIf="!!yearOffsets && yearOffsets.length > 0">
                <span> for </span>
                <span *ngFor="let yearOffset of yearOffsets; let i = index">
                    <span *ngIf="yearOffsets.length !== 1 && i === yearOffsets.length - 1"> and </span> {{ getYear(yearOffset)
                    }}<span *ngIf="i !== yearOffsets.length - 1 && i !== yearOffsets.length - 2">, </span>
                </span>
            </span>
        </p>
    `
})
export class JhiScheduleDescComponent implements OnInit, OnChanges, OnDestroy {
    time: string;
    @Input()
    schedule: ISchedule;
    @Input()
    at: any;
    @Input()
    daysOfWeek: any[];
    @Input()
    daysOfMonth: any[];
    @Input()
    months: any[];
    @Input()
    yearOffsets: any[];
    subscription: Subscription;

    constructor(private eventManager: JhiEventManager) {}

    ngOnInit(): void {
        this.init();
        this.subscription = this.eventManager.subscribe('scheduleUpdated', message => {
            if (!!this.schedule && this.schedule.id === message.content.id) {
                this.schedule = message.content;
                this.reset();
                this.init();
            }
        });
    }

    ngOnChanges(changes: SimpleChanges) {
        const _at: SimpleChange = changes.at;
        const _daysOfWeek: SimpleChange = changes.daysOfWeek;
        const _daysOfMonth: SimpleChange = changes.daysOfMonth;
        const _months: SimpleChange = changes.months;
        const _yearOffsets: SimpleChange = changes.yearOffsets;
        this.at = (!!_at && _at.currentValue) || this.at;
        this.daysOfWeek = (!!_daysOfWeek && _daysOfWeek.currentValue.map(dayOfWeek => dayOfWeek.item_id)) || this.daysOfWeek;
        this.daysOfMonth = (!!_daysOfMonth && _daysOfMonth.currentValue.map(dayOfMonth => dayOfMonth.item_id)) || this.daysOfMonth;
        this.months = (!!_months && _months.currentValue.map(month => month.item_id)) || this.months;
        this.yearOffsets = (!!_yearOffsets && _yearOffsets.currentValue.map(yearOffset => yearOffset.item_id)) || this.yearOffsets;
        this.init();
    }

    reset() {
        this.at = null;
        this.daysOfWeek = null;
        this.daysOfMonth = null;
        this.months = null;
        this.yearOffsets = null;
    }

    init() {
        this.at = this.at || (!!this.schedule && this.schedule.at);
        this.daysOfWeek = this.daysOfWeek || (!!this.schedule && this.schedule.daysOfWeek);
        this.daysOfMonth = this.daysOfMonth || (!!this.schedule && this.schedule.daysOfMonth);
        this.months = this.months || (!!this.schedule && this.schedule.months);
        this.yearOffsets = this.yearOffsets || (!!this.schedule && this.schedule.yearOffsets);
        if (!!this.at) {
            const now = new Date();
            now.setHours(this.at.hour);
            now.setMinutes(this.at.minute);
            now.setSeconds(0);
            now.setMilliseconds(0);
            this.time = now.toLocaleTimeString().replace(':00 ', ' ');
        }
    }

    getMonth(month) {
        return MONTHS[month];
    }

    getDayOfWeek(dayOfWeek) {
        return DAYS_OF_WEEKS[dayOfWeek];
    }

    getYear(yearOffset) {
        if (!!YEARS[yearOffset]) {
            return YEARS[yearOffset].replace('_', ' ').toLowerCase();
        }
    }

    ngOnDestroy(): void {
        this.eventManager.destroy(this.subscription);
    }
}
