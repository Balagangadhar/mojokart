import { HttpInterceptor, HttpRequest, HttpHandler, HttpEvent, HttpEventType, HttpResponse } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { JhiEventManager } from 'ng-jhipster';
import { Observable } from 'rxjs';
import { tap } from 'rxjs/operators';

@Injectable()
export class ProgressInterceptor implements HttpInterceptor {
    constructor(private eventManager: JhiEventManager) {}

    intercept(request: HttpRequest<any>, next: HttpHandler): Observable<HttpEvent<any>> {
        return next.handle(request).pipe(
            tap(
                (event: HttpEvent<any>) => {
                    if (event.type < HttpEventType.Response) {
                        this.eventManager.broadcast({ name: 'httpRequestStarted' });
                    } else {
                        this.eventManager.broadcast({ name: 'httpRequestCompleted' });
                    }
                },
                () => this.eventManager.broadcast({ name: 'httpRequestCompleted' })
            )
        );
    }
}
