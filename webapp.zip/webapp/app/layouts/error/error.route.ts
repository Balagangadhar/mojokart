import { Routes } from '@angular/router';
import { ErrorComponent } from './error.component';

export const errorRoute: Routes = [
    {
        path: 'error',
        component: ErrorComponent,
        data: {
            authorities: [],
            pageTitle: 'iBoomerang E-mail Marketing +'
        }
    },
    {
        path: 'accessdenied',
        component: ErrorComponent,
        data: {
            authorities: [],
            pageTitle: 'iBoomerang E-mail Marketing +',
            error403: true
        }
    }
];
