import { Component } from '@angular/core';

@Component({
    selector: 'jhi-footer',
    templateUrl: './footer.component.html'
})
export class FooterComponent {
    copyrightYear = new Date().getFullYear();

    goToHomePage() {
        window.open('http://iboomerang.com', '_blank');
    }

    goToPrivacyPolicy() {
        window.open('http://iboomerang.com/privacy-policy', '_blank');
    }

    goToTerms() {
        window.open('http://iboomerang.com/resources/terms_master-agreement.pdf', '_blank');
    }
}
