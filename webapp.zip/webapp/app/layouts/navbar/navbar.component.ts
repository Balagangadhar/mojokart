import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { NgbModalRef } from '@ng-bootstrap/ng-bootstrap';
import { VERSION } from 'app/app.constants';
import { AccountService, LoginModalService, LoginService } from 'app/core';
import { ProfileService } from '../profiles/profile.service';
import { CampaignService } from '../../entities/campaigns/campaigns.service';

@Component({
    selector: 'jhi-navbar',
    templateUrl: './navbar.component.html',
    styleUrls: ['navbar.css']
})
export class NavbarComponent implements OnInit {
    inProduction: boolean;
    isNavbarCollapsed: boolean;
    isNavbar2Collapsed: boolean;
    languages: any[];
    swaggerEnabled: boolean;
    modalRef: NgbModalRef;
    version: string;
    unsubscribe = false;
    textCampaignFlag: boolean;

    constructor(
        private loginService: LoginService,
        private accountService: AccountService,
        private loginModalService: LoginModalService,
        private profileService: ProfileService,
        private campaignService: CampaignService,
        private router: Router
    ) {
        this.version = VERSION ? 'v' + VERSION : '';
        this.isNavbarCollapsed = true;
        this.isNavbar2Collapsed = true;
        this.textCampaign();
    }

    ngOnInit() {
        this.profileService.getProfileInfo().then(profileInfo => {
            this.inProduction = profileInfo.inProduction;
            this.swaggerEnabled = profileInfo.swaggerEnabled;
        });
        this.onUnsubscribePage();
    }

    collapseNavbar() {
        this.isNavbarCollapsed = true;
        this.isNavbar2Collapsed = true;
    }

    isAuthenticated() {
        return this.accountService.isAuthenticated();
    }

    login() {
        this.modalRef = this.loginModalService.open();
    }

    logout() {
        this.collapseNavbar();
        this.loginService.logout();
        //  this.router.navigate(['']);
        window.location.href = 'https://iboom-backoffice.com/back-office/index.php#/tools';
    }

    toggleNavbar() {
        this.isNavbarCollapsed = !this.isNavbarCollapsed;
    }

    toggleNavbar2() {
        this.isNavbar2Collapsed = !this.isNavbar2Collapsed;
    }

    getImageUrl() {
        return this.isAuthenticated() ? this.accountService.getImageUrl() : null;
    }

    textCampaign() {
        this.campaignService.getEmailUsageStats().subscribe(response => {
            response.textUsage.used >= response.textUsage.limit ? (this.textCampaignFlag = true) : (this.textCampaignFlag = false);
        });
    }

    onUnsubscribePage() {
        if (this.router.url.startsWith('/unsubscribe')) {
            this.unsubscribe = true;
        } else {
            this.unsubscribe = false;
        }
    }
}
